#pragma once

#include <cdk/types/balanced3_type.h>
#include <cdk/ast/literal_node.h>

namespace cdk {

  /**
   * Class for describing syntactic tree leaves for holding
   * balanced ternary integer values (40-trit, stored as treg_t).
   */
  class balanced3_node : public virtual literal_node<balanced3_type::value_type> {
  public:
    balanced3_node(int lineno, const balanced3_type::value_type &v) noexcept:
        literal_node<balanced3_type::value_type>(lineno, v) {
    }

    void accept(basic_ast_visitor *sp, int level) override { sp->do_balanced3_node(this, level); }

  };

} // cdk

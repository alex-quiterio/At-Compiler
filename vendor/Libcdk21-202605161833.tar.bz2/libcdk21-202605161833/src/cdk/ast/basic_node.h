#pragma once

#include <cctype>
#include <typeinfo>
#include <iostream>
#include "targets/basic_ast_visitor.h"

namespace cdk {

  /**
   * Class for describing AST nodes.
   * This is an abstract class and forms the root of the node hierarchy.
   * The node hierarchy is organized in a structure according to the
   * <i>Composite</i> design pattern: class <tt>node</tt> is the root
   * of the hierarchy; class <tt>simple</tt> is a template for leaves
   * holding simple (atomic) types; <tt>composite</tt> represents the
   * recursive structure. Note that other recursion classes are possible
   * by extending any of the classes in this family.
   */
  class basic_node {
    const int _lineno; // source line

  protected:
    /**
     * Simple constructor.
     *
     * @param lineno the source code line number corresponding to the node
     */
    basic_node(int lineno) : _lineno(lineno) {}

  public:
    virtual ~basic_node() noexcept = default;

  public:
    /** @return the line number of the corresponding source code */
    int lineno() const noexcept { return _lineno; }

    /** @return the label of the node (i.e., it's class) */
    std::string label() const noexcept {
      // Itanium mangled name: optional 'N', then a sequence of
      // <length><chars> segments, optionally terminated by 'E'. The class
      // label is the last such segment. We must parse structurally — a
      // trailing digit search would misfire on names like "posit3_node".
      const std::string fullname = typeid(*this).name();
      std::size_t pos = (!fullname.empty() && fullname[0] == 'N') ? 1 : 0;
      std::string last;
      while (pos < fullname.size() && std::isdigit(static_cast<unsigned char>(fullname[pos]))) {
        std::size_t len = 0;
        while (pos < fullname.size() && std::isdigit(static_cast<unsigned char>(fullname[pos]))) {
          len = len * 10 + (fullname[pos] - '0');
          ++pos;
        }
        if (pos + len > fullname.size()) break;
        last = fullname.substr(pos, len);
        pos += len;
      }
      return last;
    }

    /**
     * Every non-abstract node must provide this method.
     *
     * @param av basic AST visitor
     * @param level syntactic tree level
     */
    virtual void accept(basic_ast_visitor *av, int level) = 0;

  };

} // cdk

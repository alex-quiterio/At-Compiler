#pragma once

#include <cdk/types/takum3_type.h>
#include <cdk/ast/literal_node.h>

namespace cdk {

  /**
   * Class for describing syntactic tree leaves for holding
   * logarithmic ternary takum real values (80-trit, Hunhold Def. 2).
   */
  class takum3_node : public virtual literal_node<takum3_type::value_type> {
  public:
    takum3_node(int lineno, const takum3_type::value_type &v) noexcept:
        literal_node<takum3_type::value_type>(lineno, v) {
    }

    void accept(basic_ast_visitor *sp, int level) override { sp->do_takum3_node(this, level); }

  };

} // cdk

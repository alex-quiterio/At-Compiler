#pragma once

#include <cdk/types/posit3_type.h>
#include <cdk/ast/literal_node.h>

namespace cdk {

  /**
   * Class for describing syntactic tree leaves for holding
   * logarithmic ternary posit real values (80-trit, stored as treg_t).
   */
  class posit3_node : public virtual literal_node<posit3_type::value_type> {
  public:
    posit3_node(int lineno, const posit3_type::value_type &v) noexcept:
        literal_node<posit3_type::value_type>(lineno, v) {
    }

    void accept(basic_ast_visitor *sp, int level) override { sp->do_posit3_node(this, level); }

  };

} // cdk

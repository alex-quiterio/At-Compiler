#pragma once

#include <cdk/types/basic_type.h>
#include <cdk/types/treg_value.h>
#include <cdk/types/treg_alu.h>

namespace cdk {

  /**
   * Logarithmic ternary takum real type (80-trit, stored as treg_t).
   *
   * Hunhold Definition 2 (2024) adapted for balanced ternary with base 3.
   * Fixed 2-trit regime field; variable characteristic and mantissa.
   */
  struct takum3_type : public basic_type {

    struct value_type : public treg_value {

      /** Zero. */
      value_type() { treg_alu::clear(*this); }

      /** From raw halves. */
      value_type(uint64_t h0, uint64_t h1, uint64_t h2) { set_half(0, h0); set_half(1, h1); set_half(2, h2); }

      /**
       * From decimal string — the primary scanner constructor.
       * Parses the string and converts to 80-trit logarithmic takum
       * entirely via balanced ternary arithmetic (no floating-point).
       */
      explicit value_type(const char *s) {
        treg_alu::load_takum3(*this, s);
      }

      /** From balanced3 integer value. */
      explicit value_type(const balanced3_type::value_type &b3) {
        treg_alu::load_takum3_from_balanced3(*this, b3);
      }

      /** Decimal string representation of the real value. */
      std::string to_string() const {
        return treg_alu::takum3_to_string(*this);
      }

      bool operator==(const value_type &o) const {
        return half(0) == o.half(0) && half(1) == o.half(1) && half(2) == o.half(2);
      }
      bool operator!=(const value_type &o) const { return !(*this == o); }
    };

  public:

    explicit takum3_type(explicit_call_disabled) :
        basic_type(16, TYPE_TAKUM3) {
    }

    ~takum3_type() = default;

  public:

    static auto create() {
      return std::make_shared<takum3_type>(explicit_call_disabled());
    }

    static auto cast(std::shared_ptr<basic_type> type) {
      return std::dynamic_pointer_cast<takum3_type>(type);
    }

  public:

    std::string to_string() const override { return "takum3"; }

  };

} // cdk

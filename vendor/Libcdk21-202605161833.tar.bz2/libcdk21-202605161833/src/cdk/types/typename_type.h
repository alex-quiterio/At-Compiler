#pragma once

#include <cstdint>

namespace cdk {

  enum typename_type : uint64_t {
    TYPE_UNSPEC = 0,

    TYPE_INT = 1UL << 0,
    TYPE_DOUBLE = 1UL << 1,
    TYPE_BOOLEAN = 1UL << 2,
    TYPE_STRING = 1UL << 3,
    TYPE_POINTER = 1UL << 4,
    TYPE_STRUCT = 1UL << 5,
    TYPE_FUNCTIONAL = 1UL << 6,
    TYPE_TENSOR = 1UL << 7,
    TYPE_BALANCED3 = 1UL << 8,
    TYPE_POSIT3 = 1UL << 9,
    TYPE_TAKUM3 = 1UL << 10,
    TYPE_VOID = 1UL << 30,

    TYPE_ERROR = 1UL << 31,
  };

} // cdk

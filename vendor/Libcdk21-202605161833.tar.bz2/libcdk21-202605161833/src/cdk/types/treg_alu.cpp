#include <cdk/types/treg_alu.h>
#include <cstring>
#include <cctype>
#include <string>

namespace cdk {

/* ================================================================== */
/*  Core operations                                                    */
/* ================================================================== */

void treg_alu::clear(treg_value &r) {
  r.h[0] = HALF_BIAS;
  r.h[1] = HALF_BIAS;
  r.h[2] = HALF_BIAS;
}

void treg_alu::neg(treg_value &dst, const treg_value &src) {
  for (int i = 0; i < HALVES; i++)
    dst.h[i] = HALF_MAX - src.h[i];
}

void treg_alu::copy(treg_value &dst, const treg_value &src) {
  for (int i = 0; i < HALVES; i++)
    dst.h[i] = src.h[i];
}

int treg_alu::get_trit(const treg_value &r, int pos) {
  if (pos < 0 || pos >= TRITS) return 0;
  int half = pos / HALF_TRITS;
  int idx  = pos % HALF_TRITS;
  return static_cast<int>((r.h[half] / pow3[idx]) % 3) - 1;
}

void treg_alu::set_trit(treg_value &r, int pos, int trit) {
  if (pos < 0 || pos >= TRITS) return;
  int half = pos / HALF_TRITS;
  int idx  = pos % HALF_TRITS;
  uint64_t *hp = &r.h[half];
  int old_d = static_cast<int>((*hp / pow3[idx]) % 3);
  *hp = *hp - static_cast<uint64_t>(old_d) * pow3[idx]
            + static_cast<uint64_t>(trit + 1) * pow3[idx];
}

void treg_alu::unpack(const treg_value &r, int trits[TRITS]) {
  for (int half = 0; half < HALVES; half++) {
    uint64_t v = r.h[half];
    int base = half * HALF_TRITS;
    for (int i = 0; i < HALF_TRITS; i++) {
      trits[base + i] = static_cast<int>(v % 3) - 1;
      v /= 3;
    }
  }
}

void treg_alu::repack(treg_value &r, const int trits[TRITS]) {
  for (int half = 0; half < HALVES; half++) {
    uint64_t v = 0;
    int base = half * HALF_TRITS;
    for (int i = HALF_TRITS - 1; i >= 0; i--)
      v = v * 3 + static_cast<uint64_t>(trits[base + i] + 1);
    r.h[half] = v;
  }
}

/* ================================================================== */
/*  Arithmetic                                                         */
/* ================================================================== */

int treg_alu::normalize_trit(int d, int *carry) {
  int adj = d + 1;
  int c = (adj >= 0) ? adj / 3 : (adj - 2) / 3;
  *carry = c;
  return d - c * 3;
}

void treg_alu::add(treg_value &dst, const treg_value &a, const treg_value &b) {
  int ta[TRITS], tb[TRITS], tr[TRITS];
  unpack(a, ta);
  unpack(b, tb);

  int carry = 0;
  for (int i = 0; i < TRITS; i++) {
    int s = ta[i] + tb[i] + carry;
    tr[i] = normalize_trit(s, &carry);
  }

  repack(dst, tr);
}

void treg_alu::sub(treg_value &dst, const treg_value &a, const treg_value &b) {
  treg_value nb;
  neg(nb, b);
  add(dst, a, nb);
}

static constexpr int DOUBLE_TRITS = treg_alu::TRITS * 2;

void treg_alu::mul(treg_value &dst_lo, treg_value &dst_hi,
                   const treg_value &a, const treg_value &b) {
  int ta[TRITS], tb[TRITS];
  int tr[DOUBLE_TRITS];
  unpack(a, ta);
  unpack(b, tb);

  for (int i = 0; i < DOUBLE_TRITS; i++) tr[i] = 0;

  for (int i = 0; i < TRITS; i++) {
    if (ta[i] == 0) continue;
    for (int j = 0; j < TRITS; j++)
      tr[i + j] += ta[i] * tb[j];
  }

  /* normalise from LST to MST */
  for (int k = 0; k < DOUBLE_TRITS - 1; k++) {
    int carry;
    tr[k] = normalize_trit(tr[k], &carry);
    tr[k + 1] += carry;
  }
  int discard;
  tr[DOUBLE_TRITS - 1] = normalize_trit(tr[DOUBLE_TRITS - 1], &discard);

  repack(dst_lo, tr);
  repack(dst_hi, tr + TRITS);
}

void treg_alu::mul_fixed(treg_value &dst, const treg_value &a,
                         const treg_value &b, int int_trits) {
  /*
   * Fixed-point multiply: both operands have int_trits integer trits
   * at the top of the 120-trit register.  The product's integer part
   * starts at trit position (TRITS - int_trits) in the 240-trit result.
   *
   * We extract the 120-trit window starting at offset (TRITS - int_trits)
   * from the full 240-trit product.
   */
  int ta[TRITS], tb[TRITS];
  int tr[DOUBLE_TRITS];
  unpack(a, ta);
  unpack(b, tb);

  for (int i = 0; i < DOUBLE_TRITS; i++) tr[i] = 0;

  for (int i = 0; i < TRITS; i++) {
    if (ta[i] == 0) continue;
    for (int j = 0; j < TRITS; j++)
      tr[i + j] += ta[i] * tb[j];
  }

  for (int k = 0; k < DOUBLE_TRITS - 1; k++) {
    int carry;
    tr[k] = normalize_trit(tr[k], &carry);
    tr[k + 1] += carry;
  }
  int discard;
  tr[DOUBLE_TRITS - 1] = normalize_trit(tr[DOUBLE_TRITS - 1], &discard);

  /* extract the window: trits [frac_trits .. frac_trits + TRITS - 1] */
  int frac_trits = TRITS - int_trits;
  int window[TRITS];
  for (int i = 0; i < TRITS; i++)
    window[i] = (frac_trits + i < DOUBLE_TRITS) ? tr[frac_trits + i] : 0;

  repack(dst, window);
}

int treg_alu::abs_compare_trits(const int *a, const int *b, int len) {
  int sa = 0, sb = 0;
  for (int i = len - 1; i >= 0; i--) {
    if (sa == 0 && a[i] != 0) sa = (a[i] > 0) ? 1 : -1;
    if (sb == 0 && b[i] != 0) sb = (b[i] > 0) ? 1 : -1;
    if (sa != 0 && sb != 0) break;
  }
  if (sa == 0 && sb == 0) return 0;
  if (sa == 0) return -1;
  if (sb == 0) return 1;

  for (int i = len - 1; i >= 0; i--) {
    int va = a[i] * sa, vb = b[i] * sb;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

void treg_alu::div(treg_value &dst_quot, treg_value &dst_rem,
                   const treg_value &a, const treg_value &b) {
  int ta[TRITS], tb[TRITS];
  unpack(a, ta);
  unpack(b, tb);

  int rem[TRITS], rp[TRITS], rn[TRITS];
  int quot[TRITS];

  for (int i = 0; i < TRITS; i++) {
    rem[i]  = 0;
    quot[i] = 0;
  }

  for (int k = TRITS - 1; k >= 0; k--) {
    /* shift remainder left by one trit (×3) and bring in next dividend trit */
    for (int i = TRITS - 1; i > 0; i--) rem[i] = rem[i - 1];
    rem[0] = ta[k];

    /* rp = rem - divisor (trial q = +1) */
    int carry_p = 0;
    for (int i = 0; i < TRITS; i++) {
      int s = rem[i] - tb[i] + carry_p;
      rp[i] = normalize_trit(s, &carry_p);
    }

    /* rn = rem + divisor (trial q = -1) */
    int carry_n = 0;
    for (int i = 0; i < TRITS; i++) {
      int s = rem[i] + tb[i] + carry_n;
      rn[i] = normalize_trit(s, &carry_n);
    }

    int cp = abs_compare_trits(rp, rem, TRITS);
    int cn = abs_compare_trits(rn, rem, TRITS);

    if (cp < 0 && abs_compare_trits(rp, rn, TRITS) <= 0) {
      quot[k] = 1;
      for (int i = 0; i < TRITS; i++) rem[i] = rp[i];
    } else if (cn < 0) {
      quot[k] = -1;
      for (int i = 0; i < TRITS; i++) rem[i] = rn[i];
    } else if (cp == 0 || cn == 0) {
      /* Tie: |rem| = d/2. Pick keep vs flip by the sign of the highest
       * non-zero remaining dividend trit (it dominates the remaining sum
       * in balanced ternary). Flip iff that sign matches rem. */
      int remaining_sign = 0;
      for (int j = k - 1; j >= 0; j--) {
        if (ta[j] != 0) { remaining_sign = ta[j]; break; }
      }
      if (cp == 0 && remaining_sign > 0) {
        quot[k] = 1;
        for (int i = 0; i < TRITS; i++) rem[i] = rp[i];
      } else if (cn == 0 && remaining_sign < 0) {
        quot[k] = -1;
        for (int i = 0; i < TRITS; i++) rem[i] = rn[i];
      } else {
        quot[k] = 0;
      }
    } else {
      quot[k] = 0;
    }
  }

  /* Normalize remainder to r ∈ (-|b|/2, |b|/2].  See ternary.c::t_div for the
   * rationale: at the |r| = |b|/2 tie, both signs are valid balanced-mod
   * results, but the modular-arithmetic invariant requires a fixed choice. */
  {
    int two_rem[TRITS];
    int carry = 0;
    for (int i = 0; i < TRITS; i++) {
      int s = rem[i] + rem[i] + carry;
      two_rem[i] = normalize_trit(s, &carry);
    }
    if (abs_compare_trits(two_rem, tb, TRITS) == 0) {
      int rem_sign = 0;
      for (int i = TRITS - 1; i >= 0; i--) {
        if (rem[i] != 0) { rem_sign = rem[i]; break; }
      }
      if (rem_sign < 0) {
        int b_sign = 0;
        for (int i = TRITS - 1; i >= 0; i--) {
          if (tb[i] != 0) { b_sign = tb[i]; break; }
        }
        carry = 0;
        for (int i = 0; i < TRITS; i++) {
          int s = rem[i] + b_sign * tb[i] + carry;
          rem[i] = normalize_trit(s, &carry);
        }
        carry = -b_sign;
        for (int i = 0; i < TRITS && carry != 0; i++) {
          int s = quot[i] + carry;
          quot[i] = normalize_trit(s, &carry);
        }
      }
    }
  }

  repack(dst_quot, quot);
  repack(dst_rem, rem);
}

void treg_alu::div_fixed(treg_value &dst, const treg_value &a,
                          const treg_value &b, int int_trits) {
  /*
   * Fixed-point division: dst = a / b, where both operands and the result
   * are in the same fixed-point format (int_trits integer trits).
   *
   * Conceptually: dst_raw = (a_raw * 3^frac_trits) / b_raw.
   * Since a_raw * 3^frac_trits overflows 120 trits, we use a 240-trit
   * extended dividend and run balanced ternary long division.
   */
  int frac_trits = TRITS - int_trits;

  int tnum[TRITS], tden[TRITS];
  unpack(a, tnum);
  unpack(b, tden);

  /* extended dividend: frac_trits zeros, then the original numerator */
  int ta_ext[DOUBLE_TRITS];
  for (int i = 0; i < frac_trits; i++)
    ta_ext[i] = 0;
  for (int i = 0; i < TRITS; i++)
    ta_ext[frac_trits + i] = tnum[i];
  for (int i = frac_trits + TRITS; i < DOUBLE_TRITS; i++)
    ta_ext[i] = 0;

  int qtrits[TRITS];
  int rr[TRITS], rp[TRITS], rn[TRITS];
  for (int i = 0; i < TRITS; i++) { qtrits[i] = 0; rr[i] = 0; }

  for (int k = DOUBLE_TRITS - 1; k >= 0; k--) {
    for (int i = TRITS - 1; i > 0; i--) rr[i] = rr[i - 1];
    rr[0] = ta_ext[k];

    int carry_p = 0;
    for (int i = 0; i < TRITS; i++) {
      int s = rr[i] - tden[i] + carry_p;
      rp[i] = normalize_trit(s, &carry_p);
    }
    int carry_n = 0;
    for (int i = 0; i < TRITS; i++) {
      int s = rr[i] + tden[i] + carry_n;
      rn[i] = normalize_trit(s, &carry_n);
    }

    int cp = abs_compare_trits(rp, rr, TRITS);
    int cn = abs_compare_trits(rn, rr, TRITS);

    int qt = 0;
    if (cp < 0 && abs_compare_trits(rp, rn, TRITS) <= 0) {
      qt = 1;
      for (int i = 0; i < TRITS; i++) rr[i] = rp[i];
    } else if (cn < 0) {
      qt = -1;
      for (int i = 0; i < TRITS; i++) rr[i] = rn[i];
    } else if (cp == 0 || cn == 0) {
      /* Tie: |rr| = d/2. Flip (qt=±1) and keep (qt=0) yield the same |rr|,
       * but only one choice lets an exact division terminate with rr=0.
       * Rule: flip iff the sum of the remaining dividend trits has the
       * same sign as rr. The highest non-zero remaining trit dominates
       * that sum in balanced ternary, so its sign is enough. */
      int remaining_sign = 0;
      for (int j = k - 1; j >= 0; j--) {
        if (ta_ext[j] != 0) { remaining_sign = ta_ext[j]; break; }
      }
      if (cp == 0 && remaining_sign > 0) {
        qt = 1;
        for (int i = 0; i < TRITS; i++) rr[i] = rp[i];
      } else if (cn == 0 && remaining_sign < 0) {
        qt = -1;
        for (int i = 0; i < TRITS; i++) rr[i] = rn[i];
      }
    }

    if (k < TRITS)
      qtrits[k] = qt;
  }

  repack(dst, qtrits);
}

void treg_alu::div_small(treg_value &dst, const treg_value &a, int k) {
  int trits[TRITS];
  unpack(a, trits);

  int rem = 0;
  for (int i = TRITS - 1; i >= 0; i--) {
    int d = rem * 3 + trits[i];
    trits[i] = d / k;
    rem = d - trits[i] * k;
  }

  for (int i = 0; i < TRITS - 1; i++) {
    int carry;
    trits[i] = normalize_trit(trits[i], &carry);
    trits[i + 1] += carry;
  }
  int discard;
  trits[TRITS - 1] = normalize_trit(trits[TRITS - 1], &discard);

  repack(dst, trits);
}

void treg_alu::mul_small(treg_value &dst, const treg_value &a, int k) {
  int trits[TRITS];
  unpack(a, trits);

  int carry = 0;
  for (int i = 0; i < TRITS; i++) {
    int d = trits[i] * k + carry;
    trits[i] = normalize_trit(d, &carry);
  }

  repack(dst, trits);
}

/* ================================================================== */
/*  Shifts and masking                                                 */
/* ================================================================== */

void treg_alu::shl(treg_value &dst, const treg_value &src, int n) {
  int trits[TRITS];
  unpack(src, trits);

  if (n >= TRITS) {
    for (int i = 0; i < TRITS; i++) trits[i] = 0;
  } else if (n > 0) {
    for (int i = TRITS - 1; i >= n; i--)
      trits[i] = trits[i - n];
    for (int i = 0; i < n; i++)
      trits[i] = 0;
  }

  repack(dst, trits);
}

void treg_alu::shr(treg_value &dst, const treg_value &src, int n) {
  int trits[TRITS];
  unpack(src, trits);

  if (n >= TRITS) {
    for (int i = 0; i < TRITS; i++) trits[i] = 0;
  } else if (n > 0) {
    for (int i = 0; i < TRITS - n; i++)
      trits[i] = trits[i + n];
    for (int i = TRITS - n; i < TRITS; i++)
      trits[i] = 0;
  }

  repack(dst, trits);
}

void treg_alu::mask40(treg_value &r) {
  r.h[1] = HALF_BIAS;
  r.h[2] = HALF_BIAS;
}

void treg_alu::mask80(treg_value &r) {
  r.h[2] = HALF_BIAS;
}

/* ================================================================== */
/*  Comparison                                                         */
/* ================================================================== */

int treg_alu::cmp(const treg_value &a, const treg_value &b) {
  for (int half = HALVES - 1; half >= 0; half--) {
    if (a.h[half] > b.h[half]) return 1;
    if (a.h[half] < b.h[half]) return -1;
  }
  return 0;
}

int treg_alu::sign(const treg_value &r) {
  for (int half = HALVES - 1; half >= 0; half--) {
    if (r.h[half] > HALF_BIAS) return 1;
    if (r.h[half] < HALF_BIAS) return -1;
  }
  return 0;
}

bool treg_alu::is_zero(const treg_value &r) {
  return r.h[0] == HALF_BIAS && r.h[1] == HALF_BIAS && r.h[2] == HALF_BIAS;
}

/* ================================================================== */
/*  Balanced3 entry/exit                                               */
/* ================================================================== */

void treg_alu::load_int(treg_value &dst, long long val) {
  int trits[TRITS];
  for (int i = 0; i < TRITS; i++) trits[i] = 0;

  bool is_neg = val < 0;
  unsigned long long mag;
  if (val < 0)
    mag = static_cast<unsigned long long>(-(val + 1)) + 1;
  else
    mag = static_cast<unsigned long long>(val);

  /* magnitude to standard ternary {0,1,2} */
  for (int i = 0; i < TRITS && mag != 0; i++) {
    trits[i] = static_cast<int>(mag % 3);
    mag /= 3;
  }

  /* balance: {0,1,2} → {-1,0,+1} with carry */
  int carry = 0;
  for (int i = 0; i < TRITS; i++) {
    int d = trits[i] + carry;
    if (d > 1) { trits[i] = d - 3; carry = 1; }
    else       { trits[i] = d;      carry = 0; }
  }

  /* apply sign */
  if (is_neg)
    for (int i = 0; i < TRITS; i++) trits[i] = -trits[i];

  repack(dst, trits);
  mask40(dst);
}

long long treg_alu::store_int(const treg_value &src) {
  int trits[TRITS];
  unpack(src, trits);

  long long result = 0;
  for (int i = TRITS - 1; i >= 0; i--) {
    if (result > 3074457345618258602LL || result < -3074457345618258602LL)
      return (result > 0) ? 9223372036854775807LL : (-9223372036854775807LL - 1);
    result = result * 3 + trits[i];
  }
  return result;
}

/* ================================================================== */
/*  Posit3 helpers                                                      */
/* ================================================================== */

int treg_alu::extract_int(const treg_value &src, int int_trits) {
  /*
   * The integer trits occupy positions [TRITS-int_trits .. TRITS-1].
   * Evaluate them via Horner's method to get a plain int.
   */
  int result = 0;
  for (int i = TRITS - 1; i >= TRITS - int_trits; i--) {
    result = result * 3 + get_trit(src, i);
  }
  return result;
}

/*
 * Precomputed 1/ln(3) as a fixed-point balanced ternary constant.
 *
 * 1/ln(3) ≈ 0.91023922662683739...
 *
 * We compute this once by converting the constant to balanced ternary
 * using the greedy MST-first extraction algorithm (the same approach
 * as t_load_double in the RTS, but done at static init time for a
 * known constant).
 *
 * The computation below uses integer arithmetic only: we scale the
 * constant by 3^frac_trits and perform balanced ternary conversion.
 */

/*
 * Build 1/ln(3) by greedy extraction using scaled integer arithmetic.
 *
 * We represent 1/ln(3) as a ratio of two large integers and extract
 * trits from MST to LST.  Since we only need ~108 fractional trits
 * and we have exact rational arithmetic (well, we approximate with
 * a truncated decimal), we use a different approach: hardcode the
 * first ~60 balanced ternary trits, which gives us more than enough
 * precision for the atanh series.
 *
 * 1/ln(3) in balanced ternary (MST first, fixed-point with 0 integer trits):
 * +1, 0, -1, 0, +1, 0, -1, +1, -1, 0, +1, -1, +1, 0, +1, -1, +1, -1, ...
 *
 * However, we use the function-static pattern to compute it once.
 */
const treg_value &treg_alu::inv_ln3() {
  static bool inited = false;
  static treg_value val;

  if (!inited) {
    /*
     * Compute 1/ln(3) in fixed-point balanced ternary.
     *
     * Strategy: compute ln(3) first via atanh series, then invert.
     * ln(3) = 2·atanh(1/2)  [since (3-1)/(3+1) = 1/2]
     *
     * 1/2 in our fixed-point format: we load the integer 1, then
     * divide by 2 using div_small (which is a binary bridge but only
     * for the constant 2, a small binary integer used as a divisor).
     */

    /* half = 1/2 in fixed-point ternary */
    treg_value half;
    clear(half);
    set_trit(half, TRITS - INT_TRITS, 1);  /* integer part = 1 */
    div_small(half, half, 2);               /* 1/2 */

    /* ln3 = 2 · atanh(1/2) */
    treg_value ln3;
    atanh_series(ln3, half, INT_TRITS);
    add(ln3, ln3, ln3);  /* ×2 */

    /* invert: val = 1 / ln3 via fixed-point division */
    treg_value one;
    clear(one);
    set_trit(one, TRITS - INT_TRITS, 1);  /* 1.0 in fixed-point */

    div_fixed(val, one, ln3, INT_TRITS);

    inited = true;
  }
  return val;
}

const treg_value &treg_alu::log3_of_10() {
  static bool inited = false;
  static treg_value val;

  if (!inited) {
    /*
     * log₃(10) = 2 + log₃(10/9)
     * log₃(10/9) = 2·atanh((10/9 - 1)/(10/9 + 1)) / ln(3)
     *            = 2·atanh(1/19) · inv_ln3
     */
    int frac_trits = TRITS - INT_TRITS;

    /* z = 1/19 in fixed-point */
    treg_value z;
    clear(z);
    set_trit(z, frac_trits, 1);  /* 1.0 */
    div_small(z, z, 19);

    /* atanh(1/19) */
    treg_value atanh_z;
    atanh_series(atanh_z, z, INT_TRITS);

    /* 2·atanh(1/19) · inv_ln3 = log₃(10/9) */
    treg_value two_atanh;
    add(two_atanh, atanh_z, atanh_z);
    treg_value log3_frac;
    mul_fixed(log3_frac, two_atanh, inv_ln3(), INT_TRITS);

    /* log₃(10) = 2 + log₃(10/9) */
    treg_value two_fp;
    clear(two_fp);
    load_int(two_fp, 2);
    shl(two_fp, two_fp, frac_trits);
    add(val, two_fp, log3_frac);

    inited = true;
  }
  return val;
}

void treg_alu::atanh_series(treg_value &dst, const treg_value &z, int int_trits) {
  /*
   * atanh(z) = z + z³/3 + z⁵/5 + z⁷/7 + ...
   *
   * Convergent for |z| < 1.  In our use case z = (m-1)/(m+1) where
   * m ∈ [1,3), so z ∈ [0, 0.5), well within the convergence radius.
   *
   * All arithmetic is fixed-point with int_trits integer trits.
   */

  /* z² (fixed-point) */
  treg_value z2;
  mul_fixed(z2, z, z, int_trits);

  /* term = z, sum = z */
  treg_value term, sum;
  copy(term, z);
  copy(sum, z);

  /* series: add z^(2k+1)/(2k+1) for k = 1,2,...
   * For z=0.5 (used in ln(3) = 2·atanh(0.5)), we need ~85 terms to reach
   * 108-trit precision.  Early-exit once term underflows to zero. */
  for (int k = 1; k < 90; k++) {
    mul_fixed(term, term, z2, int_trits);  /* term *= z² */
    if (is_zero(term)) break;
    treg_value t;
    div_small(t, term, 2 * k + 1);        /* t = term / (2k+1) */
    add(sum, sum, t);
  }

  copy(dst, sum);
}

/* ================================================================== */
/*  Posit3 entry: parse_decimal                                         */
/* ================================================================== */

void treg_alu::parse_decimal(treg_value &dst, const char *str, int int_trits) {
  /*
   * Parse a decimal string [+-]digits[.digits][Ee[+-]digits] into
   * fixed-point balanced ternary with int_trits integer trits.
   *
   * Algorithm:
   *   - Parse the integer part: multiply accumulator by 10, add digit.
   *   - Parse the fractional part: same, but track the power of 10.
   *   - Parse optional exponent (E/e): adjust effective power of 10.
   *   - Combine: result = (int_part * 10^frac_digits + frac_part)
   *              / 10^(frac_digits - exponent)
   *   - All arithmetic in balanced ternary.
   */
  const char *p = str;

  /* skip sign (handled by caller) */
  if (*p == '+' || *p == '-') p++;

  /*
   * Limit total significant digits parsed to avoid overflowing the
   * 120-trit register.  120 balanced ternary trits ≈ 57 decimal digits;
   * we cap at 50 to leave margin for the mantissa combination
   * (int_part * 10^frac_digits + frac_part).
   */
  static constexpr int MAX_SIG_DIGITS = 57;  /* floor(120 * log10(3)) */
  int sig_digits = 0;  /* significant digits consumed so far */
  int leading = 1;     /* still skipping leading zeros */

  /* parse integer part */
  treg_value int_part;
  clear(int_part);
  while (*p && *p != '.' && *p != 'E' && *p != 'e') {
    if (!std::isdigit(static_cast<unsigned char>(*p))) break;
    int digit = *p - '0';
    if (digit != 0) leading = 0;
    if (!leading) sig_digits++;
    if (sig_digits <= MAX_SIG_DIGITS) {
      mul_small(int_part, int_part, 10);
      treg_value d;
      clear(d);
      load_int(d, digit);
      add(int_part, int_part, d);
    }
    /* digits beyond MAX_SIG_DIGITS in the integer part are lost,
     * but those digits represent precision beyond what the format
     * can store anyway */
    p++;
  }

  /* parse fractional part */
  treg_value frac_part;
  clear(frac_part);
  int frac_digits = 0;
  if (*p == '.') {
    p++;
    while (*p && *p != 'E' && *p != 'e') {
      if (!std::isdigit(static_cast<unsigned char>(*p))) break;
      int digit = *p - '0';
      if (digit != 0) leading = 0;
      if (!leading) sig_digits++;
      if (sig_digits <= MAX_SIG_DIGITS) {
        mul_small(frac_part, frac_part, 10);
        treg_value d;
        clear(d);
        load_int(d, digit);
        add(frac_part, frac_part, d);
        frac_digits++;
      }
      p++;
    }
  }

  /* parse optional exponent */
  int exponent = 0;
  if (*p == 'E' || *p == 'e') {
    p++;
    int exp_sign = 1;
    if (*p == '-') { exp_sign = -1; p++; }
    else if (*p == '+') { p++; }
    while (*p && std::isdigit(static_cast<unsigned char>(*p))) {
      exponent = exponent * 10 + (*p - '0');
      p++;
    }
    exponent *= exp_sign;
  }

  /*
   * The value is: (int_part + frac_part / 10^frac_digits) * 10^exponent
   *
   * Rewrite as a single fraction to avoid intermediate divisions:
   *   value = (int_part * 10^frac_digits + frac_part) / 10^(frac_digits - exponent)
   *
   * Let mantissa = int_part * 10^frac_digits + frac_part  (ternary integer)
   * Let net_exp  = frac_digits - exponent
   *
   * If net_exp > 0: value = mantissa / 10^net_exp
   * If net_exp < 0: value = mantissa * 10^(-net_exp)
   * If net_exp == 0: value = mantissa
   */
  treg_value mantissa;
  copy(mantissa, int_part);
  for (int i = 0; i < frac_digits; i++)
    mul_small(mantissa, mantissa, 10);
  add(mantissa, mantissa, frac_part);

  int net_exp = frac_digits - exponent;

  int frac_trit_count = TRITS - int_trits;

  if (net_exp == 0) {
    /* mantissa is an integer; place into fixed-point.
     * Mantissa may exceed INT_TRITS, so use extended shift. */
    int tm[TRITS];
    unpack(mantissa, tm);
    int ext[DOUBLE_TRITS];
    for (int i = 0; i < DOUBLE_TRITS; i++) ext[i] = 0;
    for (int i = 0; i < TRITS; i++)
      ext[frac_trit_count + i] = tm[i];
    /* extract the window [0..TRITS-1] */
    int win[TRITS];
    for (int i = 0; i < TRITS; i++) win[i] = ext[i];
    repack(dst, win);
    return;
  }

  /* build 10^|net_exp| in ternary */
  treg_value power10;
  clear(power10);
  load_int(power10, 1);
  int abs_net = (net_exp > 0) ? net_exp : -net_exp;
  for (int i = 0; i < abs_net; i++)
    mul_small(power10, power10, 10);

  if (net_exp > 0) {
    /* value = mantissa / 10^net_exp
     * = (mantissa * 3^frac_trit_count) / power10
     * Use extended 240-trit dividend to avoid overflow. */
    div_fixed(dst, mantissa, power10, int_trits);
  } else {
    /* net_exp < 0: value = mantissa * 10^(-net_exp), then to fixed-point */
    treg_value lo, hi;
    mul(lo, hi, mantissa, power10);
    /* place product into fixed-point via extended shift */
    int tlo[TRITS], thi[TRITS];
    unpack(lo, tlo);
    unpack(hi, thi);
    int ext[DOUBLE_TRITS];
    for (int i = 0; i < TRITS; i++) ext[i] = tlo[i];
    for (int i = 0; i < TRITS; i++) ext[TRITS + i] = thi[i];
    /* shift left by frac_trit_count and extract bottom TRITS */
    int win[TRITS];
    for (int i = 0; i < TRITS; i++)
      win[i] = (frac_trit_count + i < DOUBLE_TRITS) ? ext[frac_trit_count + i] : 0;
    repack(dst, win);
  }
}

/* ================================================================== */
/*  Posit3 entry: encode_log                                            */
/* ================================================================== */

void treg_alu::encode_log_posit3(treg_value &dst, const treg_value &L,
                          int sign_val, int int_trits) {
  /* zero */
  if (sign_val == 0) {
    clear(dst);
    return;
  }

  /* extract integer part of L */
  int L_int = extract_int(L, int_trits);

  /* decompose L_int = regime * GROWTH + exp_field, exp_field in [-4,+4] */
  int regime = L_int / POSIT3_GROWTH;
  int exp_field = L_int - regime * POSIT3_GROWTH;
  while (exp_field > 4)  { regime++; exp_field -= POSIT3_GROWTH; }
  while (exp_field < -4) { regime--; exp_field += POSIT3_GROWTH; }

  int abs_regime = (regime >= 0) ? regime : -regime;
  if (abs_regime >= POSIT3_REGIME_MAX) {
    /* Saturate at the dynamic-range boundary.  Overflow -> MAX/MIN finite;
     * underflow -> MIN_POS_FIN/MAX_NEG_FIN (just above/below zero-packed).
     * Posit arithmetic rounds to the nearest finite -- never flush to zero. */
    if (regime > 0) {
      /* overflow */
      if (sign_val > 0) { dst.h[0] = HALF_MAX - 1; dst.h[1] = HALF_MAX; }
      else              { dst.h[0] = 1;             dst.h[1] = 0;         }
    } else {
      /* underflow: one ULP away from zero (pack(HALF_BIAS +/- 1, HALF_BIAS)) */
      if (sign_val > 0) { dst.h[0] = HALF_BIAS + 1; dst.h[1] = HALF_BIAS; }
      else              { dst.h[0] = HALF_BIAS - 1; dst.h[1] = HALF_BIAS; }
    }
    dst.h[2] = HALF_BIAS;
    return;
  }

  /* build trit pattern */
  clear(dst);
  int cursor = POSIT3_TRITS - 1;

  set_trit(dst, cursor--, 1);  /* MST = +1 */

  /* regime run + terminator */
  if (regime > 0) {
    for (int i = 0; i < regime && cursor >= 0; i++)
      set_trit(dst, cursor--, 1);
    if (cursor >= 0) set_trit(dst, cursor--, 0);
  } else if (regime < 0) {
    for (int i = 0; i < -regime && cursor >= 0; i++)
      set_trit(dst, cursor--, -1);
    if (cursor >= 0) set_trit(dst, cursor--, 0);
  } else {
    if (cursor >= 0) set_trit(dst, cursor--, 0);
  }

  /* exponent (2 trits, balanced) */
  int r0 = exp_field % 3;
  if (r0 > 1) r0 -= 3;
  if (r0 < -1) r0 += 3;
  int r1 = (exp_field - r0) / 3;
  if (r1 > 1) r1 -= 3;
  if (r1 < -1) r1 += 3;
  if (cursor >= 0) set_trit(dst, cursor--, r1);
  if (cursor >= 0) set_trit(dst, cursor--, r0);

  /* fraction trits from L's fractional part */
  int frac_src = TRITS - int_trits - 1;  /* first frac trit below integer part */
  for (int i = cursor; i >= 0 && frac_src >= 0; i--, frac_src--)
    set_trit(dst, i, get_trit(L, frac_src));

  mask80(dst);

  /* apply sign */
  if (sign_val < 0)
    neg(dst, dst);
}

/* ================================================================== */
/*  Posit3 entry: load_posit3                                            */
/* ================================================================== */

void treg_alu::load_posit3(treg_value &dst, const char *str) {
  if (!str || !*str) {
    clear(dst);
    return;
  }

  /* determine sign */
  const char *p = str;
  int sgn = 1;
  if (*p == '-')      { sgn = -1; p++; }
  else if (*p == '+') { p++; }

  /* check for zero: all digits are 0 and optionally a decimal point */
  {
    const char *q = p;
    bool all_zero = true;
    while (*q) {
      if (*q != '0' && *q != '.') { all_zero = false; break; }
      q++;
    }
    if (all_zero) {
      clear(dst);
      return;
    }
  }

  /*
   * Extract decimal exponent (e.g. "17.89712e-35" → exp_decimal = -35,
   * mantissa_str = "17.89712") so that parse_decimal only handles the
   * mantissa.  The exponent is applied in the logarithmic domain:
   *   L = log₃(mantissa) + exp_decimal × log₃(10)
   */
  int exp_decimal = 0;
  std::string mantissa_str(str);
  {
    auto epos = mantissa_str.find_first_of("Ee");
    if (epos != std::string::npos) {
      const char *ep = str + epos + 1;
      int esign = 1;
      if (*ep == '-') { esign = -1; ep++; }
      else if (*ep == '+') { ep++; }
      while (*ep >= '0' && *ep <= '9')
        exp_decimal = exp_decimal * 10 + (*ep++ - '0');
      exp_decimal *= esign;
      mantissa_str.erase(epos);
    }
  }

  /*
   * Parse mantissa → fixed-point ternary magnitude.
   */
  treg_value magnitude;
  parse_decimal(magnitude, mantissa_str.c_str(), INT_TRITS);

  /* if caller passed a negative string, make magnitude positive
   * (parse_decimal ignores sign, load_int loaded unsigned digits) */
  if (sign(magnitude) < 0)
    neg(magnitude, magnitude);

  /*
   * Normalise: find k such that magnitude = 3^k × m, m ∈ [1, 3).
   *
   * In balanced ternary fixed-point with INT_TRITS integer trits:
   *   - "1.0" has trit (TRITS - INT_TRITS) = +1 and all above = 0
   *   - "3.0" has trit (TRITS - INT_TRITS + 1) = +1 and all above = 0
   *
   * Comparing with 3.0: check if integer part >= 3 or < 1.
   * Multiply/divide by 3 = shift left/right by 1 trit.
   */
  treg_value one, three;
  clear(one);
  set_trit(one, TRITS - INT_TRITS, 1);  /* 1.0 */
  clear(three);
  set_trit(three, TRITS - INT_TRITS + 1, 1);  /* 3.0 */

  int k = 0;

  /* while magnitude >= 3.0: shift right (÷3), k++ */
  while (cmp(magnitude, three) >= 0) {
    shr(magnitude, magnitude, 1);
    k++;
    if (k > 800) break;  /* safety: overflow → NaR */
  }

  /* while magnitude < 1.0: shift left (×3), k-- */
  while (cmp(magnitude, one) < 0 && !is_zero(magnitude)) {
    shl(magnitude, magnitude, 1);
    k--;
    if (k < -800) break;
  }

  /*
   * Now magnitude = m ∈ [1, 3).
   * Compute log₃(m) = 2 · atanh((m-1)/(m+1)) / ln(3)
   *                  = 2 · atanh(z) · (1/ln(3))
   * where z = (m-1)/(m+1).
   */
  treg_value m_minus_1, m_plus_1;
  sub(m_minus_1, magnitude, one);
  add(m_plus_1, magnitude, one);

  /* z = (m-1)/(m+1): fixed-point division. */
  int frac_trits = TRITS - INT_TRITS;
  treg_value z;
  div_fixed(z, m_minus_1, m_plus_1, INT_TRITS);

  /* atanh(z) */
  treg_value atanh_z;
  atanh_series(atanh_z, z, INT_TRITS);

  /* 2 · atanh(z) */
  treg_value two_atanh;
  add(two_atanh, atanh_z, atanh_z);

  /* log₃(m) = 2·atanh(z) · (1/ln3) */
  treg_value log3_m;
  mul_fixed(log3_m, two_atanh, inv_ln3(), INT_TRITS);

  /* L = k + log₃(m): add k to the integer part */
  treg_value L;
  copy(L, log3_m);
  if (k != 0) {
    treg_value k_fp;
    clear(k_fp);
    treg_value k_int;
    load_int(k_int, static_cast<long long>(k));
    shl(k_fp, k_int, frac_trits);
    add(L, L, k_fp);
  }

  /* apply decimal exponent in log domain: L += exp_decimal × log₃(10) */
  if (exp_decimal != 0) {
    treg_value exp_contribution;
    treg_value exp_fp;
    clear(exp_fp);
    treg_value exp_int;
    load_int(exp_int, static_cast<long long>(exp_decimal));
    shl(exp_fp, exp_int, frac_trits);
    mul_fixed(exp_contribution, exp_fp, log3_of_10(), INT_TRITS);
    add(L, L, exp_contribution);
  }

  /* encode L + sign into posit3 format */
  encode_log_posit3(dst, L, sgn, INT_TRITS);
}

void treg_alu::load_posit3_from_balanced3(treg_value &dst, const treg_value &b3) {
  /*
   * Convert a balanced3 integer to posit3: value = sign × 3^L.
   * L = log₃(|integer|).
   *
   * Load the integer value into fixed-point, then normalise and compute
   * log₃ as in load_posit3.
   */
  if (is_zero(b3)) {
    clear(dst);
    return;
  }

  int sgn = sign(b3);
  treg_value magnitude;
  if (sgn < 0)
    neg(magnitude, b3);
  else
    copy(magnitude, b3);

  /* shift integer into fixed-point position: the balanced3 value sits
   * in h[0] (40 trits starting at position 0).  In fixed-point format,
   * the integer part occupies trits [TRITS-INT_TRITS .. TRITS-1].
   * We need to shift left by (TRITS - INT_TRITS) - 0 = frac_trits,
   * but the integer may exceed INT_TRITS trits.
   *
   * Simpler approach: just use normalisation (the same as load_posit3).
   */
  int frac_trits = TRITS - INT_TRITS;
  treg_value mag_fp;
  shl(mag_fp, magnitude, frac_trits);

  treg_value one, three;
  clear(one);
  set_trit(one, TRITS - INT_TRITS, 1);
  clear(three);
  set_trit(three, TRITS - INT_TRITS + 1, 1);

  int k = 0;
  while (cmp(mag_fp, three) >= 0) {
    shr(mag_fp, mag_fp, 1);
    k++;
    if (k > 800) break;
  }
  while (cmp(mag_fp, one) < 0 && !is_zero(mag_fp)) {
    shl(mag_fp, mag_fp, 1);
    k--;
    if (k < -800) break;
  }

  treg_value m_minus_1, m_plus_1;
  sub(m_minus_1, mag_fp, one);
  add(m_plus_1, mag_fp, one);

  treg_value z;
  div_fixed(z, m_minus_1, m_plus_1, INT_TRITS);

  treg_value atanh_z;
  atanh_series(atanh_z, z, INT_TRITS);

  treg_value two_atanh;
  add(two_atanh, atanh_z, atanh_z);

  treg_value log3_m;
  mul_fixed(log3_m, two_atanh, inv_ln3(), INT_TRITS);

  treg_value L;
  copy(L, log3_m);
  if (k != 0) {
    treg_value k_fp;
    clear(k_fp);
    treg_value k_int;
    load_int(k_int, static_cast<long long>(k));
    shl(k_fp, k_int, frac_trits);
    add(L, L, k_fp);
  }

  encode_log_posit3(dst, L, sgn, INT_TRITS);
}

/* ================================================================== */
/*  String conversion helpers                                          */
/* ================================================================== */

std::string treg_alu::balanced3_to_string(const treg_value &src) {
  return std::to_string(store_int(src));
}

/* ------------------------------------------------------------------ */
/*  decode_log — reverse of encode_log                                 */
/* ------------------------------------------------------------------ */

void treg_alu::decode_log_posit3(const treg_value &src, treg_value &L,
                          int &sign_out, bool &is_nar_out, int int_trits) {
  is_nar_out = false;

  /* zero: both halves at bias */
  if (src.h[0] == HALF_BIAS && src.h[1] == HALF_BIAS) {
    sign_out = 0;
    clear(L);
    return;
  }

  /* NaR: both halves at max or both at 0 */
  if ((src.h[0] == HALF_MAX && src.h[1] == HALF_MAX) ||
      (src.h[0] == 0 && src.h[1] == 0)) {
    is_nar_out = true;
    sign_out = (src.h[1] > HALF_BIAS ||
                (src.h[1] == HALF_BIAS && src.h[0] > HALF_BIAS)) ? 1 : -1;
    clear(L);
    return;
  }

  /* determine sign from MST (trit 79) and work with positive form */
  treg_value pos;
  copy(pos, src);
  mask80(pos);
  int mst = get_trit(pos, POSIT3_TRITS - 1);
  if (mst < 0) {
    sign_out = -1;
    neg(pos, pos);
    mask80(pos);
  } else {
    sign_out = 1;
  }

  /* skip MST (+1) */
  int cursor = POSIT3_TRITS - 2;

  /* read regime run */
  int regime = 0;
  int first = get_trit(pos, cursor);
  if (first == 1) {
    while (cursor >= 0 && get_trit(pos, cursor) == 1) {
      regime++;
      cursor--;
    }
    if (cursor >= 0) cursor--;  /* skip terminator */
  } else if (first == -1) {
    while (cursor >= 0 && get_trit(pos, cursor) == -1) {
      regime--;
      cursor--;
    }
    if (cursor >= 0) cursor--;  /* skip terminator */
  } else {
    cursor--;  /* regime = 0, this trit is the terminator */
  }

  /* read exponent (2 trits, MST first) */
  int e1 = 0, e0 = 0;
  if (cursor >= 0) e1 = get_trit(pos, cursor--);
  if (cursor >= 0) e0 = get_trit(pos, cursor--);
  int exp_field = e1 * 3 + e0;

  int L_int = regime * POSIT3_GROWTH + exp_field;

  /* build L as fixed-point: load integer part, then copy fraction trits */
  treg_value L_int_val;
  load_int(L_int_val, static_cast<long long>(L_int));
  int frac_trits = TRITS - int_trits;
  shl(L, L_int_val, frac_trits);

  /* fraction trits: from cursor downward in the posit3 → MST of L's fraction */
  int frac_dst = frac_trits - 1;
  for (int i = cursor; i >= 0 && frac_dst >= 0; i--, frac_dst--)
    set_trit(L, frac_dst, get_trit(pos, i));
}

/* ------------------------------------------------------------------ */
/*  ln3_const — precomputed ln(3) in fixed-point ternary               */
/* ------------------------------------------------------------------ */

const treg_value &treg_alu::ln3_const() {
  static bool inited = false;
  static treg_value val;

  if (!inited) {
    /* ln(3) = 2 · atanh(1/2) */
    treg_value half;
    clear(half);
    set_trit(half, TRITS - INT_TRITS, 1);
    div_small(half, half, 2);

    atanh_series(val, half, INT_TRITS);
    add(val, val, val);
    inited = true;
  }
  return val;
}

/* ------------------------------------------------------------------ */
/*  exp_series — exp(x) via Taylor series in ternary fixed-point       */
/* ------------------------------------------------------------------ */

void treg_alu::exp_series(treg_value &dst, const treg_value &x, int int_trits) {
  /*
   * exp(x) = 1 + x + x²/2! + x³/3! + ...
   *        = 1 + x·(1 + x/2·(1 + x/3·(1 + ...)))
   *
   * Direct accumulation: term_n = term_{n-1} * x / n
   */
  treg_value one_fp;
  clear(one_fp);
  set_trit(one_fp, TRITS - int_trits, 1);

  treg_value term, sum;
  copy(term, one_fp);
  copy(sum, one_fp);

  for (int n = 1; n < 60; n++) {
    mul_fixed(term, term, x, int_trits);
    div_small(term, term, n);
    if (is_zero(term)) break;
    add(sum, sum, term);
  }

  copy(dst, sum);
}

/* ------------------------------------------------------------------ */
/*  fixed_to_decimal — ternary fixed-point → decimal string            */
/* ------------------------------------------------------------------ */

std::string treg_alu::fixed_to_decimal(const treg_value &src,
                                       int int_trits, int decimal_digits) {
  /*
   * Integer part: extract via Horner's method → std::to_string.
   * Fractional part: repeatedly ×10, extract integer digit.
   */
  int int_val = extract_int(src, int_trits);
  bool negative = int_val < 0;
  if (negative) int_val = -int_val;

  std::string result = std::to_string(int_val);

  /* isolate fractional part: zero out integer trits */
  treg_value frac;
  copy(frac, src);
  if (negative) neg(frac, frac);
  for (int i = TRITS - int_trits; i < TRITS; i++)
    set_trit(frac, i, 0);

  /* If the fractional part is negative (due to balanced ternary
   * representation), adjust: frac = 1.0 - |frac|, int_val-- */
  if (sign(frac) < 0) {
    treg_value one_fp;
    clear(one_fp);
    set_trit(one_fp, TRITS - int_trits, 1);
    add(frac, frac, one_fp);
    if (int_val > 0) {
      int_val--;
      result = std::to_string(int_val);
    }
  }

  if (decimal_digits <= 0) return (negative ? "-" : "") + result;

  result += '.';

  for (int d = 0; d < decimal_digits; d++) {
    mul_small(frac, frac, 10);
    int digit = extract_int(frac, int_trits);
    if (digit < 0) digit = 0;
    if (digit > 9) digit = 9;
    result += static_cast<char>('0' + digit);
    /* zero out integer trits for next iteration */
    for (int i = TRITS - int_trits; i < TRITS; i++)
      set_trit(frac, i, 0);
    /* handle carry again */
    if (sign(frac) < 0) {
      treg_value one_fp;
      clear(one_fp);
      set_trit(one_fp, TRITS - int_trits, 1);
      add(frac, frac, one_fp);
      /* borrow from current digit — already emitted, so we adjust */
      if (digit > 0) {
        result.back() = static_cast<char>('0' + digit - 1);
      }
    }
  }

  /* trim trailing zeros */
  size_t last = result.find_last_not_of('0');
  if (last != std::string::npos && result[last] == '.') last--;
  result.erase(last + 1);

  return (negative ? "-" : "") + result;
}

/* ------------------------------------------------------------------ */
/*  posit3_to_string — packed posit3 → decimal string                    */
/* ------------------------------------------------------------------ */

std::string treg_alu::posit3_to_string(const treg_value &src) {
  int sgn;
  bool is_nar;
  treg_value L;

  decode_log_posit3(src, L, sgn, is_nar, INT_TRITS);

  if (sgn == 0) return "0";
  if (is_nar) return sgn > 0 ? "NaR" : "-NaR";

  /*
   * Scientific notation output: D.DDDe±EE
   *
   * 1. Compute dec_exp ≈ floor(L · log₁₀(3)).
   * 2. Reduce L' = L - dec_exp · log₃(10) so 3^L' ∈ [1, 10).
   * 3. Compute mantissa = 3^L', extract digits.
   * 4. Adjust mantissa/exponent if needed.
   */
  int frac_trits = TRITS - INT_TRITS;
  int L_int = extract_int(L, INT_TRITS);
  int dec_exp = 0;

  /* Approximate decimal exponent: log₁₀(3) ≈ 0.47712 */
  if (L_int > 0)
    dec_exp = static_cast<int>(static_cast<long long>(L_int) * 47712LL / 100000LL);
  else if (L_int < 0)
    dec_exp = static_cast<int>((static_cast<long long>(L_int) * 47712LL - 99999LL) / 100000LL);

  /* Reduce L' = L - dec_exp · log₃(10) */
  if (dec_exp != 0) {
    treg_value exp_fp;
    clear(exp_fp);
    load_int(exp_fp, static_cast<long long>(dec_exp));
    shl(exp_fp, exp_fp, frac_trits);
    treg_value exp_contribution;
    mul_fixed(exp_contribution, exp_fp, log3_of_10(), INT_TRITS);
    sub(L, L, exp_contribution);
  }

  /* Compute mantissa = 3^L' */
  int L_int2 = extract_int(L, INT_TRITS);

  treg_value L_frac;
  copy(L_frac, L);
  for (int i = frac_trits; i < TRITS; i++)
    set_trit(L_frac, i, 0);

  if (sign(L_frac) < 0) {
    treg_value one_fp;
    clear(one_fp);
    set_trit(one_fp, frac_trits, 1);
    add(L_frac, L_frac, one_fp);
    L_int2--;
  }

  treg_value f_ln3;
  mul_fixed(f_ln3, L_frac, ln3_const(), INT_TRITS);

  treg_value mantissa;
  exp_series(mantissa, f_ln3, INT_TRITS);

  if (L_int2 >= 0)
    shl(mantissa, mantissa, L_int2);
  else
    shr(mantissa, mantissa, -L_int2);

  /* Adjust mantissa to [1, 10): divide or multiply by 10 */
  int int_part = extract_int(mantissa, INT_TRITS);
  int safety = 20;
  while (int_part >= 10 && safety-- > 0) {
    div_small(mantissa, mantissa, 10);
    dec_exp++;
    int_part = extract_int(mantissa, INT_TRITS);
  }
  safety = 20;
  while (int_part <= 0 && !is_zero(mantissa) && safety-- > 0) {
    mul_small(mantissa, mantissa, 10);
    dec_exp--;
    int_part = extract_int(mantissa, INT_TRITS);
  }

  /* Convert mantissa to decimal string */
  std::string result = fixed_to_decimal(mantissa, INT_TRITS, 15);

  /* Strip trailing zeros after decimal point */
  auto dot = result.find('.');
  if (dot != std::string::npos) {
    auto last = result.find_last_not_of('0');
    if (last != std::string::npos && result[last] == '.') last--;
    result.erase(last + 1);
  }

  /* Append exponent if non-zero */
  if (dec_exp != 0) {
    result += "e";
    result += (dec_exp > 0 ? "+" : "");
    result += std::to_string(dec_exp);
  }

  if (sgn < 0) result = "-" + result;
  return result;
}


/* ================================================================== */
/*  Takum3: encode_log_takum3 (Hunhold Def. 2)                        */
/* ================================================================== */

static constexpr int takum3_pow3[] = { 1, 3, 9, 27, 81, 243 };

void treg_alu::encode_log_takum3(treg_value &dst, const treg_value &L,
                                 int sign_val, int int_trits) {
  if (sign_val == 0) {
    clear(dst);
    return;
  }

  int c = extract_int(L, int_trits);

  int R_bal, r, C_unsigned;

  if (c >= -1 && c <= 1) {
    R_bal = 0;
    r = 1;
    C_unsigned = c + 1;
  } else if (c >= 2) {
    r = 1;
    while (r < TAKUM3_MAX_R && c > (takum3_pow3[r + 1] - 1) / 2) r++;
    if (c > (takum3_pow3[r + 1] - 1) / 2) {
      /* overflow: saturate to max/min finite (not NaR) */
      if (sign_val > 0) { dst.h[0] = HALF_MAX - 1; dst.h[1] = HALF_MAX; }
      else              { dst.h[0] = 1;             dst.h[1] = 0;         }
      dst.h[2] = HALF_BIAS;
      return;
    }
    R_bal = r;
    C_unsigned = c - (takum3_pow3[r] + 1) / 2;
  } else {
    r = 1;
    while (r < TAKUM3_MAX_R && c < -(takum3_pow3[r + 1] - 1) / 2) r++;
    if (c < -(takum3_pow3[r + 1] - 1) / 2) {
      /* underflow: saturate to smallest finite (Takum paper Sec. 4.2).
       * MIN_POS_FIN: MST=+1, all others=-1. h[1]=2*3^39, h[0]=0.
       * MAX_NEG_FIN: trit-flip. h[1]=3^39-1, h[0]=HALF_MAX. */
      if (sign_val > 0) { dst.h[0] = 0ULL;     dst.h[1] = 8105110306037952534ULL; }
      else              { dst.h[0] = HALF_MAX; dst.h[1] = 4052555153018976266ULL; }
      dst.h[2] = HALF_BIAS;
      return;
    }
    R_bal = -r;
    C_unsigned = c + (takum3_pow3[r + 1] - 1) / 2;
  }

  /* build trit pattern */
  clear(dst);
  int cursor = TAKUM3_TRITS - 1;

  /* MST = +1 */
  set_trit(dst, cursor--, 1);

  /* R: 2 balanced trits encoding R_bal = R1*3 + R0 */
  int R0_trit = R_bal % 3;
  if (R0_trit > 1) R0_trit -= 3;
  if (R0_trit < -1) R0_trit += 3;
  int R1_trit = (R_bal - R0_trit) / 3;
  set_trit(dst, cursor--, R1_trit);
  set_trit(dst, cursor--, R0_trit);

  /* C: r trits, unsigned interpretation → balanced trits */
  {
    int c_trits[5];
    int tmp = C_unsigned;
    for (int i = 0; i < r; i++) {
      c_trits[i] = (tmp % 3) - 1;
      tmp /= 3;
    }
    for (int i = r - 1; i >= 0; i--)
      set_trit(dst, cursor--, c_trits[i]);
  }

  /* M: fraction trits from L's fractional part */
  int frac_src = TRITS - int_trits - 1;
  for (int i = cursor; i >= 0 && frac_src >= 0; i--, frac_src--)
    set_trit(dst, i, get_trit(L, frac_src));

  mask80(dst);

  if (sign_val < 0)
    neg(dst, dst);
}


/* ================================================================== */
/*  Takum3: decode_log_takum3 (Hunhold Def. 2)                        */
/* ================================================================== */

void treg_alu::decode_log_takum3(const treg_value &src, treg_value &L,
                                 int &sign_out, bool &is_nar_out, int int_trits) {
  is_nar_out = false;

  if (src.h[0] == HALF_BIAS && src.h[1] == HALF_BIAS) {
    sign_out = 0;
    clear(L);
    return;
  }

  if ((src.h[0] == HALF_MAX && src.h[1] == HALF_MAX) ||
      (src.h[0] == 0 && src.h[1] == 0)) {
    is_nar_out = true;
    sign_out = (src.h[1] > HALF_BIAS ||
                (src.h[1] == HALF_BIAS && src.h[0] > HALF_BIAS)) ? 1 : -1;
    clear(L);
    return;
  }

  treg_value pos;
  copy(pos, src);
  mask80(pos);
  int mst = get_trit(pos, TAKUM3_TRITS - 1);
  if (mst < 0) {
    sign_out = -1;
    neg(pos, pos);
    mask80(pos);
  } else {
    sign_out = 1;
  }

  /* Read R: 2 trits at positions 78 and 77 */
  int R1_trit = get_trit(pos, 78);
  int R0_trit = get_trit(pos, 77);
  int R_bal = R1_trit * 3 + R0_trit;

  int abs_R = (R_bal >= 0) ? R_bal : -R_bal;
  int r = (abs_R > 1) ? abs_R : 1;

  /* Read C: r trits from position 76 downward, MST first */
  int C_unsigned = 0;
  int cursor = 76;
  for (int i = r - 1; i >= 0; i--) {
    int ct = (cursor >= 0) ? get_trit(pos, cursor--) : 0;
    C_unsigned += (ct + 1) * takum3_pow3[i];
  }

  /* Compute c */
  int c;
  if (R_bal > 0)
    c = (takum3_pow3[r] + 1) / 2 + C_unsigned;
  else if (R_bal == 0)
    c = C_unsigned - 1;
  else
    c = -(takum3_pow3[r + 1] - 1) / 2 + C_unsigned;

  /* Build L as fixed-point */
  treg_value L_int_val;
  load_int(L_int_val, static_cast<long long>(c));
  int frac_trits = TRITS - int_trits;
  shl(L, L_int_val, frac_trits);

  int frac_dst = frac_trits - 1;
  for (int i = cursor; i >= 0 && frac_dst >= 0; i--, frac_dst--)
    set_trit(L, frac_dst, get_trit(pos, i));
}


/* ================================================================== */
/*  Takum3 entry: load_takum3                                          */
/* ================================================================== */

void treg_alu::load_takum3(treg_value &dst, const char *str) {
  if (!str || !*str) {
    clear(dst);
    return;
  }

  /* Reuse posit3's parsing pipeline (string → fixed-point L),
   * then encode with takum3 format instead of posit3. */
  const char *p = str;
  int sgn = 1;
  if (*p == '-')      { sgn = -1; p++; }
  else if (*p == '+') { p++; }

  {
    const char *q = p;
    bool all_zero = true;
    while (*q) {
      if (*q != '0' && *q != '.') { all_zero = false; break; }
      q++;
    }
    if (all_zero) {
      clear(dst);
      return;
    }
  }

  /*
   * Extract decimal exponent so that parse_decimal only handles the
   * mantissa.  The exponent is applied in the logarithmic domain:
   *   L = log₃(mantissa) + exp_decimal × log₃(10)
   */
  int exp_decimal = 0;
  std::string mantissa_str(str);
  {
    auto epos = mantissa_str.find_first_of("Ee");
    if (epos != std::string::npos) {
      const char *ep = str + epos + 1;
      int esign = 1;
      if (*ep == '-') { esign = -1; ep++; }
      else if (*ep == '+') { ep++; }
      while (*ep >= '0' && *ep <= '9')
        exp_decimal = exp_decimal * 10 + (*ep++ - '0');
      exp_decimal *= esign;
      mantissa_str.erase(epos);
    }
  }

  int frac_trits = TRITS - INT_TRITS;

  treg_value mag;
  parse_decimal(mag, mantissa_str.c_str(), INT_TRITS);

  if (sign(mag) < 0)
    neg(mag, mag);

  /* normalise to [1, 3) */
  treg_value one, three;
  clear(one);
  set_trit(one, TRITS - INT_TRITS, 1);
  clear(three);
  set_trit(three, TRITS - INT_TRITS + 1, 1);

  int k = 0;
  while (cmp(mag, three) >= 0) {
    shr(mag, mag, 1);
    k++;
    if (k > 800) break;
  }
  while (cmp(mag, one) < 0 && !is_zero(mag)) {
    shl(mag, mag, 1);
    k--;
    if (k < -800) break;
  }

  treg_value m_minus_1, m_plus_1;
  sub(m_minus_1, mag, one);
  add(m_plus_1, mag, one);

  treg_value z;
  div_fixed(z, m_minus_1, m_plus_1, INT_TRITS);

  treg_value atanh_z;
  atanh_series(atanh_z, z, INT_TRITS);

  treg_value two_atanh;
  add(two_atanh, atanh_z, atanh_z);

  treg_value log3_m;
  mul_fixed(log3_m, two_atanh, inv_ln3(), INT_TRITS);

  treg_value L;
  copy(L, log3_m);
  if (k != 0) {
    treg_value k_fp;
    clear(k_fp);
    treg_value k_int;
    load_int(k_int, static_cast<long long>(k));
    shl(k_fp, k_int, frac_trits);
    add(L, L, k_fp);
  }

  /* apply decimal exponent in log domain: L += exp_decimal × log₃(10) */
  if (exp_decimal != 0) {
    treg_value exp_contribution;
    treg_value exp_fp;
    clear(exp_fp);
    treg_value exp_int;
    load_int(exp_int, static_cast<long long>(exp_decimal));
    shl(exp_fp, exp_int, frac_trits);
    mul_fixed(exp_contribution, exp_fp, log3_of_10(), INT_TRITS);
    add(L, L, exp_contribution);
  }

  encode_log_takum3(dst, L, sgn, INT_TRITS);
}

void treg_alu::load_takum3_from_balanced3(treg_value &dst, const treg_value &b3) {
  if (is_zero(b3)) {
    clear(dst);
    return;
  }

  int sgn = sign(b3);
  treg_value magnitude;
  if (sgn < 0)
    neg(magnitude, b3);
  else
    copy(magnitude, b3);

  int frac_trits = TRITS - INT_TRITS;
  treg_value mag_fp;
  shl(mag_fp, magnitude, frac_trits);

  treg_value one, three;
  clear(one);
  set_trit(one, TRITS - INT_TRITS, 1);
  clear(three);
  set_trit(three, TRITS - INT_TRITS + 1, 1);

  int k = 0;
  while (cmp(mag_fp, three) >= 0) {
    shr(mag_fp, mag_fp, 1);
    k++;
    if (k > 800) break;
  }
  while (cmp(mag_fp, one) < 0 && !is_zero(mag_fp)) {
    shl(mag_fp, mag_fp, 1);
    k--;
    if (k < -800) break;
  }

  treg_value m_minus_1, m_plus_1;
  sub(m_minus_1, mag_fp, one);
  add(m_plus_1, mag_fp, one);

  treg_value z;
  div_fixed(z, m_minus_1, m_plus_1, INT_TRITS);

  treg_value atanh_z;
  atanh_series(atanh_z, z, INT_TRITS);

  treg_value two_atanh;
  add(two_atanh, atanh_z, atanh_z);

  treg_value log3_m;
  mul_fixed(log3_m, two_atanh, inv_ln3(), INT_TRITS);

  treg_value L;
  copy(L, log3_m);
  if (k != 0) {
    treg_value k_fp;
    clear(k_fp);
    treg_value k_int;
    load_int(k_int, static_cast<long long>(k));
    shl(k_fp, k_int, frac_trits);
    add(L, L, k_fp);
  }

  encode_log_takum3(dst, L, sgn, INT_TRITS);
}


/* ================================================================== */
/*  Takum3 string conversion: takum3_to_string                         */
/* ================================================================== */

std::string treg_alu::takum3_to_string(const treg_value &src) {
  int sgn;
  bool is_nar;
  treg_value L;

  decode_log_takum3(src, L, sgn, is_nar, INT_TRITS);

  if (sgn == 0) return "0";
  if (is_nar) return sgn > 0 ? "NaR" : "-NaR";

  /*
   * Same decimal conversion algorithm as posit3_to_string:
   * compute 3^L in ternary, extract decimal digits.
   */
  int frac_trits = TRITS - INT_TRITS;
  int L_int = extract_int(L, INT_TRITS);

  /* approximate decimal exponent */
  int dec_exp = 0;
  if (L_int > 0)
    dec_exp = static_cast<int>(static_cast<long long>(L_int) * 47712LL / 100000LL);
  else if (L_int < 0)
    dec_exp = static_cast<int>((static_cast<long long>(L_int) * 47712LL - 99999LL) / 100000LL);

  /* reduce: L' = L - dec_exp * log₃(10) */
  treg_value L_prime;
  copy(L_prime, L);
  if (dec_exp != 0) {
    treg_value dec_fp;
    treg_value dec_int;
    load_int(dec_int, static_cast<long long>(dec_exp));
    shl(dec_fp, dec_int, frac_trits);
    treg_value offset;
    mul_fixed(offset, dec_fp, log3_of_10(), INT_TRITS);
    sub(L_prime, L_prime, offset);
  }

  /* mantissa = 3^L': use exp(L' * ln(3)) */
  int L_prime_int = extract_int(L_prime, INT_TRITS);
  treg_value L_prime_int_val;
  load_int(L_prime_int_val, static_cast<long long>(L_prime_int));
  treg_value L_prime_int_fp;
  shl(L_prime_int_fp, L_prime_int_val, frac_trits);
  treg_value L_prime_frac;
  sub(L_prime_frac, L_prime, L_prime_int_fp);

  treg_value x_for_exp;
  mul_fixed(x_for_exp, L_prime_frac, ln3_const(), INT_TRITS);

  treg_value mantissa;
  exp_series(mantissa, x_for_exp, INT_TRITS);

  if (L_prime_int > 0)
    shl(mantissa, mantissa, L_prime_int);
  else if (L_prime_int < 0)
    shr(mantissa, mantissa, -L_prime_int);

  /* adjust mantissa into [1, 10) */
  treg_value ten;
  clear(ten);
  load_int(ten, 10);
  shl(ten, ten, frac_trits);

  treg_value one;
  clear(one);
  set_trit(one, TRITS - INT_TRITS, 1);

  int safety = 20;
  while (cmp(mantissa, ten) >= 0 && safety-- > 0) {
    div_small(mantissa, mantissa, 10);
    dec_exp++;
  }
  safety = 20;
  while (cmp(mantissa, one) < 0 && !is_zero(mantissa) && safety-- > 0) {
    mul_small(mantissa, mantissa, 10);
    dec_exp--;
  }

  /* extract integer part (leading digit) */
  treg_value int_part;
  shr(int_part, mantissa, frac_trits);
  int leading_digit = static_cast<int>(store_int(int_part));
  if (leading_digit < 1) leading_digit = 1;
  if (leading_digit > 9) leading_digit = 9;

  /* fractional part */
  treg_value frac_part;
  treg_value ld_fp;
  load_int(ld_fp, static_cast<long long>(leading_digit));
  shl(ld_fp, ld_fp, frac_trits);
  sub(frac_part, mantissa, ld_fp);

  /* if fraction went negative, adjust */
  if (sign(frac_part) < 0) {
    leading_digit--;
    if (leading_digit < 1) { leading_digit = 9; dec_exp--; }
    add(frac_part, frac_part, one);
  }

  std::string result;
  result += static_cast<char>('0' + leading_digit);

  /* extract fractional decimal digits */
  constexpr int FRAC_DIGITS = 36;
  if (!is_zero(frac_part)) {
    result += '.';
    int trailing = 0;
    std::string frac_str;

    for (int i = 0; i < FRAC_DIGITS; i++) {
      mul_small(frac_part, frac_part, 10);
      treg_value digit_val;
      shr(digit_val, frac_part, frac_trits);
      int digit = static_cast<int>(store_int(digit_val));

      treg_value digit_fp;
      shl(digit_fp, digit_val, frac_trits);
      sub(frac_part, frac_part, digit_fp);

      if (sign(frac_part) < 0) {
        digit--;
        add(frac_part, frac_part, one);
      }
      if (digit < 0) digit = 0;
      if (digit > 9) digit = 9;

      if (digit == 0) {
        trailing++;
      } else {
        for (int z = 0; z < trailing; z++) frac_str += '0';
        trailing = 0;
        frac_str += static_cast<char>('0' + digit);
      }

      if (is_zero(frac_part)) break;
    }

    result += frac_str;
    /* if the only digit after '.' was stripped, remove the dot */
    if (result.back() == '.') result.pop_back();
  }

  if (dec_exp != 0) {
    result += "e";
    result += (dec_exp > 0 ? "+" : "");
    result += std::to_string(dec_exp);
  }

  if (sgn < 0) result = "-" + result;
  return result;
}

} // cdk

#pragma once

#include <cstdint>

namespace cdk {

  /**
   * Ternary register value — layout-compatible with the RTS treg_t.
   *
   * Three 40-trit halves packed into unsigned 64-bit integers.
   * Total: 120 trits, 24 bytes.
   *
   * Encoding: each balanced trit t in {-1,0,+1} is stored as digit
   * d = t + 1 in {0,1,2}.  A 40-trit half is packed as:
   *   packed = sum_{i=0}^{39} d_i * 3^i
   *
   * Must match librts/src/ternary.h exactly.
   */
  struct treg_value {
    uint64_t h[3] = {0, 0, 0};

    /** Public accessors — client code should use these, not h[] directly. */
    uint64_t half(int i) const { return h[i]; }
    void set_half(int i, uint64_t v) { h[i] = v; }

    static constexpr int    HALVES     = 3;
    static constexpr int    HALF_TRITS = 40;
    static constexpr int    TRITS      = 120;
    static constexpr uint64_t HALF_MAX  = 12157665459056928800ULL; // 3^40 - 1
    static constexpr uint64_t HALF_BIAS =  6078832729528464400ULL; // (3^40 - 1) / 2
  };

} // cdk

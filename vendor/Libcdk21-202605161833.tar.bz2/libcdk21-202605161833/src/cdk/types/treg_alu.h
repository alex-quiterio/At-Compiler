#pragma once

#include <cdk/types/treg_value.h>
#include <cstdint>
#include <string>

namespace cdk {

  /**
   * Autonomous ternary ALU for compile-time operations.
   *
   * Operates directly on treg_value structs — no register file, no RTS
   * dependency.  All arithmetic is pure balanced ternary; binary values
   * (int, string) enter only at the conversion boundary.
   *
   * Mirrors the RTS ALU (librts/src/ternary.c) so that memory layouts
   * produced at compile time match what the RTS expects at run time.
   *
   * IMPORTANT: no floating-point (double/float) is used anywhere.
   */
  struct treg_alu {

    static constexpr int TRITS      = treg_value::TRITS;       // 120
    static constexpr int HALF_TRITS = treg_value::HALF_TRITS;  // 40
    static constexpr int HALVES     = treg_value::HALVES;       // 3

    static constexpr uint64_t HALF_MAX  = treg_value::HALF_MAX;
    static constexpr uint64_t HALF_BIAS = treg_value::HALF_BIAS;

    /** Posit3 constants. */
    static constexpr int POSIT3_TRITS      = 80;
    static constexpr int POSIT3_GROWTH     = 9;
    static constexpr int POSIT3_E_SIZE     = 2;
    static constexpr int POSIT3_REGIME_MAX = 78;
    static constexpr int INT_TRITS     = 12;

    /** Takum3 constants (Hunhold Def. 2). */
    static constexpr int TAKUM3_TRITS   = 80;
    static constexpr int TAKUM3_R_TRITS = 2;
    static constexpr int TAKUM3_MAX_R   = 4;

    /* ---------------------------------------------------------------- */
    /*  Powers of 3 (3^0 .. 3^40)                                       */
    /* ---------------------------------------------------------------- */

    static constexpr uint64_t pow3[HALF_TRITS + 1] = {
      1ULL, 3ULL, 9ULL, 27ULL, 81ULL, 243ULL, 729ULL, 2187ULL,
      6561ULL, 19683ULL, 59049ULL, 177147ULL, 531441ULL, 1594323ULL,
      4782969ULL, 14348907ULL, 43046721ULL, 129140163ULL, 387420489ULL,
      1162261467ULL, 3486784401ULL, 10460353203ULL, 31381059609ULL,
      94143178827ULL, 282429536481ULL, 847288609443ULL, 2541865828329ULL,
      7625597484987ULL, 22876792454961ULL, 68630377364883ULL,
      205891132094649ULL, 617673396283947ULL, 1853020188851841ULL,
      5559060566555523ULL, 16677181699666569ULL, 50031545098999707ULL,
      150094635296999121ULL, 450283905890997363ULL, 1350851717672992089ULL,
      4052555153018976267ULL, 12157665459056928801ULL,
    };

    /* ---------------------------------------------------------------- */
    /*  Core operations                                                  */
    /* ---------------------------------------------------------------- */

    /** Set all trits to zero (all halves to HALF_BIAS). */
    static void clear(treg_value &r);

    /** Negate: flip every trit. dst = HALF_MAX - src per half. */
    static void neg(treg_value &dst, const treg_value &src);

    /** Copy. */
    static void copy(treg_value &dst, const treg_value &src);

    /** Read one trit (returns -1, 0, or +1). */
    static int get_trit(const treg_value &r, int pos);

    /** Write one trit (-1, 0, or +1). */
    static void set_trit(treg_value &r, int pos, int trit);

    /** Unpack packed halves → flat balanced trit array (index 0 = LST). */
    static void unpack(const treg_value &r, int trits[TRITS]);

    /** Repack flat trit array → packed halves. */
    static void repack(treg_value &r, const int trits[TRITS]);

    /* ---------------------------------------------------------------- */
    /*  Arithmetic                                                       */
    /* ---------------------------------------------------------------- */

    /** Balanced ternary full adder: d = carry*3 + trit, trit ∈ {-1,0,+1}. */
    static int normalize_trit(int d, int *carry);

    /** dst = a + b (trit-by-trit with carry). */
    static void add(treg_value &dst, const treg_value &a, const treg_value &b);

    /** dst = a - b. */
    static void sub(treg_value &dst, const treg_value &a, const treg_value &b);

    /**
     * Multiply: dst_lo = low 120 trits, dst_hi = high 120 trits.
     * Schoolbook O(n²).
     */
    static void mul(treg_value &dst_lo, treg_value &dst_hi,
                    const treg_value &a, const treg_value &b);

    /**
     * Fixed-point multiply: dst = a × b, assuming both are fixed-point
     * with int_trits integer trits.  Returns the 120-trit middle portion
     * of the 240-trit full product (discards overflow and underflow).
     */
    static void mul_fixed(treg_value &dst, const treg_value &a,
                          const treg_value &b, int int_trits);

    /**
     * Divide: dst_quot = a / b, dst_rem = a mod b.
     * Balanced ternary restoring long division.
     */
    static void div(treg_value &dst_quot, treg_value &dst_rem,
                    const treg_value &a, const treg_value &b);

    /** Divide by small binary integer (O(n), for series terms). */
    static void div_small(treg_value &dst, const treg_value &a, int k);

    /** Multiply by small binary integer (O(n), for accumulation). */
    static void mul_small(treg_value &dst, const treg_value &a, int k);

    /* ---------------------------------------------------------------- */
    /*  Shifts and masking                                               */
    /* ---------------------------------------------------------------- */

    /** Shift left by n trits (× 3^n). */
    static void shl(treg_value &dst, const treg_value &src, int n);

    /** Shift right by n trits (÷ 3^n, truncating toward LST). */
    static void shr(treg_value &dst, const treg_value &src, int n);

    /** Mask to 40 trits (h[1]=h[2]=HALF_BIAS). */
    static void mask40(treg_value &r);

    /** Mask to 80 trits (h[2]=HALF_BIAS). */
    static void mask80(treg_value &r);

    /* ---------------------------------------------------------------- */
    /*  Comparison                                                       */
    /* ---------------------------------------------------------------- */

    /** Returns +1, 0, -1 (packed halves preserve ordering). */
    static int cmp(const treg_value &a, const treg_value &b);

    /** Sign of a register: +1, 0, -1. */
    static int sign(const treg_value &r);

    /** True if all trits are zero. */
    static bool is_zero(const treg_value &r);

    /* ---------------------------------------------------------------- */
    /*  Balanced3 entry/exit  (binary bridge: integers)                  */
    /* ---------------------------------------------------------------- */

    /** Convert binary integer to 120-trit balanced ternary (mask40). */
    static void load_int(treg_value &dst, long long val);

    /** Convert balanced ternary back to binary integer (Horner, 40 trits). */
    static long long store_int(const treg_value &src);

    /* ---------------------------------------------------------------- */
    /*  Posit3 entry  (binary bridge: decimal string)                     */
    /* ---------------------------------------------------------------- */

    /**
     * Convert a decimal string to an 80-trit logarithmic posit3.
     *
     * This is the ONLY entry point for real-valued data.  The algorithm:
     *   1. Parse the string into a balanced ternary fixed-point value.
     *   2. Normalise: find k such that value = 3^k × m, m ∈ [1, 3).
     *   3. Compute log₃(m) via atanh series, entirely in ternary.
     *   4. L = k + log₃(m).
     *   5. Encode L + sign into the packed posit3 format.
     *
     * Accepted formats: [+-]digits[.digits] (e.g. "3.14", "-0.001").
     */
    static void load_posit3(treg_value &dst, const char *str);

    /** Convert balanced3 integer to posit3 (value = 3^log₃(int)). */
    static void load_posit3_from_balanced3(treg_value &dst, const treg_value &b3);

    /* ---------------------------------------------------------------- */
    /*  Takum3 entry  (binary bridge: decimal string)                    */
    /* ---------------------------------------------------------------- */

    /**
     * Convert a decimal string to an 80-trit logarithmic takum3
     * (Hunhold Def. 2, fixed 2-trit regime).
     */
    static void load_takum3(treg_value &dst, const char *str);

    /** Convert balanced3 integer to takum3 (value = 3^log₃(int)). */
    static void load_takum3_from_balanced3(treg_value &dst, const treg_value &b3);

    /* ---------------------------------------------------------------- */
    /*  String conversion                                                */
    /* ---------------------------------------------------------------- */

    /** Convert a balanced3 value to its decimal integer string. */
    static std::string balanced3_to_string(const treg_value &src);

    /** Convert a posit3 value to its decimal real string. */
    static std::string posit3_to_string(const treg_value &src);

    /** Convert a takum3 value to its decimal real string. */
    static std::string takum3_to_string(const treg_value &src);

  private:

    /* --- Posit3 internal helpers --- */

    /**
     * Parse a decimal string into a ternary fixed-point register.
     * int_trits integer trits, remaining are fractional.
     */
    static void parse_decimal(treg_value &dst, const char *str, int int_trits);

    /**
     * Encode fixed-point L (in src) + sign into packed posit3 format.
     * sign: +1, -1, or 0 (zero).
     */
    static void encode_log_posit3(treg_value &dst, const treg_value &L,
                                  int sign, int int_trits);

    /**
     * Extract the integer part of a fixed-point ternary value
     * (top int_trits trits, evaluated via Horner's method).
     */
    static int extract_int(const treg_value &src, int int_trits);

    /**
     * Compute atanh(z) via balanced ternary series:
     *   atanh(z) = z + z³/3 + z⁵/5 + z⁷/7 + ...
     * Result and input are fixed-point with int_trits integer trits.
     */
    static void atanh_series(treg_value &dst, const treg_value &z, int int_trits);

    /**
     * Precomputed constant: 1/ln(3) in fixed-point ternary.
     * log₃(m) = 2 · atanh(z) · (1/ln3)
     */
    static const treg_value &inv_ln3();

    /**
     * Precomputed constant: log₃(10) in fixed-point ternary.
     * Used to apply decimal exponents in the logarithmic domain.
     */
    static const treg_value &log3_of_10();

    /**
     * Fixed-point division: dst = a / b, where a, b, dst are all
     * fixed-point with int_trits integer trits.  Uses 240-trit extended
     * dividend to avoid overflow.
     */
    static void div_fixed(treg_value &dst, const treg_value &a,
                          const treg_value &b, int int_trits);

    /**
     * Internal |a| vs |b| comparison on trit arrays.
     */
    static int abs_compare_trits(const int *a, const int *b, int len);

    /**
     * Decode a packed posit3 into sign and fixed-point L.
     * sign_out: +1, -1, or 0. is_nar_out: true if NaR.
     */
    static void decode_log_posit3(const treg_value &src, treg_value &L,
                                  int &sign_out, bool &is_nar_out, int int_trits);

    /**
     * Encode fixed-point L (in src) + sign into packed takum3 format
     * (Hunhold Def. 2, fixed 2-trit regime).
     */
    static void encode_log_takum3(treg_value &dst, const treg_value &L,
                                  int sign, int int_trits);

    /**
     * Decode a packed takum3 into sign and fixed-point L.
     * sign_out: +1, -1, or 0. is_nar_out: true if NaR.
     */
    static void decode_log_takum3(const treg_value &src, treg_value &L,
                                  int &sign_out, bool &is_nar_out, int int_trits);

    /**
     * Compute exp(x) in ternary fixed-point via Taylor series.
     * exp(x) = 1 + x + x²/2! + x³/3! + ...
     */
    static void exp_series(treg_value &dst, const treg_value &x, int int_trits);

    /** Precomputed constant: ln(3) in fixed-point ternary. */
    static const treg_value &ln3_const();

    /**
     * Convert a ternary fixed-point value to decimal string.
     * The value must be non-negative.
     */
    static std::string fixed_to_decimal(const treg_value &src,
                                        int int_trits, int decimal_digits);

  };

} // cdk

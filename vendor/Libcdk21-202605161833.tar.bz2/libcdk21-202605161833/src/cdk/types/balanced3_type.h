#pragma once

#include <string>
#include <cdk/types/basic_type.h>
#include <cdk/types/treg_value.h>
#include <cdk/types/treg_alu.h>

namespace cdk {

  /**
   * Balanced ternary integer type (40-trit, stored as treg_t).
   *
   * Usage in the scanner / parser:
   *   balanced3_type::value_type *v = new balanced3_type::value_type(42);
   *   // ... in parser: new balanced3_node(LINE, *$1); delete $1;
   */
  struct balanced3_type : public basic_type {

    struct value_type : public treg_value {

      /** Zero (all trits zero = bias in each half). */
      value_type() { treg_alu::clear(*this); }

      /** From raw halves. */
      value_type(uint64_t h0, uint64_t h1, uint64_t h2) { set_half(0, h0); set_half(1, h1); set_half(2, h2); }

      /**
       * From integer — the primary scanner constructor.
       * Converts a C integer to 40-trit balanced ternary via the ALU.
       */
      explicit value_type(int val) : value_type(static_cast<long long>(val)) {}
      explicit value_type(long long val) {
        treg_alu::load_int(*this, val);
      }

      /** Back to integer (Horner's method, 40 trits). */
      long long to_int64() const {
        return treg_alu::store_int(*this);
      }

      int to_int() const {
        long long v = to_int64();
        if (v > 2147483647LL) return 2147483647;
        if (v < -2147483648LL) return -2147483648;
        return static_cast<int>(v);
      }

      /** Decimal string representation of the integer value. */
      std::string to_string() const {
        return treg_alu::balanced3_to_string(*this);
      }

      bool operator==(const value_type &o) const {
        return half(0) == o.half(0) && half(1) == o.half(1) && half(2) == o.half(2);
      }
      bool operator!=(const value_type &o) const { return !(*this == o); }
    };

  public:

    explicit balanced3_type(explicit_call_disabled) :
        basic_type(8, TYPE_BALANCED3) {  // packed: single uint64_t (40 trits)
    }

    ~balanced3_type() = default;

  public:

    static auto create() {
      return std::make_shared<balanced3_type>(explicit_call_disabled());
    }

    static auto cast(std::shared_ptr<basic_type> type) {
      return std::dynamic_pointer_cast<balanced3_type>(type);
    }

  public:

    std::string to_string() const override { return "balanced3"; }

  };

} // cdk

/*============================================================================
 * test_ternary.c -- Tests for the ternary ALU (ternary.h).
 *
 * Exercises the scaffolding that all higher layers (balanced3, posit3,
 * takum3) rest on:
 *   - binary <-> ternary bridge (t_load_int, t_store_int, t_load_double)
 *   - per-trit addressing (t_set_trit, t_get_trit)
 *   - arithmetic primitives (add, sub, mul, div, neg, shl, shr)
 *   - comparison / predicates
 *============================================================================*/

#include <rts/ternary.h>
#include "test.h"

enum { A = 0, B = 1, C = 2, D = 3 };

int _main(int argc, char **argv, char **envp) {
  (void)argc; (void)argv; (void)envp;
  _begin("ternary ALU");

  /* ---- binary <-> ternary bridge (round-trip) ---- */
  t_load_int(A, 0);        CHECK_I("load/store 0",    t_store_int(A), 0);
  t_load_int(A, 1);        CHECK_I("load/store 1",    t_store_int(A), 1);
  t_load_int(A, -1);       CHECK_I("load/store -1",   t_store_int(A), -1);
  t_load_int(A, 42);       CHECK_I("load/store 42",   t_store_int(A), 42);
  t_load_int(A, -42);      CHECK_I("load/store -42",  t_store_int(A), -42);
  t_load_int(A, 1000000);  CHECK_I("load/store 1e6",  t_store_int(A), 1000000);
  t_load_int(A, -1000000); CHECK_I("load/store -1e6", t_store_int(A), -1000000);

  /* 40-trit balanced range: ±(3^40-1)/2 = ±6078832729528464400 */
  long long max40 = 6078832729528464400LL;
  t_load_int(A, max40);    CHECK_I("load/store +max40", t_store_int(A), max40);
  t_load_int(A, -max40);   CHECK_I("load/store -max40", t_store_int(A), -max40);

  /* ---- t_is_zero / t_sign ---- */
  t_load_int(A, 0);   CHECK("is_zero(0)",    t_is_zero(A));
  t_load_int(A, 1);   CHECK("!is_zero(1)",   !t_is_zero(A));
  t_load_int(A, -1);  CHECK("!is_zero(-1)",  !t_is_zero(A));

  t_load_int(A, 100);  CHECK("sign(+) > 0", t_sign(A) > 0);
  t_load_int(A, -100); CHECK("sign(-) < 0", t_sign(A) < 0);
  t_load_int(A, 0);    CHECK("sign(0) == 0", t_sign(A) == 0);

  /* ---- set_trit / get_trit ---- */
  t_clear(A);
  t_set_trit(A, 0, 1);
  t_set_trit(A, 1, -1);
  t_set_trit(A, 4, 1);
  CHECK_I("get_trit[0]", t_get_trit(A, 0),  1);
  CHECK_I("get_trit[1]", t_get_trit(A, 1), -1);
  CHECK_I("get_trit[2]", t_get_trit(A, 2),  0);
  CHECK_I("get_trit[4]", t_get_trit(A, 4),  1);
  /* value = 1 - 3 + 81 = 79 */
  CHECK_I("set_trit composite value", t_store_int(A), 79);

  /* overwrite a trit */
  t_set_trit(A, 0, -1);
  /* value = -1 - 3 + 81 = 77 */
  CHECK_I("overwrite trit[0]", t_store_int(A), 77);

  /* ---- addition ---- */
  t_load_int(A, 123); t_load_int(B, 456);
  t_add(C, A, B);
  CHECK_I("123 + 456", t_store_int(C), 579);

  t_load_int(A, 500); t_load_int(B, -200);
  t_add(C, A, B);
  CHECK_I("500 + -200", t_store_int(C), 300);

  /* add identity: a + 0 == a */
  t_load_int(A, 98765); t_load_int(B, 0);
  t_add(C, A, B);
  CHECK_I("a + 0 == a", t_store_int(C), 98765);

  /* commutativity */
  t_load_int(A, 7); t_load_int(B, 11);
  t_add(C, A, B); t_add(D, B, A);
  CHECK_I("a+b commutative", t_store_int(C), t_store_int(D));

  /* ---- subtraction ---- */
  t_load_int(A, 1000); t_load_int(B, 237);
  t_sub(C, A, B);
  CHECK_I("1000 - 237", t_store_int(C), 763);

  /* a - a == 0 */
  t_load_int(A, -54321);
  t_sub(C, A, A);
  CHECK("a - a == 0", t_is_zero(C));

  /* ---- multiplication ---- */
  t_load_int(A, 7); t_load_int(B, 13);
  t_mul(C, D, A, B);  /* 7*13 = 91, high trits zero */
  CHECK_I("7 * 13 low",  t_store_int(C), 91);
  CHECK_I("7 * 13 high", t_store_int(D), 0);

  /* sign: (-7) * 13 = -91 */
  t_load_int(A, -7); t_load_int(B, 13);
  t_mul(C, D, A, B);
  CHECK_I("-7 * 13", t_store_int(C), -91);

  /* zero: a * 0 == 0 */
  t_load_int(A, 99999); t_load_int(B, 0);
  t_mul(C, D, A, B);
  CHECK("a * 0 low zero",  t_is_zero(C));
  CHECK("a * 0 high zero", t_is_zero(D));

  /* ---- division ---- */
  t_load_int(A, 100); t_load_int(B, 7);
  t_div(C, D, A, B);   /* 100 = 7 * 14 + 2 */
  CHECK_I("100 / 7 quot", t_store_int(C), 14);
  CHECK_I("100 / 7 rem",  t_store_int(D), 2);

  /* a / 1 == a */
  t_load_int(A, 123456); t_load_int(B, 1);
  t_div(C, D, A, B);
  CHECK_I("a / 1 == a", t_store_int(C), 123456);

  /* a / a == 1 */
  t_load_int(A, 789);
  t_div(C, D, A, A);
  CHECK_I("a / a == 1", t_store_int(C), 1);

  /* ---- negation ---- */
  t_load_int(A, 42); t_neg(C, A);
  CHECK_I("neg(42)", t_store_int(C), -42);
  /* involutive: neg(neg(a)) == a */
  t_neg(D, C);
  CHECK_I("neg(neg(a)) == a", t_store_int(D), 42);

  /* ---- shift ---- */
  t_load_int(A, 5); t_shl(C, A, 2);  /* 5 * 9 = 45 */
  CHECK_I("5 << 2 (*9)", t_store_int(C), 45);

  t_load_int(A, 45); t_shr(C, A, 2);  /* 45 / 9 = 5 */
  CHECK_I("45 >> 2 (/9)", t_store_int(C), 5);

  t_load_int(A, 1); t_shl(C, A, 5);  /* 3^5 = 243 */
  CHECK_I("1 << 5 (3^5)", t_store_int(C), 243);

  /* ---- compare ---- */
  t_load_int(A, 10); t_load_int(B, 20);
  CHECK("10 < 20", t_cmp(A, B) < 0);
  CHECK("20 > 10", t_cmp(B, A) > 0);
  t_load_int(A, 7);  t_load_int(B, 7);
  CHECK("7 == 7",  t_cmp(A, B) == 0);

  /* ---- double bridge ---- */
  t_load_double(A, 0.0, 12);
  CHECK("load_double(0.0) is zero", t_is_zero(A));

  t_load_double(A, 1.0, 12);
  /* integer part lives at trits [120-12 .. 119] = [108..119]; value 1 -> trit 108 = +1 */
  CHECK_I("load_double(1.0) trit108", t_get_trit(A, 108), 1);

  t_load_double(A, -1.0, 12);
  CHECK_I("load_double(-1.0) trit108", t_get_trit(A, 108), -1);

  return _summary();
}

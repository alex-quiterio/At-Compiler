/*============================================================================
 * test_takum3.c -- Tests for takum3 (Hunhold Def. 2, fixed 2-trit regime).
 *
 * Covers everything in test_posit3 plus:
 *   - Regime decoding at each R_bal region (-4..+4)
 *   - Characteristic range verification
 *   - Saturation: overflow -> MAXFIN, underflow -> MIN_POS_FIN
 *     (NOT zero -- takum paper Sec. 4.2 prohibits flush-to-zero)
 *============================================================================*/

#include <rts/takum3.h>
#include "test.h"

static int _close(double got, double want, double tol) {
  double e = got - want;
  if (e < 0) e = -e;
  double w = want < 0 ? -want : want;
  if (w < 1e-300) return e < tol;
  return e / w < tol;
}

static int _bt(balanced3_t v) { return balanced3_to_int64(v) > 0; }

/* helper: round-trip a double through takum3 and back */
static double _rt(double d) {
  takum3_t v;
  takum3_from_double(&v, d);
  return takum3_to_double(v);
}

int _main(int argc, char **argv, char **envp) {
  (void)argc; (void)argv; (void)envp;
  _begin("takum3");

  /* ---- predicates ---- */
  takum3_t zero; takum3_from_double(&zero, 0.0);
  CHECK("is_zero(0.0)",      takum3_is_zero(zero));
  CHECK("!is_nar(0.0)",     !takum3_is_nar(zero));

  takum3_t one; takum3_from_double(&one, 1.0);
  CHECK("is_positive(1.0)",  takum3_is_positive(one));
  CHECK("!is_zero(1.0)",    !takum3_is_zero(one));

  takum3_t mone; takum3_from_double(&mone, -1.0);
  CHECK("is_negative(-1.0)", takum3_is_negative(mone));

  /* ---- round-trip ---- */
  CHECK("round 0.0",  _close(_rt(0.0),  0.0, 1e-30));
  CHECK("round 1.0",  _close(_rt(1.0),  1.0, 1e-12));
  CHECK("round -1.0", _close(_rt(-1.0), -1.0, 1e-12));
  CHECK("round 3.0",  _close(_rt(3.0),  3.0, 1e-12));
  CHECK("round 9.0",  _close(_rt(9.0),  9.0, 1e-12));
  CHECK("round 1/3",  _close(_rt(1.0/3.0), 1.0/3.0, 1e-10));
  CHECK("round pi",   _close(_rt(3.14159265358979), 3.14159265358979, 1e-10));

  /* ---- regime regions (each R_bal case) ---- */
  /* R_bal=0 (c in {-1,0,+1}):    L ~ -1, 0, +1 -> values 1/3, 1, 3 */
  CHECK("R=0 c=-1 (1/3)", _close(_rt(1.0/3.0), 1.0/3.0, 1e-10));
  CHECK("R=0 c=0 (1)",    _close(_rt(1.0), 1.0, 1e-12));
  CHECK("R=0 c=+1 (3)",   _close(_rt(3.0), 3.0, 1e-12));
  /* R_bal=+1 (c in [2,4]):  3^2..3^4 = 9..81 */
  CHECK("R=+1 c=2 (9)",   _close(_rt(9.0), 9.0, 1e-10));
  CHECK("R=+1 c=4 (81)",  _close(_rt(81.0), 81.0, 1e-10));
  /* R_bal=+2 (c in [5,13]): 3^5..3^13 = 243..1594323 */
  CHECK("R=+2 c=5 (243)", _close(_rt(243.0), 243.0, 1e-10));
  /* R_bal=-1 (c in [-4,-2]): 3^-4..3^-2 */
  CHECK("R=-1 c=-2 (1/9)", _close(_rt(1.0/9.0), 1.0/9.0, 1e-10));
  /* R_bal=+3 (c in [14,40]) */
  CHECK("R=+3 c=14 (3^14)", _close(_rt(4782969.0), 4782969.0, 1e-8));
  /* R_bal=-2, -3: check via small values */
  CHECK("R=-2 (1e-3)",  _close(_rt(1e-3), 1e-3, 1e-8));
  CHECK("R=-3 (1e-15)", _close(_rt(1e-15), 1e-15, 1e-6));

  /* ---- arithmetic ---- */
  takum3_t a; takum3_from_double(&a, 2.0);
  takum3_t b; takum3_from_double(&b, 3.0);
  takum3_t r;

  takum3_add(&r, a, b); CHECK("2 + 3 == 5",   _close(takum3_to_double(r), 5.0, 1e-10));
  takum3_sub(&r, a, b); CHECK("2 - 3 == -1",  _close(takum3_to_double(r), -1.0, 1e-10));
  takum3_mul(&r, a, b); CHECK("2 * 3 == 6",   _close(takum3_to_double(r), 6.0, 1e-10));
  takum3_div(&r, b, a); CHECK("3 / 2 == 1.5", _close(takum3_to_double(r), 1.5, 1e-10));

  takum3_mul(&r, a, one); CHECK("x * 1 == x",  _close(takum3_to_double(r), 2.0, 1e-10));
  takum3_mul(&r, a, zero); CHECK("x * 0 == 0", takum3_is_zero(r));
  takum3_add(&r, zero, a); CHECK("0 + x == x", _close(takum3_to_double(r), 2.0, 1e-10));
  takum3_sub(&r, a, a);    CHECK("a - a == 0", takum3_is_zero(r));

  /* negation is involutive */
  takum3_t n;
  takum3_neg(&n, a);
  CHECK("neg(2) < 0",       takum3_is_negative(n));
  takum3_neg(&r, n);
  CHECK("neg(neg a) == a", _close(takum3_to_double(r), 2.0, 1e-10));

  /* ---- NaR propagation ---- */
  takum3_t nar;
  takum3_div(&nar, one, zero);
  CHECK("1/0 is NaR", takum3_is_nar(nar));
  takum3_add(&r, nar, a);
  CHECK("NaR + x is NaR", takum3_is_nar(r));
  takum3_mul(&r, nar, a);
  CHECK("NaR * x is NaR", takum3_is_nar(r));

  /* ---- saturation (critical) ---- */
  /* overflow: huge -> MAXFIN (very large finite, NOT NaR) */
  takum3_t huge; takum3_from_double(&huge, 1e300);
  CHECK("1e300 not NaR",     !takum3_is_nar(huge));
  CHECK("1e300 positive",     takum3_is_positive(huge));
  CHECK("1e300 very large",   takum3_to_double(huge) > 1e50);

  /* underflow: tiny positive -> MIN_POS_FIN (small finite, NOT zero, NOT huge) */
  takum3_t tiny; takum3_from_double(&tiny, 1e-300);
  CHECK("1e-300 not zero",   !takum3_is_zero(tiny));
  CHECK("1e-300 not NaR",    !takum3_is_nar(tiny));
  CHECK("1e-300 positive",    takum3_is_positive(tiny));
  /* REGRESSION GUARD: previous bug saturated underflow to MAXFIN */
  CHECK("1e-300 NOT saturated to huge", takum3_to_double(tiny) < 1.0);
  /* value is near 3^-121 ~ 1.07e-58 (smallest finite) */
  CHECK("1e-300 near smallest finite", takum3_to_double(tiny) < 1e-50);

  takum3_t neg_tiny; takum3_from_double(&neg_tiny, -1e-300);
  CHECK("-1e-300 negative",    takum3_is_negative(neg_tiny));
  CHECK("-1e-300 NOT saturated to huge-neg",
        takum3_to_double(neg_tiny) > -1.0);

  /* ---- symmetry: huge == -neg_huge ---- */
  takum3_t neg_huge; takum3_from_double(&neg_huge, -1e300);
  takum3_neg(&r, neg_huge);
  CHECK("neg(-1e300) == 1e300 (by packed eq)",
        _bt(takum3_eq(r, huge)));

  /* ---- ordering ---- */
  CHECK("tiny < 1",        _bt(takum3_lt(tiny, one)));
  CHECK("1 < huge",        _bt(takum3_lt(one, huge)));
  CHECK("-1 < 1",          _bt(takum3_lt(mone, one)));
  CHECK("zero < tiny",     _bt(takum3_lt(zero, tiny)));
  CHECK("neg_tiny < zero", _bt(takum3_lt(neg_tiny, zero)));
  CHECK("neg_huge < -1",   _bt(takum3_lt(neg_huge, mone)));

  /* ---- comparisons ---- */
  takum3_t two; takum3_from_double(&two, 2.0);
  CHECK("2 == 2", _bt(takum3_eq(two, two)));
  CHECK("2 != 3", _bt(takum3_ne(two, b)));
  CHECK("2 <= 2", _bt(takum3_le(two, two)));
  CHECK("2 >= 2", _bt(takum3_ge(two, two)));

  /* ---- balanced3 bridge ---- */
  balanced3_t b3 = balanced3_from_int(7);
  takum3_t t7;
  takum3_from_balanced3(&t7, b3);
  CHECK("takum3 from balanced3(7)",
        _close(takum3_to_double(t7), 7.0, 1e-10));

  return _summary();
}

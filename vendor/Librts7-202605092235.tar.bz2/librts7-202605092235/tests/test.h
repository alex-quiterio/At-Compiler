#pragma once

/*============================================================================
 * test.h -- Minimal test harness for librts.
 *
 * Each test file defines _main() and uses the macros below.  Results are
 * reported via librts's own I/O (prints, printi, println) -- no libc.
 *
 * Entry point is _main (called from lib32.asm's _start).
 *============================================================================*/

#include <rts/string.h>
#include <rts/integer.h>

static int _tr = 0;       /* tests run */
static int _tp = 0;       /* tests passed */
static const char *_suite = "";

__attribute__((unused))
static void _begin(const char *suite) {
  _suite = suite;
  prints("==== "); prints(suite); prints(" ====\n");
}

__attribute__((unused))
static void _ok(const char *name) {
  prints("  ok    "); prints(name); println();
  _tp++; _tr++;
}

__attribute__((unused))
static void _fail_i(const char *name, long long got, long long want) {
  prints("  FAIL  "); prints(name);
  prints("  got="); printi((int)got);
  prints(" want="); printi((int)want);
  println();
  _tr++;
}

__attribute__((unused))
static void _fail(const char *name, const char *why) {
  prints("  FAIL  "); prints(name); prints("  "); prints(why); println();
  _tr++;
}

__attribute__((unused))
static int _summary(void) {
  prints("---- "); prints(_suite); prints(": ");
  printi(_tp); prints("/"); printi(_tr); prints(" passed ----\n");
  return (_tp == _tr) ? 0 : 1;
}

#define CHECK_I(name, got_expr, want_expr) do { \
    long long _g = (long long)(got_expr); \
    long long _w = (long long)(want_expr); \
    if (_g == _w) _ok(name); else _fail_i(name, _g, _w); \
  } while (0)

#define CHECK(name, cond) do { \
    if (cond) _ok(name); else _fail(name, "predicate false"); \
  } while (0)

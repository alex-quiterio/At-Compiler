/*============================================================================
 * test_posit3.c -- Tests for posit3 (variable-regime logarithmic 80-trit).
 *
 * Covers:
 *   - binary <-> posit bridge (from_double, to_double)
 *   - predicates (is_zero, is_nar, is_positive, is_negative)
 *   - arithmetic (add, sub, mul, div, neg)
 *   - NaR propagation
 *   - Zero handling (a*0 == 0, div by zero -> NaR)
 *   - Saturation: overflow -> MAXFIN, underflow -> MIN_POS_FIN (NOT zero, NOT MAXFIN)
 *   - Negation via trit-flip
 *   - Ordering preservation (packed compare matches value compare)
 *   - Comparisons
 *============================================================================*/

#include <rts/posit3.h>
#include "test.h"

/* helper: round-trip a double and check |rel_error| < tol */
static int _close(double got, double want, double tol) {
  double e = got - want;
  if (e < 0) e = -e;
  double w = want < 0 ? -want : want;
  if (w < 1e-300) return e < tol;
  return e / w < tol;
}

/* helper: balanced3 comparison result is true iff +1 */
static int _bt(balanced3_t v) { return balanced3_to_int64(v) > 0; }

/* helper: round-trip a double through posit3 and back */
static double _rt(double d) {
  posit3_t v;
  posit3_from_double(&v, d);
  return posit3_to_double(v);
}

int _main(int argc, char **argv, char **envp) {
  (void)argc; (void)argv; (void)envp;
  _begin("posit3");

  /* ---- predicates ---- */
  posit3_t zero; posit3_from_double(&zero, 0.0);
  CHECK("is_zero(0.0)",      posit3_is_zero(zero));
  CHECK("!is_nar(0.0)",     !posit3_is_nar(zero));

  posit3_t one; posit3_from_double(&one, 1.0);
  CHECK("!is_zero(1.0)",    !posit3_is_zero(one));
  CHECK("is_positive(1.0)",  posit3_is_positive(one));
  CHECK("!is_negative(1.0)",!posit3_is_negative(one));

  posit3_t mone; posit3_from_double(&mone, -1.0);
  CHECK("is_negative(-1.0)", posit3_is_negative(mone));
  CHECK("!is_positive(-1.0)",!posit3_is_positive(mone));

  /* ---- round-trip ---- */
  CHECK("round 0.0",  _close(_rt(0.0),  0.0, 1e-30));
  CHECK("round 1.0",  _close(_rt(1.0),  1.0, 1e-12));
  CHECK("round -1.0", _close(_rt(-1.0), -1.0, 1e-12));
  CHECK("round 3.0",  _close(_rt(3.0),  3.0, 1e-12));
  CHECK("round 0.5",  _close(_rt(0.5),  0.5, 1e-12));
  CHECK("round 3.14159265", _close(_rt(3.14159265), 3.14159265, 1e-10));
  CHECK("round 1e10",       _close(_rt(1e10), 1e10, 1e-10));
  CHECK("round 1e-10",      _close(_rt(1e-10), 1e-10, 1e-10));

  /* ---- arithmetic ---- */
  posit3_t a; posit3_from_double(&a, 2.0);
  posit3_t b; posit3_from_double(&b, 3.0);
  posit3_t r;

  posit3_add(&r, a, b); CHECK("2 + 3 == 5",     _close(posit3_to_double(r), 5.0, 1e-10));
  posit3_sub(&r, a, b); CHECK("2 - 3 == -1",    _close(posit3_to_double(r), -1.0, 1e-10));
  posit3_mul(&r, a, b); CHECK("2 * 3 == 6",     _close(posit3_to_double(r), 6.0, 1e-10));
  posit3_div(&r, b, a); CHECK("3 / 2 == 1.5",   _close(posit3_to_double(r), 1.5, 1e-10));

  /* identity: x * 1 == x */
  posit3_mul(&r, a, one);
  CHECK("x * 1 == x", _close(posit3_to_double(r), 2.0, 1e-10));

  /* zero: x * 0 == 0 */
  posit3_mul(&r, a, zero);
  CHECK("x * 0 == 0", posit3_is_zero(r));

  /* zero: 0 + x == x */
  posit3_add(&r, zero, a);
  CHECK("0 + x == x", _close(posit3_to_double(r), 2.0, 1e-10));

  /* cancellation */
  posit3_sub(&r, a, a);
  CHECK("a - a == 0", posit3_is_zero(r));

  /* negation via trit-flip is involutive */
  posit3_t n;
  posit3_neg(&n, a);
  CHECK("neg(2) < 0",     posit3_is_negative(n));
  posit3_neg(&r, n);
  CHECK("neg(neg a) == a", _close(posit3_to_double(r), 2.0, 1e-10));

  /* ---- NaR propagation ---- */
  posit3_t nar;
  posit3_div(&nar, one, zero);  /* 1/0 -> NaR */
  CHECK("1/0 is NaR", posit3_is_nar(nar));

  posit3_add(&r, nar, a);
  CHECK("NaR + x is NaR", posit3_is_nar(r));
  posit3_mul(&r, nar, a);
  CHECK("NaR * x is NaR", posit3_is_nar(r));

  /* ---- saturation ---- */
  /* overflow: huge value -> MAXFIN (a very large finite, NOT NaR) */
  posit3_t huge; posit3_from_double(&huge, 1e300);
  CHECK("1e300 not NaR",  !posit3_is_nar(huge));
  CHECK("1e300 positive",  posit3_is_positive(huge));
  /* sanity: round-trip gives something >> 1 */
  CHECK("1e300 large", posit3_to_double(huge) > 1e100);

  posit3_t neg_huge; posit3_from_double(&neg_huge, -1e300);
  CHECK("-1e300 negative", posit3_is_negative(neg_huge));
  CHECK("-1e300 not NaR", !posit3_is_nar(neg_huge));

  /* underflow: tiny positive MUST saturate to MIN_POS_FIN, not zero, not MAXFIN */
  posit3_t tiny; posit3_from_double(&tiny, 1e-300);
  CHECK("1e-300 not zero",    !posit3_is_zero(tiny));
  CHECK("1e-300 not NaR",     !posit3_is_nar(tiny));
  CHECK("1e-300 positive",     posit3_is_positive(tiny));
  /* MUST NOT saturate up to huge: round-trip must be small */
  CHECK("1e-300 round-trip small", posit3_to_double(tiny) < 1.0);

  posit3_t neg_tiny; posit3_from_double(&neg_tiny, -1e-300);
  CHECK("-1e-300 not zero",   !posit3_is_zero(neg_tiny));
  CHECK("-1e-300 negative",    posit3_is_negative(neg_tiny));
  CHECK("-1e-300 round-trip small",
        posit3_to_double(neg_tiny) > -1.0);

  /* ---- ordering preservation ---- */
  CHECK("tiny < 1",     _bt(posit3_lt(tiny, one)));
  CHECK("1 < huge",     _bt(posit3_lt(one, huge)));
  CHECK("-1 < 1",       _bt(posit3_lt(mone, one)));
  CHECK("tiny > neg_tiny", _bt(posit3_gt(tiny, neg_tiny)));
  CHECK("zero < tiny",  _bt(posit3_lt(zero, tiny)));
  CHECK("neg_tiny < zero", _bt(posit3_lt(neg_tiny, zero)));

  /* ---- comparisons ---- */
  posit3_t two; posit3_from_double(&two, 2.0);
  CHECK("2 == 2",      _bt(posit3_eq(two, two)));
  CHECK("2 != 3",      _bt(posit3_ne(two, b)));
  CHECK("2 <= 2",      _bt(posit3_le(two, two)));
  CHECK("2 >= 2",      _bt(posit3_ge(two, two)));
  CHECK("2 < 3",       _bt(posit3_lt(two, b)));
  CHECK("3 > 2",       _bt(posit3_gt(b, two)));

  /* ---- balanced3 bridge ---- */
  balanced3_t b3 = balanced3_from_int(7);
  posit3_t p7;
  posit3_from_balanced3(&p7, b3);
  CHECK("posit3 from balanced3(7)", _close(posit3_to_double(p7), 7.0, 1e-10));

  return _summary();
}

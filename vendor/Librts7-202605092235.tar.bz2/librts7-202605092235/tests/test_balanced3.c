/*============================================================================
 * test_balanced3.c -- Tests for balanced3 (40-trit signed integer).
 *
 * Covers:
 *   - binary <-> ternary bridge (from_int, from_int64, to_int, to_int64)
 *   - arithmetic (add, sub, mul, div, mod, neg)
 *   - trit access
 *   - comparisons (eq, ne, lt, gt, le, ge returning balanced3 +1/-1)
 *   - Kleene three-valued logic (not, and, or with Unknown=0)
 *   - range boundaries (near 3^40 limits)
 *============================================================================*/

#include <rts/balanced3.h>
#include "test.h"

/* A balanced3 comparison result is +1 (true), -1 (false), or Unknown(0). */
static int _is_true(balanced3_t v)  { return balanced3_to_int64(v) > 0; }
static int _is_false(balanced3_t v) { return balanced3_to_int64(v) < 0; }

int _main(int argc, char **argv, char **envp) {
  (void)argc; (void)argv; (void)envp;
  _begin("balanced3");

  /* ---- binary <-> ternary bridge ---- */
  CHECK_I("from_int(0)",   balanced3_to_int64(balanced3_from_int(0)),    0);
  CHECK_I("from_int(1)",   balanced3_to_int64(balanced3_from_int(1)),    1);
  CHECK_I("from_int(-1)",  balanced3_to_int64(balanced3_from_int(-1)),  -1);
  CHECK_I("from_int(42)",  balanced3_to_int64(balanced3_from_int(42)),   42);
  CHECK_I("from_int(-42)", balanced3_to_int64(balanced3_from_int(-42)), -42);

  /* int64 round-trip beyond 32-bit range */
  long long big = 100000000000LL;   /* 1e11 */
  CHECK_I("from_int64(1e11)",  balanced3_to_int64(balanced3_from_int64(big)),  big);
  CHECK_I("from_int64(-1e11)", balanced3_to_int64(balanced3_from_int64(-big)), -big);

  /* near-limit values */
  long long max40 = 6078832729528464400LL;
  CHECK_I("from_int64(+max40)", balanced3_to_int64(balanced3_from_int64(max40)),  max40);
  CHECK_I("from_int64(-max40)", balanced3_to_int64(balanced3_from_int64(-max40)), -max40);

  /* to_int (32-bit) */
  CHECK_I("to_int(12345)", balanced3_to_int(balanced3_from_int(12345)), 12345);

  /* ---- addition ---- */
  balanced3_t a = balanced3_from_int(123);
  balanced3_t b = balanced3_from_int(456);
  CHECK_I("123 + 456", balanced3_to_int64(balanced3_add(a, b)), 579);

  /* identity: a + 0 == a */
  balanced3_t z = balanced3_from_int(0);
  CHECK_I("a + 0 == a", balanced3_to_int64(balanced3_add(a, z)), 123);

  /* commutative */
  long long s1 = balanced3_to_int64(balanced3_add(a, b));
  long long s2 = balanced3_to_int64(balanced3_add(b, a));
  CHECK_I("add commutative", s1, s2);

  /* sign mix */
  a = balanced3_from_int(500); b = balanced3_from_int(-200);
  CHECK_I("500 + -200", balanced3_to_int64(balanced3_add(a, b)), 300);

  /* ---- subtraction ---- */
  a = balanced3_from_int(1000); b = balanced3_from_int(237);
  CHECK_I("1000 - 237", balanced3_to_int64(balanced3_sub(a, b)), 763);

  /* a - a == 0 */
  a = balanced3_from_int(-54321);
  CHECK_I("a - a == 0", balanced3_to_int64(balanced3_sub(a, a)), 0);

  /* ---- multiplication ---- */
  a = balanced3_from_int(7); b = balanced3_from_int(13);
  CHECK_I("7 * 13", balanced3_to_int64(balanced3_mul(a, b)), 91);

  /* sign */
  a = balanced3_from_int(-7); b = balanced3_from_int(13);
  CHECK_I("-7 * 13", balanced3_to_int64(balanced3_mul(a, b)), -91);

  /* zero */
  a = balanced3_from_int(99999); b = balanced3_from_int(0);
  CHECK_I("a * 0 == 0", balanced3_to_int64(balanced3_mul(a, b)), 0);

  /* identity */
  a = balanced3_from_int(42); b = balanced3_from_int(1);
  CHECK_I("a * 1 == a", balanced3_to_int64(balanced3_mul(a, b)), 42);

  /* larger product still in range */
  a = balanced3_from_int64(1000000LL); b = balanced3_from_int64(1000000LL);
  CHECK_I("1e6 * 1e6 = 1e12",
          balanced3_to_int64(balanced3_mul(a, b)), 1000000000000LL);

  /* ---- division and modulo ---- */
  a = balanced3_from_int(100); b = balanced3_from_int(7);
  CHECK_I("100 / 7 quot", balanced3_to_int64(balanced3_div(a, b)), 14);
  CHECK_I("100 mod 7",    balanced3_to_int64(balanced3_mod(a, b)),  2);

  /* a / a == 1 */
  a = balanced3_from_int(789);
  CHECK_I("a / a == 1", balanced3_to_int64(balanced3_div(a, a)), 1);

  /* a / 1 == a */
  a = balanced3_from_int(-1234); b = balanced3_from_int(1);
  CHECK_I("a / 1 == a", balanced3_to_int64(balanced3_div(a, b)), -1234);

  /* ---- negation ---- */
  a = balanced3_from_int(42);
  CHECK_I("-42", balanced3_to_int64(balanced3_neg(a)), -42);

  /* involutive */
  CHECK_I("-(-42) = 42",
          balanced3_to_int64(balanced3_neg(balanced3_neg(a))), 42);

  /* neg(0) == 0 */
  CHECK_I("-0 == 0", balanced3_to_int64(balanced3_neg(balanced3_from_int(0))), 0);

  /* ---- trit access ---- */
  /* 79 = 81 - 3 + 1 = +1*3^4 + -1*3^1 + +1*3^0 */
  a = balanced3_from_int(79);
  CHECK_I("trit[0] of 79",   balanced3_get_trit(a, 0),  1);
  CHECK_I("trit[1] of 79",   balanced3_get_trit(a, 1), -1);
  CHECK_I("trit[2] of 79",   balanced3_get_trit(a, 2),  0);
  CHECK_I("trit[4] of 79",   balanced3_get_trit(a, 4),  1);

  /* set_trit */
  a = balanced3_from_int(0);
  a = balanced3_set_trit(a, 3, 1);  /* 3^3 = 27 */
  CHECK_I("set_trit[3]=+1", balanced3_to_int64(a), 27);
  a = balanced3_set_trit(a, 3, -1);
  CHECK_I("overwrite trit[3]=-1", balanced3_to_int64(a), -27);

  /* ---- comparisons (return +1 true, -1 false) ---- */
  a = balanced3_from_int(10); b = balanced3_from_int(20);
  CHECK("10 < 20",  _is_true(balanced3_lt(a, b)));
  CHECK("10 > 20",  _is_false(balanced3_gt(a, b)));
  CHECK("10 == 20", _is_false(balanced3_eq(a, b)));
  CHECK("10 != 20", _is_true(balanced3_ne(a, b)));
  CHECK("10 <= 20", _is_true(balanced3_le(a, b)));
  CHECK("10 >= 20", _is_false(balanced3_ge(a, b)));

  a = balanced3_from_int(7); b = balanced3_from_int(7);
  CHECK("7 == 7", _is_true(balanced3_eq(a, b)));
  CHECK("7 <= 7", _is_true(balanced3_le(a, b)));
  CHECK("7 >= 7", _is_true(balanced3_ge(a, b)));

  /* ---- Kleene three-valued logic ---- */
  balanced3_t T = balanced3_from_int(1);   /* True  */
  balanced3_t F = balanced3_from_int(-1);  /* False */
  balanced3_t U = balanced3_from_int(0);   /* Unknown */

  CHECK("not T = F", _is_false(balanced3_kleene_not(T)));
  CHECK("not F = T", _is_true (balanced3_kleene_not(F)));
  CHECK_I("not U = U",
          balanced3_to_int64(balanced3_kleene_not(U)), 0);

  CHECK("T and T = T", _is_true (balanced3_kleene_and(T, T)));
  CHECK("T and F = F", _is_false(balanced3_kleene_and(T, F)));
  CHECK("T or F = T",  _is_true (balanced3_kleene_or (T, F)));
  CHECK("F or F = F",  _is_false(balanced3_kleene_or (F, F)));

  /* Kleene's key case: Unknown propagates only when not dominated */
  CHECK("T and U = U",
        balanced3_to_int64(balanced3_kleene_and(T, U)) == 0);
  CHECK("F and U = F",
        _is_false(balanced3_kleene_and(F, U)));      /* F dominates */
  CHECK("T or U = T",
        _is_true (balanced3_kleene_or(T, U)));       /* T dominates */
  CHECK("F or U = U",
        balanced3_to_int64(balanced3_kleene_or(F, U)) == 0);

  return _summary();
}

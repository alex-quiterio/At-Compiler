#include "ternary.h"

/*============================================================================
 * ternary.c -- Balanced Ternary ALU Simulator
 *============================================================================
 *
 * This is the ONLY file in the entire RTS that performs arithmetic using
 * binary C types to implement ternary operations.  Every other ternary
 * module (balanced3, posit3) calls into this ALU.
 *
 * The implementation is straightforward:
 *
 *   1. Unpack registers into flat trit arrays (int per trit).
 *   2. Perform the operation on the trit arrays.
 *   3. Repack into the mixed-radix packed halves.
 *
 * This unpack-operate-repack pattern is not the most efficient, but it
 * is transparent: each ALU operation is expressed as a simple loop over
 * trits, easily verified against the balanced ternary arithmetic rules.
 *
 * On a native ternary machine, this entire file would be replaced by
 * hardware instructions.
 *============================================================================*/

/* ------------------------------------------------------------------ */
/*  Powers of 3 table                                                 */
/* ------------------------------------------------------------------ */

static const unsigned long long pow3[T_HALF_TRITS + 1] = {
  1ULL, 3ULL, 9ULL, 27ULL, 81ULL, 243ULL, 729ULL, 2187ULL,
  6561ULL, 19683ULL, 59049ULL, 177147ULL, 531441ULL, 1594323ULL,
  4782969ULL, 14348907ULL, 43046721ULL, 129140163ULL, 387420489ULL,
  1162261467ULL, 3486784401ULL, 10460353203ULL, 31381059609ULL,
  94143178827ULL, 282429536481ULL, 847288609443ULL, 2541865828329ULL,
  7625597484987ULL, 22876792454961ULL, 68630377364883ULL,
  205891132094649ULL, 617673396283947ULL, 1853020188851841ULL,
  5559060566555523ULL, 16677181699666569ULL, 50031545098999707ULL,
  150094635296999121ULL, 450283905890997363ULL, 1350851717672992089ULL,
  4052555153018976267ULL, 12157665459056928801ULL,
};

/* ------------------------------------------------------------------ */
/*  Register file                                                     */
/* ------------------------------------------------------------------ */

static treg_t regfile[T_NUM_REGS];

treg_t *t_reg(int r) {
  return &regfile[r];
}

void t_clear(int r) {
  /* all-zero balanced trits = all halves at bias */
  regfile[r].h[0] = T_HALF_BIAS;
  regfile[r].h[1] = T_HALF_BIAS;
  regfile[r].h[2] = T_HALF_BIAS;
}

void t_copy(int dst, int src) {
  regfile[dst] = regfile[src];
}

/* ------------------------------------------------------------------ */
/*  Internal: unpack / repack                                         */
/*                                                                    */
/*  Unpack: convert packed halves -> flat int array (index 0 = LST).  */
/*  Repack: convert flat int array -> packed halves.                  */
/*                                                                    */
/*  These are the core routines that bridge binary storage and trit   */
/*  arithmetic.  All ALU operations go through them.                  */
/* ------------------------------------------------------------------ */

static void unpack(const treg_t *reg, int trits[T_REG_TRITS]) {
  for (int half = 0; half < T_HALVES; half++) {
    unsigned long long v = reg->h[half];
    int base = half * T_HALF_TRITS;
    for (int i = 0; i < T_HALF_TRITS; i++) {
      trits[base + i] = (int)(v % 3) - 1;
      v /= 3;
    }
  }
}

static void repack(treg_t *reg, const int trits[T_REG_TRITS]) {
  for (int half = 0; half < T_HALVES; half++) {
    unsigned long long v = 0;
    int base = half * T_HALF_TRITS;
    /* Horner's method from MST of this half downward */
    for (int i = T_HALF_TRITS - 1; i >= 0; i--)
      v = v * 3 + (unsigned long long)(trits[base + i] + 1);
    reg->h[half] = v;
  }
}

/*
 * normalize_trit -- the balanced ternary full adder.
 *
 * Decomposes an integer d (possibly outside {-1,0,+1}) into:
 *   d = carry * 3 + trit,   where trit ∈ {-1, 0, +1}
 *
 * This is the single most important operation in the ALU.  Every
 * addition, subtraction, and multiplication ultimately reduces to
 * repeated applications of this function.
 */
static int normalize_trit(int d, int *carry) {
  int adj = d + 1;
  int c = (adj >= 0) ? adj / 3 : (adj - 2) / 3;
  *carry = c;
  return d - c * 3;
}

/* ------------------------------------------------------------------ */
/*  Trit-level access                                                 */
/* ------------------------------------------------------------------ */

int t_get_trit(int r, int pos) {
  if (pos < 0 || pos >= T_REG_TRITS) return 0;
  int half = pos / T_HALF_TRITS;
  int idx = pos % T_HALF_TRITS;
  return (int)((regfile[r].h[half] / pow3[idx]) % 3) - 1;
}

void t_set_trit(int r, int pos, int trit) {
  if (pos < 0 || pos >= T_REG_TRITS) return;
  int half = pos / T_HALF_TRITS;
  int idx = pos % T_HALF_TRITS;
  unsigned long long *h = &regfile[r].h[half];
  int old_d = (int)((*h / pow3[idx]) % 3);
  *h = *h - (unsigned long long)old_d * pow3[idx]
           + (unsigned long long)(trit + 1) * pow3[idx];
}

/* ------------------------------------------------------------------ */
/*  Addition                                                          */
/*                                                                    */
/*  Unpack both operands, add trit-by-trit from LST to MST with      */
/*  carry propagation, repack the result.                             */
/*                                                                    */
/*  This is exactly what a hardware balanced ternary ripple-carry     */
/*  adder does, one trit at a time.  A real ALU would use carry-      */
/*  lookahead or carry-select for speed, but the logic is the same.   */
/* ------------------------------------------------------------------ */

int t_add(int dst, int a, int b) {
  int ta[T_REG_TRITS], tb[T_REG_TRITS], tr[T_REG_TRITS];
  unpack(&regfile[a], ta);
  unpack(&regfile[b], tb);

  int carry = 0;
  for (int i = 0; i < T_REG_TRITS; i++) {
    int sum = ta[i] + tb[i] + carry;
    tr[i] = normalize_trit(sum, &carry);
  }

  repack(&regfile[dst], tr);
  return carry;
}

/* ------------------------------------------------------------------ */
/*  Subtraction:  dst = a - b  (add with negated b)                   */
/* ------------------------------------------------------------------ */

int t_sub(int dst, int a, int b) {
  int ta[T_REG_TRITS], tb[T_REG_TRITS], tr[T_REG_TRITS];
  unpack(&regfile[a], ta);
  unpack(&regfile[b], tb);

  int carry = 0;
  for (int i = 0; i < T_REG_TRITS; i++) {
    int sum = ta[i] - tb[i] + carry;
    tr[i] = normalize_trit(sum, &carry);
  }

  repack(&regfile[dst], tr);
  return carry;
}

/* ------------------------------------------------------------------ */
/*  Multiplication                                                    */
/*                                                                    */
/*  Schoolbook (long) multiplication in balanced ternary:             */
/*                                                                    */
/*    1. For each pair (i, j), accumulate a[i]*b[j] at position i+j  */
/*       of the result.  Since each trit is in {-1, 0, +1}, the      */
/*       product a[i]*b[j] is also in {-1, 0, +1}.                   */
/*                                                                    */
/*    2. Normalise from LST to MST (propagate carries).               */
/*                                                                    */
/*  The result is 240 trits wide, stored in two registers:            */
/*    dst_lo = trits 0-119,  dst_hi = trits 120-239.                 */
/*                                                                    */
/*  Complexity: O(n²) where n = 120.  This is ~14,400 trit-multiply  */
/*  operations -- trivial on modern hardware (< 1 ms).                */
/* ------------------------------------------------------------------ */

#define T_DOUBLE_TRITS (2 * T_REG_TRITS)

void t_mul(int dst_lo, int dst_hi, int a, int b) {
  int ta[T_REG_TRITS], tb[T_REG_TRITS];
  int tr[T_DOUBLE_TRITS];
  unpack(&regfile[a], ta);
  unpack(&regfile[b], tb);

  for (int i = 0; i < T_DOUBLE_TRITS; i++) tr[i] = 0;

  for (int i = 0; i < T_REG_TRITS; i++) {
    if (ta[i] == 0) continue;
    for (int j = 0; j < T_REG_TRITS; j++)
      tr[i + j] += ta[i] * tb[j];
  }

  /* normalise from LST to MST */
  for (int k = 0; k < T_DOUBLE_TRITS - 1; k++) {
    int carry;
    tr[k] = normalize_trit(tr[k], &carry);
    tr[k + 1] += carry;
  }
  int discard;
  tr[T_DOUBLE_TRITS - 1] = normalize_trit(tr[T_DOUBLE_TRITS - 1], &discard);

  /* split into two registers */
  repack(&regfile[dst_lo], tr);             /* trits 0-119  */
  repack(&regfile[dst_hi], tr + T_REG_TRITS); /* trits 120-239 */
}

/* ------------------------------------------------------------------ */
/*  Division (balanced ternary MSD-first long division)               */
/*                                                                    */
/*  Schoolbook long division, trit-at-a-time, MSD to LSD:             */
/*                                                                    */
/*    1. Shift remainder left by one trit, bring down dividend[k].    */
/*    2. Try trial subtraction (q=+1) and trial addition (q=-1).      */
/*    3. Pick the trial whose |remainder| is strictly smaller than    */
/*       the current |remainder|; otherwise q=0.                      */
/*                                                                    */
/*  After 120 iterations, dst_rem holds the true remainder and        */
/*  dst_quot holds the quotient with MSD at trit[119].                */
/* ------------------------------------------------------------------ */

/*
 * Internal absolute-value comparison on trit arrays (LST-first).
 * Returns +1 if |a| > |b|, -1 if |a| < |b|, 0 if equal.
 */
static int abs_compare_trits(const int *a, const int *b, int len) {
  /* find sign of each array from MST */
  int sa = 0, sb = 0;
  for (int i = len - 1; i >= 0; i--) {
    if (sa == 0 && a[i] != 0) sa = (a[i] > 0) ? 1 : -1;
    if (sb == 0 && b[i] != 0) sb = (b[i] > 0) ? 1 : -1;
    if (sa != 0 && sb != 0) break;
  }
  if (sa == 0 && sb == 0) return 0;
  if (sa == 0) return -1;
  if (sb == 0) return 1;

  /* compare magnitudes from MST */
  for (int i = len - 1; i >= 0; i--) {
    int va = a[i] * sa, vb = b[i] * sb;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

void t_div(int dst_quot, int dst_rem, int a, int b) {
  int ta[T_REG_TRITS], tb[T_REG_TRITS];
  unpack(&regfile[a], ta);
  unpack(&regfile[b], tb);

  int rem[T_REG_TRITS], rp[T_REG_TRITS], rn[T_REG_TRITS];
  int quot[T_REG_TRITS];

  for (int i = 0; i < T_REG_TRITS; i++) {
    rem[i] = 0;
    quot[i] = 0;
  }

  for (int k = T_REG_TRITS - 1; k >= 0; k--) {
    /* shift remainder left by one trit, bring down dividend[k] */
    for (int i = T_REG_TRITS - 1; i > 0; i--) rem[i] = rem[i - 1];
    rem[0] = ta[k];

    /* rp = rem - divisor (trial q = +1) */
    int carry_p = 0;
    for (int i = 0; i < T_REG_TRITS; i++) {
      int s = rem[i] - tb[i] + carry_p;
      rp[i] = normalize_trit(s, &carry_p);
    }

    /* rn = rem + divisor (trial q = -1) */
    int carry_n = 0;
    for (int i = 0; i < T_REG_TRITS; i++) {
      int s = rem[i] + tb[i] + carry_n;
      rn[i] = normalize_trit(s, &carry_n);
    }

    /* pick the digit whose |remainder| is strictly smaller */
    int cp = abs_compare_trits(rp, rem, T_REG_TRITS);
    int cn = abs_compare_trits(rn, rem, T_REG_TRITS);

    if (cp < 0 && (cn >= 0 || abs_compare_trits(rp, rn, T_REG_TRITS) <= 0)) {
      quot[k] = 1;
      for (int i = 0; i < T_REG_TRITS; i++) rem[i] = rp[i];
    } else if (cn < 0) {
      quot[k] = -1;
      for (int i = 0; i < T_REG_TRITS; i++) rem[i] = rn[i];
    } else if (cp == 0 || cn == 0) {
      /* Tie: |rem| = d/2. Keep (q=0) and flip (q=±1) give the same |rem|,
       * but the choice determines whether the exact division can terminate.
       * Rule: flip iff the sum of the remaining dividend trits has the same
       * sign as rem. In balanced ternary the highest non-zero trit of the
       * remaining dividend dominates that sum, so its sign is enough. */
      int remaining_sign = 0;
      for (int j = k - 1; j >= 0; j--) {
        if (ta[j] != 0) { remaining_sign = ta[j]; break; }
      }
      if (cp == 0 && remaining_sign > 0) {
        quot[k] = 1;
        for (int i = 0; i < T_REG_TRITS; i++) rem[i] = rp[i];
      } else if (cn == 0 && remaining_sign < 0) {
        quot[k] = -1;
        for (int i = 0; i < T_REG_TRITS; i++) rem[i] = rn[i];
      } else {
        quot[k] = 0;
      }
    } else {
      quot[k] = 0;
    }
  }

  /* Normalize remainder to the canonical range r ∈ (-|b|/2, |b|/2].
   *
   * The long division above leaves |r| ≤ |b|/2.  At the boundary |r| = |b|/2,
   * both r = +|b|/2 and r = -|b|/2 are valid balanced-mod results, and the
   * intermediate tie-break can pick either depending on the dividend's
   * trit pattern.  That breaks the modular-arithmetic invariant that
   * a₁ ≡ a₂ (mod b) ⇒ a₁ % b = a₂ % b (e.g. 150 vs 5000000050 mod 100).
   *
   * Force the positive side at the tie, adjusting the quotient so that
   * q*b + r = a still holds:  if r = -|b|/2 then r += |b|, q -= sign(b). */
  {
    int two_rem[T_REG_TRITS];
    int carry = 0;
    for (int i = 0; i < T_REG_TRITS; i++) {
      int s = rem[i] + rem[i] + carry;
      two_rem[i] = normalize_trit(s, &carry);
    }
    if (abs_compare_trits(two_rem, tb, T_REG_TRITS) == 0) {
      int rem_sign = 0;
      for (int i = T_REG_TRITS - 1; i >= 0; i--) {
        if (rem[i] != 0) { rem_sign = rem[i]; break; }
      }
      if (rem_sign < 0) {
        int b_sign = 0;
        for (int i = T_REG_TRITS - 1; i >= 0; i--) {
          if (tb[i] != 0) { b_sign = tb[i]; break; }
        }
        carry = 0;
        for (int i = 0; i < T_REG_TRITS; i++) {
          int s = rem[i] + b_sign * tb[i] + carry;
          rem[i] = normalize_trit(s, &carry);
        }
        carry = -b_sign;
        for (int i = 0; i < T_REG_TRITS && carry != 0; i++) {
          int s = quot[i] + carry;
          quot[i] = normalize_trit(s, &carry);
        }
      }
    }
  }

  repack(&regfile[dst_quot], quot);
  repack(&regfile[dst_rem], rem);
}

/* ------------------------------------------------------------------ */
/*  Negation:  flip every trit.                                       */
/*                                                                    */
/*  In packed representation:  negated_half = HALF_MAX - half.        */
/*  This works because flipping trit d (in {0,1,2} standard form)    */
/*  to 2-d, summed over all positions, gives HALF_MAX - packed.      */
/* ------------------------------------------------------------------ */

void t_neg(int dst, int src) {
  for (int half = 0; half < T_HALVES; half++)
    regfile[dst].h[half] = T_HALF_MAX - regfile[src].h[half];
}

/* ------------------------------------------------------------------ */
/*  Shifts                                                            */
/* ------------------------------------------------------------------ */

void t_shl(int dst, int src, int n) {
  if (n <= 0) { t_copy(dst, src); return; }

  int trits[T_REG_TRITS];
  unpack(&regfile[src], trits);

  if (n >= T_REG_TRITS) {
    for (int i = 0; i < T_REG_TRITS; i++) trits[i] = 0;
  } else {
    /* shift toward MST: move trits[i] to trits[i+n] */
    for (int i = T_REG_TRITS - 1; i >= n; i--)
      trits[i] = trits[i - n];
    for (int i = 0; i < n; i++)
      trits[i] = 0;
  }

  repack(&regfile[dst], trits);
}

void t_shr(int dst, int src, int n) {
  if (n <= 0) { t_copy(dst, src); return; }

  int trits[T_REG_TRITS];
  unpack(&regfile[src], trits);

  if (n >= T_REG_TRITS) {
    for (int i = 0; i < T_REG_TRITS; i++) trits[i] = 0;
  } else {
    /* shift toward LST: move trits[i] to trits[i-n] */
    for (int i = 0; i < T_REG_TRITS - n; i++)
      trits[i] = trits[i + n];
    for (int i = T_REG_TRITS - n; i < T_REG_TRITS; i++)
      trits[i] = 0;
  }

  repack(&regfile[dst], trits);
}

/* ------------------------------------------------------------------ */
/*  Comparison                                                        */
/*                                                                    */
/*  Compare packed halves from MST (h[2]) down to LST (h[0]).        */
/*  The packed representation preserves ordering, so unsigned         */
/*  comparison of the halves gives the correct result.                */
/* ------------------------------------------------------------------ */

int t_cmp(int a, int b) {
  for (int half = T_HALVES - 1; half >= 0; half--) {
    if (regfile[a].h[half] > regfile[b].h[half]) return 1;
    if (regfile[a].h[half] < regfile[b].h[half]) return -1;
  }
  return 0;
}

int t_sign(int r) {
  /* check from MST downward for the first non-zero trit */
  for (int half = T_HALVES - 1; half >= 0; half--) {
    if (regfile[r].h[half] > T_HALF_BIAS) return 1;
    if (regfile[r].h[half] < T_HALF_BIAS) return -1;
  }
  return 0;
}

int t_is_zero(int r) {
  return regfile[r].h[0] == T_HALF_BIAS
      && regfile[r].h[1] == T_HALF_BIAS
      && regfile[r].h[2] == T_HALF_BIAS;
}

/* ------------------------------------------------------------------ */
/*  Bulk trit load/store                                              */
/* ------------------------------------------------------------------ */

void t_load_trits(int r, const int *trits, int n, int start_pos) {
  /* trits[] is MST-first; trit positions in register are LST-first */
  for (int i = 0; i < n; i++) {
    int pos = start_pos - i;  /* MST of field -> highest position */
    if (pos >= 0 && pos < T_REG_TRITS)
      t_set_trit(r, pos, trits[i]);
  }
}

void t_store_trits(int r, int *trits, int n, int start_pos) {
  for (int i = 0; i < n; i++) {
    int pos = start_pos - i;
    if (pos >= 0 && pos < T_REG_TRITS)
      trits[i] = t_get_trit(r, pos);
    else
      trits[i] = 0;
  }
}

/* ------------------------------------------------------------------ */
/*  Binary bridge: integer load/store                                 */
/* ------------------------------------------------------------------ */

void t_load_int(int r, long long value) {
  int trits[T_REG_TRITS];
  for (int i = 0; i < T_REG_TRITS; i++) trits[i] = 0;

  int neg = 0;
  unsigned long long mag;
  if (value < 0) {
    neg = 1;
    mag = (unsigned long long)(-(value + 1)) + 1;
  } else {
    mag = (unsigned long long)value;
  }

  /* convert magnitude to standard (unsigned) ternary */
  for (int i = 0; i < T_REG_TRITS && mag != 0; i++) {
    trits[i] = (int)(mag % 3);
    mag /= 3;
  }

  /* convert standard digits {0,1,2} to balanced {-1,0,+1} */
  int carry = 0;
  for (int i = 0; i < T_REG_TRITS; i++) {
    int d = trits[i] + carry;
    if (d > 1) { trits[i] = d - 3; carry = 1; }
    else { trits[i] = d; carry = 0; }
  }

  if (neg) {
    for (int i = 0; i < T_REG_TRITS; i++) trits[i] = -trits[i];
  }

  repack(&regfile[r], trits);
}

long long t_store_int(int r) {
  int trits[T_REG_TRITS];
  unpack(&regfile[r], trits);

  /*
   * Accumulate value from MST to LST using Horner's method.
   * Clamp to int64 range if the ternary value is too large.
   */
  long long result = 0;
  for (int i = T_REG_TRITS - 1; i >= 0; i--) {
    /* overflow check before multiply */
    if (result > 3074457345618258602LL || result < -3074457345618258602LL) {
      /* 3074457345618258602 ≈ INT64_MAX / 3 */
      return (result > 0) ? 9223372036854775807LL : (-9223372036854775807LL - 1);
    }
    result = result * 3 + trits[i];
  }
  return result;
}

/* ------------------------------------------------------------------ */
/*  Binary bridge: double load/store                                  */
/*                                                                    */
/*  Interprets the register as a fixed-point number with `int_trits`  */
/*  integer trits and the rest as fraction.  MST = trit 119.          */
/* ------------------------------------------------------------------ */

void t_load_double(int r, double value, int int_trits) {
  int trits[T_REG_TRITS];
  for (int i = 0; i < T_REG_TRITS; i++) trits[i] = 0;

  /*
   * Greedy MST-first extraction.
   *
   * Start with weight = 3^(int_trits - 1) (the value of the MST).
   * At each trit position from MST (119) to LST (0):
   *   if value >= 0.5 * weight:  trit = +1, value -= weight
   *   if value <= -0.5 * weight: trit = -1, value += weight
   *   else:                      trit = 0
   *   weight /= 3
   */
  double weight = 1.0;
  for (int i = 1; i < int_trits; i++) weight *= 3.0;

  for (int i = T_REG_TRITS - 1; i >= 0; i--) {
    if (value >= 0.5 * weight)       { trits[i] = 1;  value -= weight; }
    else if (value <= -0.5 * weight) { trits[i] = -1; value += weight; }
    else                             { trits[i] = 0; }
    weight /= 3.0;
  }

  repack(&regfile[r], trits);
}

double t_store_double(int r, int int_trits) {
  int trits[T_REG_TRITS];
  unpack(&regfile[r], trits);

  double result = 0.0;
  double weight = 1.0;
  for (int i = 1; i < int_trits; i++) weight *= 3.0;

  for (int i = T_REG_TRITS - 1; i >= 0; i--) {
    result += trits[i] * weight;
    weight /= 3.0;
  }
  return result;
}

/* ------------------------------------------------------------------ */
/*  Binary bridge: packed half load/store                             */
/* ------------------------------------------------------------------ */

void t_load_packed(int r, unsigned long long lo,
                   unsigned long long mi, unsigned long long hi) {
  regfile[r].h[0] = lo;
  regfile[r].h[1] = mi;
  regfile[r].h[2] = hi;
}

void t_store_packed(int r, unsigned long long *lo,
                    unsigned long long *mi, unsigned long long *hi) {
  *lo = regfile[r].h[0];
  *mi = regfile[r].h[1];
  *hi = regfile[r].h[2];
}

/* ------------------------------------------------------------------ */
/*  Divide by small binary integer                                    */
/*                                                                    */
/*  This is a convenience operation that crosses the binary bridge:   */
/*  the divisor `k` is a plain C int.  It uses sequential division    */
/*  from MST to LST, which is O(n) rather than O(n²).                */
/*                                                                    */
/*  Used by series evaluations (dividing by 2, 3, 5, 7, ... in       */
/*  the Horner loops for exp and atanh).                              */
/* ------------------------------------------------------------------ */

void t_div_small(int dst, int a, int k) {
  int trits[T_REG_TRITS];
  unpack(&regfile[a], trits);

  int rem = 0;
  for (int i = T_REG_TRITS - 1; i >= 0; i--) {
    int d = rem * 3 + trits[i];
    trits[i] = d / k;
    rem = d - trits[i] * k;
  }

  /* normalise: the quotient digits may be outside {-1,0,+1} */
  for (int i = 0; i < T_REG_TRITS - 1; i++) {
    int carry;
    trits[i] = normalize_trit(trits[i], &carry);
    trits[i + 1] += carry;
  }
  int discard;
  trits[T_REG_TRITS - 1] = normalize_trit(trits[T_REG_TRITS - 1], &discard);

  repack(&regfile[dst], trits);
}

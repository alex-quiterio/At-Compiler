#pragma once

#include "ternary.h"

/*============================================================================
 * balanced3.h -- Balanced Ternary Integer Arithmetic (40 trits)
 *============================================================================
 *
 * WHAT IS BALANCED TERNARY?
 *
 *   Balanced ternary is a numeral system where each digit ("trit") has one
 *   of three values: -1, 0, or +1.  The value of an N-trit number is:
 *
 *       value = sum_{i=0}^{N-1}  trit_i * 3^i
 *
 *   Example (4 trits, written MST-first):  +-0- = (+1)*27 + (-1)*9 + 0*3 + (-1)*1 = 17
 *
 *   Unlike two's-complement binary, balanced ternary is inherently signed:
 *   positive numbers have a positive most-significant trit, negative numbers
 *   have a negative one.  Negation is trivial -- just flip every trit.
 *
 *   The system was famously used by the Setun computer (Moscow State
 *   University, 1958), designed by Nikolay Brusentsov.  The Setun operated
 *   on 18-trit words and demonstrated that balanced ternary can simplify
 *   signed arithmetic, since addition, subtraction, and sign detection
 *   require no special cases.
 *
 *   See: Brusentsov, N.P. & Ramil Alvarez, J. (2011). "Ternary Computers:
 *   The Setun and the Setun 70." In: Perspectives on Soviet and Russian
 *   Computing, Springer.
 *
 * WHY 40 TRITS?
 *
 *   The ternary ALU (ternary.h) provides 120-trit registers.  A balanced
 *   ternary integer uses the lower 40 trits of a register.  This is the
 *   maximum that fits in a signed 64-bit integer for ABI transport:
 *
 *       (3^40 - 1) / 2  =  6,078,832,729,528,464,400  <  2^63 - 1
 *
 *   The representable range [-6.08e18, +6.08e18] exceeds 32-bit int
 *   (+-2.1e9) and approaches the full int64 range (+-9.2e18).
 *
 * WHY CLAMP TO 40 TRITS?
 *
 *   The ALU register is 120 trits wide, but we clamp to 40 to emulate
 *   a fixed-width ternary word.  This gives a stable sizeof(int) and
 *   makes overflow behaviour match real ternary hardware.  On a native
 *   ternary target, the clamp disappears — the ALU's register width
 *   enforces the same range.
 *
 * KLEENE THREE-VALUED LOGIC
 *
 *   Balanced ternary integers support Kleene's strong logic of
 *   indeterminacy natively, since every integer has a natural sign:
 *
 *       True    = any value  > 0
 *       Unknown = 0
 *       False   = any value  < 0
 *
 *   NOT (~):  True <-> False,  Unknown stays Unknown
 *   AND (&&): min(a, b)       -- short-circuits on False
 *   OR  (||): max(a, b)       -- short-circuits on True
 *
 *   Comparisons return +1 (True) or -1 (False), never 0 (Unknown).
 *============================================================================*/

/**
 * balanced3_t is a packed 40-trit balanced ternary integer.
 * Stored as a single uint64_t in biased encoding (same as treg_t.h[0]).
 * The ALU register (treg_t) is wider (120 trits, 24 bytes); values
 * are expanded on load and truncated on store.
 */
typedef unsigned long long balanced3_t;

/* ------------------------------------------------------------------ */
/*  Constants                                                         */
/* ------------------------------------------------------------------ */

#define BALANCED3_TRITS 40

/* ------------------------------------------------------------------ */
/*  Construction and conversion  (binary bridge)                      */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_from_int(int value);
balanced3_t balanced3_from_int64(long long value);
double balanced3_to_double(balanced3_t v);
int balanced3_to_int(balanced3_t v);
long long balanced3_to_int64(balanced3_t v);

/* ------------------------------------------------------------------ */
/*  Trit-level manipulation                                           */
/* ------------------------------------------------------------------ */

int balanced3_get_trit(balanced3_t v, int pos);
balanced3_t balanced3_set_trit(balanced3_t v, int pos, int trit);

/* ------------------------------------------------------------------ */
/*  Arithmetic  (via ternary ALU)                                     */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_add(balanced3_t a, balanced3_t b);
balanced3_t balanced3_sub(balanced3_t a, balanced3_t b);
balanced3_t balanced3_mul(balanced3_t a, balanced3_t b);
balanced3_t balanced3_div(balanced3_t a, balanced3_t b);
balanced3_t balanced3_mod(balanced3_t a, balanced3_t b);
balanced3_t balanced3_neg(balanced3_t v);

/* ------------------------------------------------------------------ */
/*  Kleene three-valued logic                                         */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_kleene_not(balanced3_t v);
balanced3_t balanced3_kleene_and(balanced3_t a, balanced3_t b);
balanced3_t balanced3_kleene_or(balanced3_t a, balanced3_t b);

/* ------------------------------------------------------------------ */
/*  Comparison  (returns balanced3 +1 or -1)                          */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_eq(balanced3_t a, balanced3_t b);
balanced3_t balanced3_ne(balanced3_t a, balanced3_t b);
balanced3_t balanced3_lt(balanced3_t a, balanced3_t b);
balanced3_t balanced3_gt(balanced3_t a, balanced3_t b);
balanced3_t balanced3_le(balanced3_t a, balanced3_t b);
balanced3_t balanced3_ge(balanced3_t a, balanced3_t b);

/* ------------------------------------------------------------------ */
/*  I/O  (crosses binary bridge)                                      */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_read(void);
void balanced3_print(balanced3_t v);
balanced3_t balanced3_from_string(const char *s);
const char *balanced3_to_decimal(balanced3_t v, char *buf, unsigned long len);
const char *balanced3_to_nonary(balanced3_t v, char *buf, unsigned long len);
const char *balanced3_to_balanced(balanced3_t v, char *buf, unsigned long len);

#include "takum3.h"
#include "lognum3.h"
#include "string.h"

/*============================================================================
 * takum3.c -- Logarithmic Ternary Takum Arithmetic (80 trits)
 *============================================================================
 *
 * Hunhold Definition 2 (2024) adapted for balanced ternary with base 3.
 * Fixed 2-trit regime field R, variable characteristic C, mantissa M.
 *
 * All arithmetic is performed via the ternary ALU (ternary.h).  Shared
 * transcendental and Gaussian logarithm routines are in lognum3.c.
 *
 * REGISTER ALLOCATION:
 *   T0..T7 are used by takum3/lognum3 operations.
 *   T8..T11 are reserved for balanced3 (see balanced3.c).
 *   T12..T15 are scratch / constants.
 *
 * SECTIONS:
 *   1. Predicates and trit access
 *   2. Decode / encode (packed takum3 <-> log L in register)
 *   3. Native arithmetic
 *   4. Conversion and I/O
 *   5. Comparison
 *============================================================================*/

/* Local aliases mapping to the shared lognum3 register convention. */
#define INT_TRITS    LOGNUM3_INT_TRITS

#define R0 LN_R0
#define R1 LN_R1
#define R2 LN_R2
#define R3 LN_R3
#define R4 LN_R4
#define R5 LN_R5
#define R6 LN_R6
#define R7 LN_R7
#define RSCRATCH  LN_RSCRATCH
#define RSCRATCH2 LN_RSCRATCH2
#define RSCRATCH3 LN_RSCRATCH3

#define R_LN3     LN_R_LN3
#define R_INVLN3  LN_R_INVLN3
#define R_LOG3_2  LN_R_LOG3_2
#define R_LOG3_10 LN_R_LOG3_10

/* Powers of 3 used for characteristic computation. */
static const int pow3[] = { 1, 3, 9, 27, 81, 243 };


/* ================================================================== */
/*  SECTION 1: PREDICATES AND TRIT ACCESS                             */
/* ================================================================== */

static void mask80(int r) {
  t_reg(r)->h[2] = T_HALF_BIAS;
}

static void takum3_load(int r, takum3_t v) {
  treg_t *reg = t_reg(r);
  reg->h[0] = v.h[0];
  reg->h[1] = v.h[1];
  reg->h[2] = T_HALF_BIAS;
}

static takum3_t takum3_read_reg(int r) {
  mask80(r);
  takum3_t v;
  v.h[0] = t_reg(r)->h[0];
  v.h[1] = t_reg(r)->h[1];
  return v;
}

int takum3_is_zero(takum3_t v) {
  return v.h[0] == T_HALF_BIAS && v.h[1] == T_HALF_BIAS;
}

int takum3_is_nar(takum3_t v) {
  return (v.h[0] == T_HALF_MAX && v.h[1] == T_HALF_MAX)
      || (v.h[0] == 0 && v.h[1] == 0);
}

int takum3_is_positive(takum3_t v) {
  return v.h[1] > T_HALF_BIAS
      || (v.h[1] == T_HALF_BIAS && v.h[0] > T_HALF_BIAS);
}

int takum3_is_negative(takum3_t v) {
  return v.h[1] < T_HALF_BIAS
      || (v.h[1] == T_HALF_BIAS && v.h[0] < T_HALF_BIAS);
}

int takum3_get_trit(takum3_t v, int pos) {
  if (pos < 0 || pos >= TAKUM3_TRITS) return 0;
  takum3_load(RSCRATCH, v);
  return t_get_trit(RSCRATCH, pos);
}

void takum3_set_trit(takum3_t *result, takum3_t v, int pos, int trit) {
  if (pos < 0 || pos >= TAKUM3_TRITS) { *result = v; return; }
  takum3_load(RSCRATCH, v);
  t_set_trit(RSCRATCH, pos, trit);
  mask80(RSCRATCH);
  *result = takum3_read_reg(RSCRATCH);
}

static takum3_t takum3_neg_val(takum3_t v) {
  takum3_load(RSCRATCH, v);
  t_neg(RSCRATCH, RSCRATCH);
  mask80(RSCRATCH);
  return takum3_read_reg(RSCRATCH);
}

void takum3_neg(takum3_t *result, takum3_t v) {
  *result = takum3_neg_val(v);
}

static takum3_t takum3_pack(unsigned long long h0, unsigned long long h1) {
  takum3_t v;
  v.h[0] = h0;
  v.h[1] = h1;
  return v;
}

#define TAKUM3_ZERO  takum3_pack(T_HALF_BIAS, T_HALF_BIAS)
#define TAKUM3_PNAR  takum3_pack(T_HALF_MAX,  T_HALF_MAX)
#define TAKUM3_NNAR  takum3_pack(0,           0)
#define TAKUM3_MAXFIN takum3_pack(T_HALF_MAX - 1, T_HALF_MAX)
#define TAKUM3_MINFIN takum3_pack(1,              0)
/* Smallest-magnitude finite values (for underflow saturation per Takum Sec. 4.2).
 * MIN_POS_FIN: MST=+1, all 79 other trits=-1.
 *   R_bal=-4 (r=4), C_unsigned=0 => c=-121.
 *   73 mantissa trits all -1 give m = -(1-3^-73)/2 ~= -1/2 (balanced ternary).
 *   L = c + m ~= -121.5, so v = 3^-121.5 ~= 1.071e-58.
 *   h[1] trits 40..79: trit 79=+1, trits 40..78=-1 => packed = 2*3^39
 *   h[0] all -1 => packed 0
 * MAX_NEG_FIN: trit-flip of MIN_POS_FIN (MST=-1, all others=+1). */
#define TAKUM3_MIN_POS_FIN takum3_pack(0ULL,                    8105110306037952534ULL)
#define TAKUM3_MAX_NEG_FIN takum3_pack(T_HALF_MAX,              4052555153018976266ULL)


/* ================================================================== */
/*  SECTION 2: DECODE / ENCODE  (Hunhold Definition 2)                */
/* ================================================================== */

/*
 * decode_log -- extract the fixed-point L = log_3(|value|) from a
 * takum3_t.  Stores L in register `dst`.  Returns the sign (+1 or -1)
 * and sets *is_nar if the value is NaR.
 *
 * Hunhold encoding:
 *   [+1] [R, 2 trits] [C, r trits] [M, 77-r trits]
 *   MST    78-77         76-...        remaining
 *
 * R_bal = R1*3 + R0 (balanced 2-trit integer, range [-4, +4])
 * r = max(1, |R_bal|)
 * C_unsigned = sum of (trit_i + 1) * 3^i over the r C trits
 * c = characteristic (from formula), L = c + mantissa fraction
 */
static int decode_log(int dst, takum3_t v, int *is_nar) {
  *is_nar = 0;
  if (takum3_is_zero(v)) { t_clear(dst); return 0; }
  if (takum3_is_nar(v))  { t_clear(dst); *is_nar = 1; return takum3_is_positive(v) ? 1 : -1; }

  int sign;
  if (takum3_is_negative(v)) { sign = -1; v = takum3_neg_val(v); }
  else { sign = 1; }

  takum3_load(RSCRATCH, v);

  /* Read R: 2 trits at positions 78 and 77 */
  int R1_trit = t_get_trit(RSCRATCH, 78);
  int R0_trit = t_get_trit(RSCRATCH, 77);
  int R_bal = R1_trit * 3 + R0_trit;

  /* r = max(1, |R_bal|) */
  int abs_R = (R_bal >= 0) ? R_bal : -R_bal;
  int r = (abs_R > 1) ? abs_R : 1;

  /* Read C: r trits from position 76 downward, MST first.
   * C_unsigned = sum of (trit + 1) * 3^i, i=0 at LST. */
  int C_unsigned = 0;
  int cursor = 76;
  for (int i = r - 1; i >= 0; i--) {
    int ct = (cursor >= 0) ? t_get_trit(RSCRATCH, cursor--) : 0;
    C_unsigned += (ct + 1) * pow3[i];
  }

  /* Compute c from R_bal and C_unsigned */
  int c;
  if (R_bal > 0)
    c = (pow3[r] + 1) / 2 + C_unsigned;
  else if (R_bal == 0)
    c = C_unsigned - 1;
  else
    c = -(pow3[r + 1] - 1) / 2 + C_unsigned;

  /* Build fixed-point L: integer part c + mantissa fraction from remaining trits */
  t_load_int(dst, c);
  t_shl(dst, dst, T_REG_TRITS - INT_TRITS);

  int frac_pos = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_pos >= 0; i--, frac_pos--)
    t_set_trit(dst, frac_pos, t_get_trit(RSCRATCH, i));

  return sign;
}

/*
 * encode_log -- encode a fixed-point L (in register `src`) and a sign
 * back into a packed takum3_t.
 *
 * 1. Extract integer part c = L_int.
 * 2. Determine R_bal and C_unsigned from c.
 * 3. Write: MST=+1, R (2 trits), C (r trits), M (remaining trits from L frac).
 * 4. Negate if sign < 0.
 */
static takum3_t encode_log(int src, int sign, int is_nar) {
  if (sign == 0) return TAKUM3_ZERO;
  if (is_nar) return (sign > 0) ? TAKUM3_PNAR : TAKUM3_NNAR;

  int c = (int)lognum3_extract_int_fp(src);

  /* Determine R_bal, r, C_unsigned from c */
  int R_bal, r, C_unsigned;

  if (c >= -1 && c <= 1) {
    /* Center band: R_bal = 0, r = 1 */
    R_bal = 0;
    r = 1;
    C_unsigned = c + 1;
  } else if (c >= 2) {
    /* Positive regime: find r such that (3^r+1)/2 <= c <= (3^(r+1)-1)/2 */
    r = 1;
    while (r < TAKUM3_MAX_R && c > (pow3[r + 1] - 1) / 2) r++;
    if (c > (pow3[r + 1] - 1) / 2) {
      /* overflow: saturate */
      return (sign > 0) ? TAKUM3_MAXFIN : TAKUM3_MINFIN;
    }
    R_bal = r;
    C_unsigned = c - (pow3[r] + 1) / 2;
  } else {
    /* Negative regime: find r such that -(3^(r+1)-1)/2 <= c <= -(3^r+1)/2 */
    r = 1;
    while (r < TAKUM3_MAX_R && c < -(pow3[r + 1] - 1) / 2) r++;
    if (c < -(pow3[r + 1] - 1) / 2) {
      /* underflow: saturate to smallest finite (Takum paper Sec. 4.2) */
      return (sign > 0) ? TAKUM3_MIN_POS_FIN : TAKUM3_MAX_NEG_FIN;
    }
    R_bal = -r;
    C_unsigned = c + (pow3[r + 1] - 1) / 2;
  }

  /* Build trit pattern in R0 */
  t_clear(R0);
  int cursor = TAKUM3_TRITS - 1;

  /* MST = +1 */
  t_set_trit(R0, cursor--, 1);

  /* R: 2 balanced trits encoding R_bal = R1*3 + R0 */
  int R0_trit = R_bal % 3;
  if (R0_trit > 1) R0_trit -= 3;
  if (R0_trit < -1) R0_trit += 3;
  int R1_trit = (R_bal - R0_trit) / 3;
  t_set_trit(R0, cursor--, R1_trit);  /* trit 78 */
  t_set_trit(R0, cursor--, R0_trit);  /* trit 77 */

  /* C: r trits, unsigned interpretation.
   * Convert C_unsigned to r ternary digits (0,1,2) then map to balanced (-1,0,+1). */
  {
    int c_trits[5];  /* max r = 4 */
    int tmp = C_unsigned;
    for (int i = 0; i < r; i++) {
      c_trits[i] = (tmp % 3) - 1;  /* 0->-1, 1->0, 2->+1 */
      tmp /= 3;
    }
    /* Write MST first (c_trits[r-1] at highest position) */
    for (int i = r - 1; i >= 0; i--)
      t_set_trit(R0, cursor--, c_trits[i]);
  }

  /* M: fraction trits from L's fractional part */
  int frac_src = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_src >= 0; i--, frac_src--)
    t_set_trit(R0, i, t_get_trit(src, frac_src));

  mask80(R0);
  takum3_t result = takum3_read_reg(R0);

  if (sign < 0) result = takum3_neg_val(result);
  return result;
}


/* ================================================================== */
/*  SECTION 3: NATIVE ARITHMETIC                                      */
/* ================================================================== */

void takum3_mul(takum3_t *result, takum3_t a, takum3_t b) {
  lognum3_init();
  if (takum3_is_nar(a)) { *result = a; return; }
  if (takum3_is_nar(b)) { *result = b; return; }
  if (takum3_is_zero(a) || takum3_is_zero(b)) {
    *result = TAKUM3_ZERO; return;
  }

  int nar_a, nar_b;
  int sa = decode_log(R0, a, &nar_a);
  int sb = decode_log(R1, b, &nar_b);

  t_add(R2, R0, R1);
  *result = encode_log(R2, sa * sb, 0);
}

void takum3_div(takum3_t *result, takum3_t a, takum3_t b) {
  lognum3_init();
  if (takum3_is_nar(a)) { *result = a; return; }
  if (takum3_is_zero(b)) {
    *result = (takum3_is_zero(a) || takum3_is_positive(a)) ? TAKUM3_PNAR : TAKUM3_NNAR;
    return;
  }
  if (takum3_is_nar(b)) { *result = TAKUM3_ZERO; return; }
  if (takum3_is_zero(a)) { *result = TAKUM3_ZERO; return; }

  int nar_a, nar_b;
  int sa = decode_log(R0, a, &nar_a);
  int sb = decode_log(R1, b, &nar_b);

  t_sub(R2, R0, R1);
  *result = encode_log(R2, sa * sb, 0);
}

static takum3_t takum3_add_val(takum3_t a, takum3_t b) {
  lognum3_init();
  if (takum3_is_nar(a)) return a;
  if (takum3_is_nar(b)) return b;
  if (takum3_is_zero(a)) return b;
  if (takum3_is_zero(b)) return a;

  int nar_a, nar_b;
  int sa = decode_log(R0, a, &nar_a);
  int sb = decode_log(R1, b, &nar_b);

  /* ensure |a| >= |b|: larger L = larger magnitude */
  if (t_cmp(R1, R0) > 0) {
    t_copy(R2, R0); t_copy(R0, R1); t_copy(R1, R2);
    int tmp = sa; sa = sb; sb = tmp;
  }

  /* d = L_b - L_a (<=0) */
  t_sub(R2, R1, R0);

  /* Save L_a: gauss_phi/psi clobber R0-R4 and all scratch registers */
  treg_t saved_La = *t_reg(R0);

  if (sa == sb) {
    lognum3_gauss_phi(R3, R2);
    *t_reg(R0) = saved_La;
    t_add(R4, R0, R3);
    return encode_log(R4, sa, 0);
  } else {
    if (t_is_zero(R2))
      return TAKUM3_ZERO;
    lognum3_gauss_psi(R3, R2);
    *t_reg(R0) = saved_La;
    t_add(R4, R0, R3);
    return encode_log(R4, sa, 0);
  }
}

void takum3_add(takum3_t *result, takum3_t a, takum3_t b) {
  *result = takum3_add_val(a, b);
}

void takum3_sub(takum3_t *result, takum3_t a, takum3_t b) {
  lognum3_init();
  if (takum3_is_nar(a)) { *result = a; return; }
  if (takum3_is_nar(b)) { *result = b; return; }
  *result = takum3_add_val(a, takum3_neg_val(b));
}


/* ================================================================== */
/*  SECTION 4: CONVERSION AND I/O                                     */
/* ================================================================== */

void takum3_from_double(takum3_t *result, double d) {
  if (d == 0.0) { *result = TAKUM3_ZERO; return; }
  lognum3_init();

  int negative = 0;
  if (d < 0.0) { negative = 1; d = -d; }

  int k = 0;
  double d_red = d;
  while (d_red >= 3.0) { d_red /= 3.0; k++; }
  while (d_red < 1.0)  { d_red *= 3.0;  k--; }

  if (k > 121) {
    *result = negative ? TAKUM3_MINFIN : TAKUM3_MAXFIN; return;
  }
  if (k < -121) {
    *result = negative ? TAKUM3_MAX_NEG_FIN : TAKUM3_MIN_POS_FIN; return;
  }

  int frac = T_REG_TRITS - INT_TRITS;

  if (k >= 0 && d <= 265720.0) {
    t_load_double(R0, d, INT_TRITS);
    if (k > 0) t_shr(R0, R0, k);
  } else {
    t_load_double(R0, d_red, INT_TRITS);
  }

  t_load_int(R1, 1);
  t_shl(R1, R1, frac);
  t_sub(R2, R0, R1);
  t_add(R3, R0, R1);
  lognum3_div_fp(R2, R2, R3);
  lognum3_atanh_small(R3, R2);
  t_add(R3, R3, R3);
  lognum3_mul_fp(R2, R3, R_INVLN3);

  t_load_int(R3, k);
  t_shl(R3, R3, frac);
  t_add(RSCRATCH, R3, R2);

  *result = encode_log(RSCRATCH, negative ? -1 : 1, 0);
}

double takum3_to_double(takum3_t v) {
  if (takum3_is_zero(v)) return 0.0;
  if (takum3_is_nar(v)) {
    return takum3_is_positive(v) ? 1.7976931348623157e+308 : -1.7976931348623157e+308;
  }

  int is_nar;
  int sign = decode_log(R0, v, &is_nar);

  double L = t_store_double(R0, INT_TRITS);

  int L_int = (int)L;
  double L_frac = L - L_int;

  double val = 1.0;
  if (L_int >= 0) { for (int i = 0; i < L_int; i++) val *= 3.0; }
  else { for (int i = 0; i < -L_int; i++) val /= 3.0; }

  double x = L_frac * 1.0986122886681098;
  double exp_x = 1.0, term = 1.0;
  for (int i = 1; i < 30; i++) { term *= x / i; exp_x += term; }
  val *= exp_x;

  return (sign < 0) ? -val : val;
}

void takum3_from_balanced3(takum3_t *result, balanced3_t b3) {
  lognum3_init();

  /* Load balanced3 (40 trits) into ALU register -- pure ternary */
  treg_t *reg = t_reg(R0);
  reg->h[0] = b3;
  reg->h[1] = T_HALF_BIAS;
  reg->h[2] = T_HALF_BIAS;

  long long val = t_store_int(R0);
  if (val == 0) { *result = TAKUM3_ZERO; return; }

  int negative = 0;
  if (val < 0) { negative = 1; val = -val; t_neg(R0, R0); mask80(R0); }

  /* k = floor(log₃(|val|)) so that d_red = |val|/3^k ∈ [1,3) */
  int k = 0;
  { long long tmp = val; while (tmp >= 3) { tmp /= 3; k++; } }

  /* Place d_red in fixed-point: shift so MST sits at the 3^0 position */
  int frac = T_REG_TRITS - INT_TRITS;
  t_shl(R0, R0, frac - k);

  /* log₃(d') = 2·atanh((d'-1)/(d'+1)) / ln(3) */
  t_load_int(R1, 1);
  t_shl(R1, R1, frac);
  t_sub(R2, R0, R1);
  t_add(R3, R0, R1);
  lognum3_div_fp(R2, R2, R3);
  lognum3_atanh_small(R3, R2);
  t_add(R3, R3, R3);
  lognum3_mul_fp(R2, R3, R_INVLN3);

  t_load_int(R3, k);
  t_shl(R3, R3, frac);
  t_add(RSCRATCH, R3, R2);

  *result = encode_log(RSCRATCH, negative ? -1 : 1, 0);
}

balanced3_t takum3_to_balanced3(takum3_t v) {
  if (takum3_is_zero(v)) return balanced3_from_int(0);
  if (takum3_is_nar(v))  return balanced3_from_int(0);

  int is_nar;
  int sign = decode_log(R0, v, &is_nar);

  /* 3^L in the ternary ALU (fixed-point result) */
  lognum3_3_to_d(R1, R0);

  /* Extract integer part from fixed-point and apply sign */
  long long ival = lognum3_extract_int_fp(R1);
  if (sign < 0) ival = -ival;
  return balanced3_from_int64(ival);
}

/*
 * takum3_print -- native ternary decimal output in scientific notation.
 *
 * Same algorithm as posit3_print: decode → compute decimal mantissa → output.
 */
#define TAKUM3_FRAC_DIGITS 36

void takum3_print(takum3_t v) {
  lognum3_init();
  if (takum3_is_zero(v)) { prints("0"); return; }
  if (takum3_is_nar(v)) {
    prints(takum3_is_positive(v) ? "+NaR" : "-NaR");
    return;
  }

  int is_nar;
  int sign = decode_log(R0, v, &is_nar);
  if (sign < 0) prints("-");

  int frac_trits = T_REG_TRITS - INT_TRITS;

  long long L_int = lognum3_extract_int_fp(R0);
  int dec_exp = 0;

  if (L_int > 0)
    dec_exp = (int)(L_int * 47712LL / 100000LL);
  else if (L_int < 0)
    dec_exp = (int)((L_int * 47712LL - 99999LL) / 100000LL);

  if (dec_exp != 0) {
    t_load_int(R3, (long long)dec_exp);
    t_shl(R3, R3, frac_trits);
    lognum3_mul_fp(R3, R3, R_LOG3_10);
    t_sub(R0, R0, R3);
  }

  lognum3_3_to_d(R1, R0);

  t_copy(R2, R1);
  t_shr(R2, R2, frac_trits);
  long long int_part = t_store_int(R2);

  int safety = 20;
  while (int_part >= 10 && safety-- > 0) {
    t_div_small(R1, R1, 10);
    dec_exp++;
    t_copy(R2, R1);
    t_shr(R2, R2, frac_trits);
    int_part = t_store_int(R2);
  }
  safety = 20;
  while (int_part <= 0 && !t_is_zero(R1) && safety-- > 0) {
    t_shl(R2, R1, 2);
    t_add(R1, R2, R1);
    dec_exp--;
    t_copy(R2, R1);
    t_shr(R2, R2, frac_trits);
    int_part = t_store_int(R2);
  }

  if (int_part < 1) int_part = 1;
  if (int_part > 9) int_part = 9;

  t_load_int(R2, int_part);
  t_shl(R2, R2, frac_trits);
  t_sub(R1, R1, R2);

  if (t_sign(R1) < 0) {
    int_part--;
    if (int_part < 1) { int_part = 9; dec_exp--; }
    t_load_int(R2, 1);
    t_shl(R2, R2, frac_trits);
    t_add(R1, R1, R2);
  }

  char lbuf[2] = { '0' + (int)int_part, '\0' };
  prints(lbuf);

  if (!t_is_zero(R1)) {
    char fbuf[TAKUM3_FRAC_DIGITS + 2];
    fbuf[0] = '.';
    int flen = 1;
    int trailing_zeros = 0;

    for (int i = 0; i < TAKUM3_FRAC_DIGITS; i++) {
      t_shl(R2, R1, 2);
      t_add(R2, R2, R1);

      t_copy(RSCRATCH, R2);
      t_shr(RSCRATCH, RSCRATCH, frac_trits);
      int digit = (int)t_store_int(RSCRATCH);

      t_shl(RSCRATCH, RSCRATCH, frac_trits);
      t_sub(R1, R2, RSCRATCH);

      if (t_sign(R1) < 0) {
        digit--;
        t_load_int(RSCRATCH, 1);
        t_shl(RSCRATCH, RSCRATCH, frac_trits);
        t_add(R1, R1, RSCRATCH);
      }

      if (digit < 0) digit = 0;
      if (digit > 9) digit = 9;

      if (digit == 0) {
        trailing_zeros++;
      } else {
        for (int z = 0; z < trailing_zeros; z++)
          fbuf[flen++] = '0';
        trailing_zeros = 0;
        fbuf[flen++] = '0' + digit;
      }

      if (t_is_zero(R1)) break;
    }

    fbuf[flen] = '\0';
    if (flen > 1)
      prints(fbuf);
  }

  if (dec_exp != 0) {
    char ebuf[20];
    int epos = 19;
    ebuf[epos] = '\0';
    int abs_exp = dec_exp < 0 ? -dec_exp : dec_exp;
    while (abs_exp > 0) {
      ebuf[--epos] = '0' + (abs_exp % 10);
      abs_exp /= 10;
    }
    ebuf[--epos] = dec_exp < 0 ? '-' : '+';
    ebuf[--epos] = 'e';
    prints(ebuf + epos);
  }
}

void takum3_read(takum3_t *result) {
  char buf[128];
  if (readln(buf, 128) == 0) { *result = TAKUM3_ZERO; return; }
  takum3_from_string(result, buf);
}

void takum3_from_string(takum3_t *result, const char *s) {
  int sign = lognum3_parse_decimal(RSCRATCH, s);
  if (sign == 0) { *result = TAKUM3_ZERO; return; }
  *result = encode_log(RSCRATCH, sign, 0);
}


/* ================================================================== */
/*  SECTION 5: COMPARISON                                             */
/* ================================================================== */

static int takum3_cmp_packed(takum3_t a, takum3_t b) {
  if (a.h[1] > b.h[1]) return 1;
  if (a.h[1] < b.h[1]) return -1;
  if (a.h[0] > b.h[0]) return 1;
  if (a.h[0] < b.h[0]) return -1;
  return 0;
}

balanced3_t takum3_eq(takum3_t a, takum3_t b) {
  return balanced3_from_int(takum3_cmp_packed(a, b) == 0 ? 1 : -1);
}
balanced3_t takum3_ne(takum3_t a, takum3_t b) {
  return balanced3_from_int(takum3_cmp_packed(a, b) != 0 ? 1 : -1);
}
balanced3_t takum3_lt(takum3_t a, takum3_t b) {
  return balanced3_from_int(takum3_cmp_packed(a, b) < 0 ? 1 : -1);
}
balanced3_t takum3_gt(takum3_t a, takum3_t b) {
  return balanced3_from_int(takum3_cmp_packed(a, b) > 0 ? 1 : -1);
}
balanced3_t takum3_le(takum3_t a, takum3_t b) {
  return balanced3_from_int(takum3_cmp_packed(a, b) <= 0 ? 1 : -1);
}
balanced3_t takum3_ge(takum3_t a, takum3_t b) {
  return balanced3_from_int(takum3_cmp_packed(a, b) >= 0 ? 1 : -1);
}

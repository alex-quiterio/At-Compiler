#include "posit3.h"
#include "takum3.h"
#include "lognum3.h"

/*============================================================================
 * lognum3_convert.c -- Direct posit3 <-> takum3 conversion (no float)
 *============================================================================
 *
 * Both formats represent values as sign * 3^L, where L is a fixed-point
 * logarithm.  They differ only in how L's integer part (the characteristic
 * c) is packed into the regime/exponent fields.
 *
 * Conversion decodes L from the source format and re-encodes it in the
 * target format, preserving full ternary precision.  Only the ALU
 * primitives (t_get_trit, t_set_trit, t_load_int, t_shl, etc.) and the
 * public type predicates are used.
 *============================================================================*/

#define INT_TRITS  LOGNUM3_INT_TRITS

/* ALU register aliases (local to this file). */
#define R0 LN_R0
#define R1 LN_R1
#define RSCRATCH LN_RSCRATCH

static const int pow3[] = { 1, 3, 9, 27, 81, 243 };

/* ------------------------------------------------------------------ */
/*  Helpers: load/read packed values into/from ALU registers           */
/* ------------------------------------------------------------------ */

static void load80(int r, const unsigned long long h[2]) {
  treg_t *reg = t_reg(r);
  reg->h[0] = h[0];
  reg->h[1] = h[1];
  reg->h[2] = T_HALF_BIAS;
}

static void read80(int r, unsigned long long h[2]) {
  t_reg(r)->h[2] = T_HALF_BIAS;
  h[0] = t_reg(r)->h[0];
  h[1] = t_reg(r)->h[1];
}

static void negate80(int r) {
  t_neg(r, r);
  t_reg(r)->h[2] = T_HALF_BIAS;
}

/* ------------------------------------------------------------------ */
/*  Posit3 decode: variable regime + 2-trit exponent, GROWTH = 9      */
/* ------------------------------------------------------------------ */

static int posit3_decode(int dst, posit3_t v) {
  if (posit3_is_zero(v)) { t_clear(dst); return 0; }
  if (posit3_is_nar(v))  { t_clear(dst); return 0; }

  int sign;
  if (posit3_is_negative(v)) {
    sign = -1;
    load80(RSCRATCH, v.h);
    negate80(RSCRATCH);
  } else {
    sign = 1;
    load80(RSCRATCH, v.h);
  }

  int cursor = POSIT3_TRITS - 2;  /* trit 78 */
  int regime = 0;

  int run_trit = t_get_trit(RSCRATCH, cursor);
  if (run_trit == 1) {
    while (cursor >= 0 && t_get_trit(RSCRATCH, cursor) == 1)
      { regime++; cursor--; }
    if (cursor >= 0) cursor--;
  } else if (run_trit == -1) {
    while (cursor >= 0 && t_get_trit(RSCRATCH, cursor) == -1)
      { regime--; cursor--; }
    if (cursor >= 0) cursor--;
  } else {
    cursor--;
  }

  int e1 = 0, e0 = 0;
  if (cursor >= 0) { e1 = t_get_trit(RSCRATCH, cursor); cursor--; }
  if (cursor >= 0) { e0 = t_get_trit(RSCRATCH, cursor); cursor--; }
  int L_int = regime * POSIT3_GROWTH + e1 * 3 + e0;

  t_load_int(dst, L_int);
  t_shl(dst, dst, T_REG_TRITS - INT_TRITS);

  int frac_pos = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_pos >= 0; i--, frac_pos--)
    t_set_trit(dst, frac_pos, t_get_trit(RSCRATCH, i));

  return sign;
}

/* ------------------------------------------------------------------ */
/*  Takum3 decode: fixed 2-trit R + variable characteristic           */
/* ------------------------------------------------------------------ */

static int takum3_decode(int dst, takum3_t v) {
  if (takum3_is_zero(v)) { t_clear(dst); return 0; }
  if (takum3_is_nar(v))  { t_clear(dst); return 0; }

  int sign;
  if (takum3_is_negative(v)) {
    sign = -1;
    load80(RSCRATCH, v.h);
    negate80(RSCRATCH);
  } else {
    sign = 1;
    load80(RSCRATCH, v.h);
  }

  int R1_trit = t_get_trit(RSCRATCH, 78);
  int R0_trit = t_get_trit(RSCRATCH, 77);
  int R_bal = R1_trit * 3 + R0_trit;

  int abs_R = (R_bal >= 0) ? R_bal : -R_bal;
  int r = (abs_R > 1) ? abs_R : 1;

  int C_unsigned = 0;
  int cursor = 76;
  for (int i = r - 1; i >= 0; i--) {
    int ct = (cursor >= 0) ? t_get_trit(RSCRATCH, cursor--) : 0;
    C_unsigned += (ct + 1) * pow3[i];
  }

  int c;
  if (R_bal > 0)
    c = (pow3[r] + 1) / 2 + C_unsigned;
  else if (R_bal == 0)
    c = C_unsigned - 1;
  else
    c = -(pow3[r + 1] - 1) / 2 + C_unsigned;

  t_load_int(dst, c);
  t_shl(dst, dst, T_REG_TRITS - INT_TRITS);

  int frac_pos = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_pos >= 0; i--, frac_pos--)
    t_set_trit(dst, frac_pos, t_get_trit(RSCRATCH, i));

  return sign;
}

/* ------------------------------------------------------------------ */
/*  Posit3 encode: from fixed-point L in register src                 */
/* ------------------------------------------------------------------ */

static posit3_t posit3_encode(int src, int sign) {
  posit3_t zero = {{ T_HALF_BIAS, T_HALF_BIAS }};
  if (sign == 0) return zero;

  int L_int = (int)lognum3_extract_int_fp(src);

  int regime = L_int / POSIT3_GROWTH;
  int exp_field = L_int - regime * POSIT3_GROWTH;
  while (exp_field > 4)  { regime++; exp_field -= POSIT3_GROWTH; }
  while (exp_field < -4) { regime--; exp_field += POSIT3_GROWTH; }

  int abs_regime = (regime >= 0) ? regime : -regime;
  if (abs_regime >= POSIT3_REGIME_MAX) {
    if (regime > 0) {
      /* Saturate: all trits +1 except MST pattern for MAXFIN/MINFIN.
       * Use the predicate-based approach: build from known extreme L. */
      t_load_int(R0, regime > 0 ? 700 : -700);
      t_shl(R0, R0, T_REG_TRITS - INT_TRITS);
      return posit3_encode(R0, sign);
    }
    /* underflow: smallest finite */
    t_load_int(R0, regime < 0 ? -700 : 700);
    t_shl(R0, R0, T_REG_TRITS - INT_TRITS);
    return posit3_encode(R0, sign);
  }

  t_clear(R0);
  int cursor = POSIT3_TRITS - 1;

  t_set_trit(R0, cursor--, 1);

  if (regime > 0) {
    for (int i = 0; i < regime && cursor >= 0; i++)
      t_set_trit(R0, cursor--, 1);
    if (cursor >= 0) t_set_trit(R0, cursor--, 0);
  } else if (regime < 0) {
    for (int i = 0; i < -regime && cursor >= 0; i++)
      t_set_trit(R0, cursor--, -1);
    if (cursor >= 0) t_set_trit(R0, cursor--, 0);
  } else {
    if (cursor >= 0) t_set_trit(R0, cursor--, 0);
  }

  int r0 = exp_field % 3;
  if (r0 > 1) r0 -= 3;
  if (r0 < -1) r0 += 3;
  int r1 = (exp_field - r0) / 3;
  if (r1 > 1) r1 -= 3;
  if (r1 < -1) r1 += 3;
  if (cursor >= 0) t_set_trit(R0, cursor--, r1);
  if (cursor >= 0) t_set_trit(R0, cursor--, r0);

  int frac_src = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_src >= 0; i--, frac_src--)
    t_set_trit(R0, i, t_get_trit(src, frac_src));

  t_reg(R0)->h[2] = T_HALF_BIAS;
  posit3_t result;
  result.h[0] = t_reg(R0)->h[0];
  result.h[1] = t_reg(R0)->h[1];

  if (sign < 0) {
    load80(R0, result.h);
    negate80(R0);
    read80(R0, result.h);
  }
  return result;
}

/* ------------------------------------------------------------------ */
/*  Takum3 encode: from fixed-point L in register src                 */
/* ------------------------------------------------------------------ */

static takum3_t takum3_encode(int src, int sign) {
  takum3_t zero = {{ T_HALF_BIAS, T_HALF_BIAS }};
  if (sign == 0) return zero;

  int c = (int)lognum3_extract_int_fp(src);

  int R_bal, r, C_unsigned;

  if (c >= -1 && c <= 1) {
    R_bal = 0;
    r = 1;
    C_unsigned = c + 1;
  } else if (c >= 2) {
    r = 1;
    while (r < TAKUM3_MAX_R && c > (pow3[r + 1] - 1) / 2) r++;
    if (c > (pow3[r + 1] - 1) / 2) {
      /* overflow saturate */
      takum3_t sat;
      sat.h[0] = T_HALF_MAX; sat.h[1] = T_HALF_MAX;
      if (sign < 0) { load80(R0, sat.h); negate80(R0); read80(R0, sat.h); }
      return sat;
    }
    R_bal = r;
    C_unsigned = c - (pow3[r] + 1) / 2;
  } else {
    r = 1;
    while (r < TAKUM3_MAX_R && c < -(pow3[r + 1] - 1) / 2) r++;
    if (c < -(pow3[r + 1] - 1) / 2) {
      takum3_t sat;
      sat.h[0] = 0; sat.h[1] = 0;
      if (sign > 0) { load80(R0, sat.h); negate80(R0); read80(R0, sat.h); }
      return sat;
    }
    R_bal = -r;
    C_unsigned = c + (pow3[r + 1] - 1) / 2;
  }

  t_clear(R0);
  int cursor = TAKUM3_TRITS - 1;

  t_set_trit(R0, cursor--, 1);

  int R0_trit = R_bal % 3;
  if (R0_trit > 1) R0_trit -= 3;
  if (R0_trit < -1) R0_trit += 3;
  int R1_trit = (R_bal - R0_trit) / 3;
  t_set_trit(R0, cursor--, R1_trit);
  t_set_trit(R0, cursor--, R0_trit);

  {
    int c_trits[5];
    int tmp = C_unsigned;
    for (int i = 0; i < r; i++) {
      c_trits[i] = (tmp % 3) - 1;
      tmp /= 3;
    }
    for (int i = r - 1; i >= 0; i--)
      t_set_trit(R0, cursor--, c_trits[i]);
  }

  int frac_src = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_src >= 0; i--, frac_src--)
    t_set_trit(R0, i, t_get_trit(src, frac_src));

  t_reg(R0)->h[2] = T_HALF_BIAS;
  takum3_t result;
  result.h[0] = t_reg(R0)->h[0];
  result.h[1] = t_reg(R0)->h[1];

  if (sign < 0) {
    load80(R0, result.h);
    negate80(R0);
    read80(R0, result.h);
  }
  return result;
}

/* ================================================================== */
/*  Public API                                                         */
/* ================================================================== */

void posit3_from_takum3(posit3_t *result, takum3_t t) {
  lognum3_init();
  int sign = takum3_decode(R1, t);
  if (sign == 0) {
    result->h[0] = T_HALF_BIAS;
    result->h[1] = T_HALF_BIAS;
    return;
  }
  *result = posit3_encode(R1, sign);
}

void takum3_from_posit3(takum3_t *result, posit3_t p) {
  lognum3_init();
  int sign = posit3_decode(R1, p);
  if (sign == 0) {
    result->h[0] = T_HALF_BIAS;
    result->h[1] = T_HALF_BIAS;
    return;
  }
  *result = takum3_encode(R1, sign);
}

#pragma once

/*============================================================================
 * ternary.h -- Balanced Ternary ALU Simulator
 *============================================================================
 *
 * OVERVIEW
 *
 *   This module simulates a balanced ternary arithmetic-logic unit (ALU)
 *   with a small register file.  It is the ONLY module in the RTS that
 *   directly manipulates binary C types to implement ternary operations.
 *   All other ternary modules (balanced3, posit3, takum3) are built exclusively
 *   on top of this interface.
 *
 *   The design is inspired by the Setun computer (Moscow State University,
 *   1958, Nikolay Brusentsov), which used 18-trit words and a ternary ALU
 *   with balanced ternary full adders.  This simulator extends the concept
 *   to 120-trit registers -- wide enough for extended-precision ternary
 *   real arithmetic.
 *
 * REGISTER FORMAT
 *
 *   Each register holds 120 balanced ternary trits, stored in three
 *   "packed halves" of 40 trits each.  Each half uses mixed-radix
 *   packing into a 64-bit unsigned integer:
 *
 *       packed_half = sum_{i=0}^{39} (trit_i + 1) * 3^i
 *
 *   This maps balanced trits {-1, 0, +1} to unsigned digits {0, 1, 2}.
 *   The ordering is preserved: larger balanced values produce larger
 *   packed values.
 *
 *       Half 0 (lo):  trits   0-39   (least significant)
 *       Half 1 (mi):  trits  40-79
 *       Half 2 (hi):  trits  80-119  (most significant)
 *
 *   The total information content is 120 * log2(3) ≈ 190.2 bits,
 *   stored in 24 bytes.
 *
 * REGISTER FILE
 *
 *   16 general-purpose registers, T0 through T15.  The register count
 *   is sufficient for complex operations like the Gaussian logarithm
 *   series evaluation, which requires ~8 simultaneous temporaries.
 *
 *   Two additional "special" views:
 *     - Double-width results: t_mul produces a 240-trit result in a
 *       register pair (Rlo, Rhi).
 *     - Carry flag: t_add/t_sub return the carry-out trit.
 *
 * OPERATIONS
 *
 *   All operations work on register indices (0..15).  Results are
 *   written to a destination register.  The operations are:
 *
 *   Arithmetic:  t_add, t_sub, t_mul, t_div, t_mod, t_neg
 *   Shifts:      t_shl, t_shr  (trit shifts, not bit shifts)
 *   Comparison:  t_cmp  (returns -1, 0, +1 as a trit)
 *   Trit access: t_get_trit, t_set_trit
 *   Load/Store:  t_clear, t_copy, t_load_trits, t_store_trits
 *
 * BINARY BRIDGE
 *
 *   The following functions cross the binary/ternary boundary.  They
 *   are the ONLY mechanism by which binary values enter or leave the
 *   ternary domain:
 *
 *   t_load_int(reg, long long)        -- binary int -> ternary register
 *   t_store_int(reg) -> long long     -- ternary register -> binary int
 *   t_load_double(reg, double)        -- binary float -> ternary fixed-pt
 *   t_store_double(reg) -> double     -- ternary fixed-pt -> binary float
 *   t_load_packed(reg, lo, mi, hi)    -- raw packed halves -> register
 *   t_store_packed(reg, &lo, &mi, &hi)-- register -> raw packed halves
 *
 *   These exist because the host machine (x86) is binary.  On a native
 *   ternary machine, they would be replaced by direct register access.
 *============================================================================*/

/*--------------------------------------------------------------------------
 * Register type.
 *
 * Three 40-trit halves packed into unsigned 64-bit integers.
 * Total: 120 trits, 24 bytes.
 *--------------------------------------------------------------------------*/
typedef struct {
  unsigned long long h[3];  /* h[0]=lo (trits 0-39), h[1]=mi (40-79), h[2]=hi (80-119) */
} treg_t;

/* ------------------------------------------------------------------ */
/*  Constants                                                         */
/* ------------------------------------------------------------------ */

/** Trits per register. */
#define T_REG_TRITS       120

/** Trits per packed half. */
#define T_HALF_TRITS       40

/** Number of packed halves per register. */
#define T_HALVES            3

/** Number of registers in the register file. */
#define T_NUM_REGS         16

/** 3^40 - 1: maximum packed value for one half (all +1 trits). */
#define T_HALF_MAX  12157665459056928800ULL

/** (3^40 - 1) / 2: bias for balanced -> standard conversion. */
#define T_HALF_BIAS  6078832729528464400ULL

/** Register indices (symbolic names for readability). */
enum reg_index : unsigned int {
    T0  = 0,
    T1  = 1,
    T2  = 2,
    T3  = 3,
    T4  = 4,
    T5  = 5,
    T6  = 6,
    T7  = 7,
    T8  = 8,
    T9  = 9,
    T10 = 10,
    T11 = 11,
    T12 = 12,
    T13 = 13,
    T14 = 14,
    T15 = 15
};

/* ------------------------------------------------------------------ */
/*  Register file access                                              */
/* ------------------------------------------------------------------ */

/** Get a pointer to register `r` (0..15). */
treg_t *t_reg(int r);

/** Clear register `r` to all-zero trits. */
void t_clear(int r);

/** Copy register `src` to register `dst`. */
void t_copy(int dst, int src);

/* ------------------------------------------------------------------ */
/*  Trit-level access                                                 */
/* ------------------------------------------------------------------ */

/**
 * Get the balanced trit at position `pos` of register `r`.
 * pos 0 = LST (least significant), pos 119 = MST (most significant).
 * Returns -1, 0, or +1.
 */
int t_get_trit(int r, int pos);

/**
 * Set the trit at position `pos` of register `r`.
 * `trit` must be -1, 0, or +1.
 */
void t_set_trit(int r, int pos, int trit);

/* ------------------------------------------------------------------ */
/*  Arithmetic                                                        */
/*                                                                    */
/*  All operations:  dst = src_a OP src_b                             */
/*  src and dst may overlap.                                          */
/* ------------------------------------------------------------------ */

/**
 * Add:  dst = a + b.
 * Returns the carry-out trit (-1, 0, or +1).
 */
int t_add(int dst, int a, int b);

/**
 * Subtract:  dst = a - b.
 * Returns the borrow-out trit.
 */
int t_sub(int dst, int a, int b);

/**
 * Multiply:  (dst_hi : dst_lo) = a * b.
 * Produces a 240-trit result across two registers.
 * dst_lo gets trits 0-119, dst_hi gets trits 120-239.
 */
void t_mul(int dst_lo, int dst_hi, int a, int b);

/**
 * Divide:  dst_quot = a / b,  dst_rem = a % b.
 * Uses balanced ternary restoring long division.
 * dst_quot and dst_rem may be the same register (remainder is lost).
 */
void t_div(int dst_quot, int dst_rem, int a, int b);

/**
 * Negate:  dst = -src  (flip every trit).
 */
void t_neg(int dst, int src);

/* ------------------------------------------------------------------ */
/*  Shifts (trit positions, not bit positions)                        */
/* ------------------------------------------------------------------ */

/**
 * Shift left by `n` trit positions (multiply by 3^n).
 * Trits shifted past the MST are lost.
 */
void t_shl(int dst, int src, int n);

/**
 * Shift right by `n` trit positions (divide by 3^n, truncate).
 * Trits shifted past the LST are lost.
 */
void t_shr(int dst, int src, int n);

/* ------------------------------------------------------------------ */
/*  Comparison                                                        */
/* ------------------------------------------------------------------ */

/**
 * Three-way compare:
 *   returns +1 if reg[a] > reg[b]
 *   returns  0 if reg[a] == reg[b]
 *   returns -1 if reg[a] < reg[b]
 */
int t_cmp(int a, int b);

/**
 * Test sign of register `r`:
 *   returns +1 if positive (MST non-zero trit is +1)
 *   returns  0 if zero (all trits are 0)
 *   returns -1 if negative (MST non-zero trit is -1)
 */
int t_sign(int r);

/** True if register `r` is all-zero trits. */
int t_is_zero(int r);

/* ------------------------------------------------------------------ */
/*  Bulk trit load/store (for encode/decode)                          */
/* ------------------------------------------------------------------ */

/**
 * Load `n` trits from array `trits[]` (MST-first) into register `r`,
 * starting at trit position `start_pos`.  Remaining trits are unchanged.
 * This is used to pack/unpack fields (regime, exponent, fraction).
 */
void t_load_trits(int r, const int *trits, int n, int start_pos);

/**
 * Store `n` trits from register `r` starting at trit position
 * `start_pos` into array `trits[]` (MST-first).
 */
void t_store_trits(int r, int *trits, int n, int start_pos);

/* ------------------------------------------------------------------ */
/*  Binary bridge                                                     */
/*                                                                    */
/*  These are the ONLY functions that cross the ternary/binary        */
/*  boundary.  On a native ternary machine, they would be replaced    */
/*  by direct register ↔ memory transfers.                            */
/* ------------------------------------------------------------------ */

/**
 * Load a binary integer into register `r`.
 * The value is converted to balanced ternary.  If it exceeds the
 * 120-trit range, it is clamped.
 */
void t_load_int(int r, long long value);

/**
 * Store register `r` as a binary integer (long long).
 * If the ternary value exceeds int64 range, it is clamped.
 */
long long t_store_int(int r);

/**
 * Load a double into register `r` as a balanced ternary fixed-point
 * number with `int_trits` integer trits and the rest as fraction.
 *
 * The double is decomposed into balanced ternary digits MST-first
 * using greedy extraction.
 */
void t_load_double(int r, double value, int int_trits);

/**
 * Store register `r` as a double, interpreting it as a fixed-point
 * number with `int_trits` integer trits.
 */
double t_store_double(int r, int int_trits);

/**
 * Load raw packed halves into register `r`.
 * Used to interface with the x86 ABI representation of posit3_t.
 */
void t_load_packed(int r, unsigned long long lo,
                   unsigned long long mi, unsigned long long hi);

/**
 * Store register `r` as raw packed halves.
 */
void t_store_packed(int r, unsigned long long *lo,
                    unsigned long long *mi, unsigned long long *hi);

/**
 * Divide register `a` by a small positive integer `k` (k < 100),
 * store quotient in `dst`.  Uses fast sequential division.
 * This crosses the binary bridge because `k` is a binary int.
 */
void t_div_small(int dst, int a, int k);

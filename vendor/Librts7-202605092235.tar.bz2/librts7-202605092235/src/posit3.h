#pragma once

#include "ternary.h"
#include "balanced3.h"

/*============================================================================
 * posit3.h -- Ternary Posit Real Number Arithmetic (80 trits)
 *============================================================================
 *
 * WHAT IS A POSIT?
 *
 *   Posit numbers are a real-number format created by John L. Gustafson,
 *   using logarithmic, tapered precision via a variable-length regime.
 *   Near 1.0 almost all digits go to the fraction (high precision); for
 *   extreme magnitudes, digits shift toward the regime (high range).
 *
 *   See: Gustafson, J. & Yonemoto, I. (2017). "Beating Floating Point
 *   at its Own Game: Posit Arithmetic." DOI:10.14529/jsfi170206
 *
 *   This implementation adapts the concept to balanced ternary, exploiting
 *   the natural sign symmetry: negation is a trit-flip, and no separate
 *   sign digit is required.
 *
 * WHY 80 TRITS?
 *
 *   The ternary ALU (ternary.h) provides 120-trit registers.  A posit3
 *   occupies the lower 80 trits (trits 0-79).  The upper 40 trits are
 *   zero in stored values but available as headroom during computation.
 *
 *   80 trits carry  80 * log2(3) ~ 126.8 bits  of information:
 *
 *       Precision near 1.0:  ~76 fraction trits ~ 36 decimal digits
 *       Range:  up to ~ 3^702 ~ 10^335
 *
 * LOGARITHMIC ENCODING
 *
 *   The regime, exponent, and fraction fields together form a single
 *   fixed-point balanced ternary representation of log_3(|value|).
 *
 *   For a POSITIVE posit3 (MST = +1, trit 79):
 *
 *       [MST=+1] [regime] [exponent: 2 trits] [fraction: remaining]
 *
 *   VALUE FORMULA:
 *     L = regime * 9 + exponent + fraction
 *     value = +3^L
 *
 *   NEGATION: flip all trits.  value = -3^L.
 *
 *   SPECIAL VALUES:
 *     All 0 trits  -> exact zero
 *     All +1 trits -> +NaR (Not-a-Real)
 *     All -1 trits -> -NaR
 *
 * ARITHMETIC
 *
 *   Multiplication/division: add/subtract the L fields (exact, O(n)).
 *   Addition/subtraction: Gaussian logarithm via convergent series,
 *   evaluated entirely in the ternary ALU.
 *============================================================================*/

/**
 * posit3_t is a packed 80-trit logarithmic ternary posit.
 * Stored as two uint64_t halves in biased encoding (same layout as
 * treg_t.h[0..1]).  The ALU register (treg_t) is wider (120 trits,
 * 24 bytes); values are expanded on load and truncated on store.
 */
typedef struct {
  unsigned long long h[2];  /* h[0] = trits 0-39, h[1] = trits 40-79 */
} posit3_t;

/* ------------------------------------------------------------------ */
/*  Constants                                                         */
/* ------------------------------------------------------------------ */

#define POSIT3_TRITS          80
#define POSIT3_E_SIZE          2
#define POSIT3_GROWTH          9
#define POSIT3_REGIME_MAX     78

/* ------------------------------------------------------------------ */
/*  Predicates                                                        */
/* ------------------------------------------------------------------ */

int posit3_is_zero(posit3_t v);
int posit3_is_nar(posit3_t v);
int posit3_is_positive(posit3_t v);
int posit3_is_negative(posit3_t v);

/* ------------------------------------------------------------------ */
/*  Trit-level access                                                 */
/* ------------------------------------------------------------------ */

int posit3_get_trit(posit3_t v, int pos);
void posit3_set_trit(posit3_t *result, posit3_t v, int pos, int trit);

/* ------------------------------------------------------------------ */
/*  Construction and conversion  (binary bridge)                      */
/* ------------------------------------------------------------------ */

void posit3_from_double(posit3_t *result, double d);
double posit3_to_double(posit3_t v);
void posit3_from_balanced3(posit3_t *result, balanced3_t b3);
balanced3_t posit3_to_balanced3(posit3_t v);

/* ------------------------------------------------------------------ */
/*  Arithmetic  (native ternary ALU, no binary intermediate)          */
/* ------------------------------------------------------------------ */

void posit3_add(posit3_t *result, posit3_t a, posit3_t b);
void posit3_sub(posit3_t *result, posit3_t a, posit3_t b);
void posit3_mul(posit3_t *result, posit3_t a, posit3_t b);
void posit3_div(posit3_t *result, posit3_t a, posit3_t b);
void posit3_neg(posit3_t *result, posit3_t v);

/* ------------------------------------------------------------------ */
/*  Comparison  (returns balanced3_t: +1 True, -1 False)              */
/* ------------------------------------------------------------------ */

balanced3_t posit3_eq(posit3_t a, posit3_t b);
balanced3_t posit3_ne(posit3_t a, posit3_t b);
balanced3_t posit3_lt(posit3_t a, posit3_t b);
balanced3_t posit3_gt(posit3_t a, posit3_t b);
balanced3_t posit3_le(posit3_t a, posit3_t b);
balanced3_t posit3_ge(posit3_t a, posit3_t b);

/* ------------------------------------------------------------------ */
/*  I/O  (crosses binary bridge)                                      */
/* ------------------------------------------------------------------ */

void posit3_read(posit3_t *result);
void posit3_print(posit3_t v);
void posit3_from_string(posit3_t *result, const char *s);

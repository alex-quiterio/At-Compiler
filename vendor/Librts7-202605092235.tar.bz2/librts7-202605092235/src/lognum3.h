#pragma once

#include "ternary.h"

/*============================================================================
 * lognum3.h -- Shared Logarithmic Number Infrastructure (Ternary)
 *============================================================================
 *
 * This module provides the common arithmetic, transcendental, and Gaussian
 * logarithm routines used by both posit3 and takum3.  Both formats represent
 * values as sign * 3^L, where L is a fixed-point logarithm stored in the
 * ternary ALU.  The encode/decode between packed formats and L is format-
 * specific; everything else is shared here.
 *
 * Fixed-point format:
 *   INT_TRITS = 12 integer trits (range ±265720), remaining 108 fractional.
 *   Stored in 120-trit ALU registers.
 *
 * REGISTER ALLOCATION:
 *   T0..T7 are used by lognum3 / posit3 / takum3 operations.
 *   T8..T11 are reserved for balanced3 (see balanced3.c).
 *   T12..T15 are scratch / constants.
 *============================================================================*/

/* Fixed-point parameters */
#define LOGNUM3_INT_TRITS    12
#define LOGNUM3_ATANH_TERMS 90
#define LOGNUM3_EXP_TERMS   30

/* ALU register aliases (shared by posit3 and takum3). */
#define LN_R0 T0
#define LN_R1 T1
#define LN_R2 T2
#define LN_R3 T3
#define LN_R4 T4
#define LN_R5 T5
#define LN_R6 T6
#define LN_R7 T7
#define LN_RSCRATCH  T13
#define LN_RSCRATCH2 T14
#define LN_RSCRATCH3 T15

/* Constant registers (loaded on first use by lognum3_init). */
#define LN_R_LN3      LN_R5
#define LN_R_INVLN3   LN_R6
#define LN_R_LOG3_2   LN_R7
#define LN_R_LOG3_10  T12

/* ------------------------------------------------------------------ */
/*  Initialization                                                     */
/* ------------------------------------------------------------------ */

/** Load precomputed constants (ln3, 1/ln3, log3_2, log3_10). Idempotent. */
void lognum3_init(void);

/* ------------------------------------------------------------------ */
/*  Fixed-point helpers                                                */
/* ------------------------------------------------------------------ */

/** Fixed-point multiply: dst = a * b. */
void lognum3_mul_fp(int dst, int a, int b);

/** Fixed-point divide: dst = num / den (240-trit extended long division). */
void lognum3_div_fp(int dst, int num, int den);

/** Extract integer part of a fixed-point register (Horner, INT_TRITS). */
long long lognum3_extract_int_fp(int src);

/* ------------------------------------------------------------------ */
/*  Transcendental series                                              */
/* ------------------------------------------------------------------ */

/** exp(x) for |x| < 1, Horner evaluation. */
void lognum3_exp_small(int dst, int src);

/** atanh(z) for |z| < 0.5, direct summation. */
void lognum3_atanh_small(int dst, int src);

/** 3^d where d is fixed-point: d = d_int + d_frac, 3^d = shift * exp. */
void lognum3_3_to_d(int dst, int src);

/* ------------------------------------------------------------------ */
/*  Gaussian logarithm                                                 */
/* ------------------------------------------------------------------ */

/** phi(d) = log_3(1 + 3^d), for d <= 0. */
void lognum3_gauss_phi(int dst, int src);

/** psi(d) = log_3(1 - 3^d), for d < 0. */
void lognum3_gauss_psi(int dst, int src);

/* ------------------------------------------------------------------ */
/*  Decimal string parsing                                             */
/* ------------------------------------------------------------------ */

/**
 * Parse a decimal string into log₃(|value|) in fixed-point register dst.
 * Returns the sign: -1, 0, or +1.  On zero/invalid input, returns 0 and
 * clears dst.  Uses only the ternary ALU (no double intermediate).
 */
int lognum3_parse_decimal(int dst, const char *s);

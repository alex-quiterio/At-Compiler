#include "balanced3.h"
#include "string.h"

/*============================================================================
 * balanced3.c -- Balanced Ternary Integer Arithmetic (40 trits)
 *============================================================================
 *
 * All arithmetic is performed via the ternary ALU (ternary.h).  This
 * file is a thin wrapper that:
 *
 *   1. Manages loading/storing values into ALU registers.
 *   2. Masks results to 40 trits (the integer word width).
 *   3. Provides I/O (string conversion) which necessarily crosses
 *      the binary bridge.
 *
 * The ALU registers used by this module are T8..T11 (reserved for
 * balanced3 operations, avoiding collision with posit3 which uses
 * T0..T7).  Local operations use them transiently and leave no
 * persistent state.
 *============================================================================*/

#define BALANCED3_BUFSIZE 128UL

/* ALU registers reserved for balanced3 temporaries */
#define RA T8
#define RB T9
#define RC T10
#define RD T11

/* ------------------------------------------------------------------ */
/*  Internal: mask to 40 trits                                        */
/*                                                                    */
/*  After ALU operations, trits 40-119 may be non-zero (e.g., from   */
/*  carry propagation).  We zero them to enforce the 40-trit word.   */
/*  On real ternary hardware, this would be the natural register      */
/*  width — no masking needed.                                        */
/* ------------------------------------------------------------------ */

static void mask40(int r) {
  /* trits 40-119 = zero means halves 1 and 2 are at bias */
  treg_t *reg = t_reg(r);
  reg->h[1] = T_HALF_BIAS;
  reg->h[2] = T_HALF_BIAS;
}

/* Load a balanced3 value (8-byte packed) into an ALU register (24-byte). */
static void load_reg(int r, balanced3_t v) {
  treg_t *reg = t_reg(r);
  reg->h[0] = v;
  reg->h[1] = T_HALF_BIAS;
  reg->h[2] = T_HALF_BIAS;
}

/* Read an ALU register as a balanced3 value (masked to 40 trits). */
static balanced3_t read_reg(int r) {
  mask40(r);
  return t_reg(r)->h[0];
}

/* ------------------------------------------------------------------ */
/*  Construction and conversion  (binary bridge)                      */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_from_int(int value) {
  t_load_int(RA, (long long)value);
  return read_reg(RA);
}

balanced3_t balanced3_from_int64(long long value) {
  t_load_int(RA, value);
  return read_reg(RA);
}

double balanced3_to_double(balanced3_t v) {
  load_reg(RA, v);
  return (double)t_store_int(RA);
}

int balanced3_to_int(balanced3_t v) {
  load_reg(RA, v);
  long long val = t_store_int(RA);
  if (val > 2147483647LL) return 2147483647;
  if (val < -2147483648LL) return -2147483648;
  return (int)val;
}

long long balanced3_to_int64(balanced3_t v) {
  load_reg(RA, v);
  return t_store_int(RA);
}

/* ------------------------------------------------------------------ */
/*  Trit-level manipulation                                           */
/* ------------------------------------------------------------------ */

int balanced3_get_trit(balanced3_t v, int pos) {
  if (pos < 0 || pos >= BALANCED3_TRITS) return 0;
  load_reg(RA, v);
  return t_get_trit(RA, pos);
}

balanced3_t balanced3_set_trit(balanced3_t v, int pos, int trit) {
  if (pos < 0 || pos >= BALANCED3_TRITS) return v;
  load_reg(RA, v);
  t_set_trit(RA, pos, trit);
  return read_reg(RA);
}

/* ------------------------------------------------------------------ */
/*  Arithmetic                                                        */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_add(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  t_add(RC, RA, RB);
  return read_reg(RC);
}

balanced3_t balanced3_sub(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  t_sub(RC, RA, RB);
  return read_reg(RC);
}

balanced3_t balanced3_mul(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  t_mul(RC, RD, RA, RB);   /* low 120 trits in RC, high in RD */
  return read_reg(RC);      /* mask to 40 trits (overflow discarded) */
}

balanced3_t balanced3_div(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  t_div(RC, RD, RA, RB);   /* quotient in RC, remainder in RD */
  return read_reg(RC);
}

balanced3_t balanced3_mod(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  t_div(RC, RD, RA, RB);
  return read_reg(RD);
}

balanced3_t balanced3_neg(balanced3_t v) {
  load_reg(RA, v);
  t_neg(RC, RA);
  return read_reg(RC);
}

/* ------------------------------------------------------------------ */
/*  Kleene three-valued logic                                         */
/* ------------------------------------------------------------------ */

balanced3_t balanced3_kleene_not(balanced3_t v) {
  load_reg(RA, v);
  int s = t_sign(RA);
  if (s > 0)       return balanced3_from_int(-1);
  else if (s < 0)  return balanced3_from_int(1);
  else              return balanced3_from_int(0);
}

balanced3_t balanced3_kleene_and(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  return (t_cmp(RA, RB) < 0) ? a : b;
}

balanced3_t balanced3_kleene_or(balanced3_t a, balanced3_t b) {
  load_reg(RA, a);
  load_reg(RB, b);
  return (t_cmp(RA, RB) > 0) ? a : b;
}

/* ------------------------------------------------------------------ */
/*  Comparison                                                        */
/* ------------------------------------------------------------------ */

static balanced3_t kleene_true(void)  { return balanced3_from_int(1); }
static balanced3_t kleene_false(void) { return balanced3_from_int(-1); }

balanced3_t balanced3_eq(balanced3_t a, balanced3_t b) {
  load_reg(RA, a); load_reg(RB, b);
  return (t_cmp(RA, RB) == 0) ? kleene_true() : kleene_false();
}

balanced3_t balanced3_ne(balanced3_t a, balanced3_t b) {
  load_reg(RA, a); load_reg(RB, b);
  return (t_cmp(RA, RB) != 0) ? kleene_true() : kleene_false();
}

balanced3_t balanced3_lt(balanced3_t a, balanced3_t b) {
  load_reg(RA, a); load_reg(RB, b);
  return (t_cmp(RA, RB) < 0) ? kleene_true() : kleene_false();
}

balanced3_t balanced3_gt(balanced3_t a, balanced3_t b) {
  load_reg(RA, a); load_reg(RB, b);
  return (t_cmp(RA, RB) > 0) ? kleene_true() : kleene_false();
}

balanced3_t balanced3_le(balanced3_t a, balanced3_t b) {
  load_reg(RA, a); load_reg(RB, b);
  return (t_cmp(RA, RB) <= 0) ? kleene_true() : kleene_false();
}

balanced3_t balanced3_ge(balanced3_t a, balanced3_t b) {
  load_reg(RA, a); load_reg(RB, b);
  return (t_cmp(RA, RB) >= 0) ? kleene_true() : kleene_false();
}

/* ------------------------------------------------------------------ */
/*  I/O  (crosses binary bridge)                                      */
/* ------------------------------------------------------------------ */

const char *balanced3_to_decimal(balanced3_t v, char *buf, unsigned long len) {
  if (len < 2) return nullptr; /* Minimum for "0" + \0 */
  buf[len - 1] = '\0';
  char *p = buf + len - 1;

  load_reg(RA, v);
  if (t_is_zero(RA)) { *--p = '0'; return p; }

  int neg = (t_sign(RA) < 0);
  long long val = t_store_int(RA);
  unsigned long long mag = neg ? (unsigned long long)(-(val + 1)) + 1
                               : (unsigned long long)val;

  while (mag != 0) {
    /* Abort if buffer is too small (reserving space for a potential '-') */
    if (p <= buf + (neg ? 1 : 0)) return nullptr;
    *--p = '0' + (int)(mag % 10);
    mag /= 10;
  }
  if (neg) *--p = '-';
  return p;
}

const char *balanced3_to_nonary(balanced3_t v, char *buf, unsigned long len) {
  if (len < 4) return nullptr;
  buf[len - 1] = '\0';
  char *p = buf + len - 1;

  load_reg(RA, v);
  if (t_is_zero(RA)) {
    *--p = '0'; *--p = 'n'; *--p = '0';
    return p;
  }

  int neg = (t_sign(RA) < 0);
  long long val = t_store_int(RA);
  unsigned long long mag = neg ? (unsigned long long)(-(val + 1)) + 1
                               : (unsigned long long)val;

  while (mag != 0) {
    /* Abort if out of space (reserving 2 bytes for "0n" + 1 for "-") */
    if (p <= buf + (neg ? 1 : 0) + 2) return nullptr;
    *--p = '0' + (int)(mag % 9);
    mag /= 9;
  }
  *--p = 'n'; *--p = '0';
  if (neg) *--p = '-';
  return p;
}

const char *balanced3_to_balanced(balanced3_t v, char *buf, unsigned long len) {
  if (len < 4) return nullptr;
  buf[len - 1] = '\0';

  load_reg(RA, v);
  if (t_is_zero(RA)) {
    buf[0] = '0'; buf[1] = 't'; buf[2] = '0'; buf[3] = '\0';
    return buf;
  }

  /* find MST */
  int mst = BALANCED3_TRITS - 1;
  while (mst > 0 && t_get_trit(RA, mst) == 0) mst--;

  /* Ensure buffer can hold: "0t" (2) + trits (mst + 1) + '\0' (1) */
  if (len < (unsigned long)(mst + 4)) return nullptr;

  char *p = buf;
  *p++ = '0'; *p++ = 't';
  for (int i = mst; i >= 0; i--) {
    int t = t_get_trit(RA, i);
    if (t == 1)       *p++ = '+';
    else if (t == -1) *p++ = '-';
    else              *p++ = '0';
  }
  *p = '\0';
  return buf;
}

/* --- string -> balanced3 parsers ---------------------------------- */

static balanced3_t parse_decimal(const char *s) {
  int neg = 0;
  if (*s == '-') { neg = 1; s++; }
  else if (*s == '+') { s++; }
  while (*s == '0') s++;

  long long result = 0;
  while (*s >= '0' && *s <= '9')
    result = result * 10 + (*s++ - '0');

  return balanced3_from_int64(neg ? -result : result);
}

static balanced3_t parse_nonary(const char *s) {
  long long result = 0;
  int count = 0;
  /* Max 20 nonary digits fits within 40 trits */
  while (*s >= '0' && *s <= '8' && count < 20) {
    result = result * 9 + (*s++ - '0');
    count++;
  }
  return balanced3_from_int64(result);
}

static balanced3_t parse_balanced(const char *s) {
  long long result = 0;
  int count = 0;
  /* Limit to word size to prevent long long overflow */
  while ((*s == '+' || *s == '0' || *s == '-') && count < BALANCED3_TRITS) {
    int trit = (*s == '+') ? 1 : (*s == '-') ? -1 : 0;
    result = result * 3 + trit;
    s++;
    count++;
  }
  return balanced3_from_int64(result);
}

balanced3_t balanced3_from_string(const char *s) {
  while (*s == ' ') s++;
  if (s[0] == '0' && s[1] == 'n') return parse_nonary(s + 2);
  if (s[0] == '0' && s[1] == 't') return parse_balanced(s + 2);
  if (s[0] == '-' && s[1] == '0' && s[2] == 'n') return balanced3_neg(parse_nonary(s + 3));
  if (s[0] == '-' && s[1] == '0' && s[2] == 't') return balanced3_neg(parse_balanced(s + 3));
  return parse_decimal(s);
}

void balanced3_print(balanced3_t v) {
  char buf[BALANCED3_BUFSIZE];
  prints(balanced3_to_decimal(v, buf, BALANCED3_BUFSIZE));
}

balanced3_t balanced3_read(void) {
  char buf[BALANCED3_BUFSIZE];
  if (readln(buf, BALANCED3_BUFSIZE) == 0) return balanced3_from_int(0);
  return balanced3_from_string(buf);
}

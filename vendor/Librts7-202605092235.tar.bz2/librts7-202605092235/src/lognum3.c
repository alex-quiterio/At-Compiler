#include "lognum3.h"

/*============================================================================
 * lognum3.c -- Shared Logarithmic Number Infrastructure (Ternary)
 *============================================================================
 *
 * All arithmetic is performed via the ternary ALU (ternary.h).  This
 * file never performs binary arithmetic on trit data -- every operation
 * goes through t_add, t_sub, t_mul, t_div, t_neg, t_shl, t_shr, etc.
 *
 * The binary bridge (t_load_int, t_store_int) is crossed ONLY in
 * conversion/initialization functions.
 *============================================================================*/

#define INT_TRITS    LOGNUM3_INT_TRITS
#define ATANH_TERMS  LOGNUM3_ATANH_TERMS
#define EXP_TERMS    LOGNUM3_EXP_TERMS

/* Local aliases for brevity */
#define R0 LN_R0
#define R1 LN_R1
#define R2 LN_R2
#define R3 LN_R3
#define R4 LN_R4
#define R5 LN_R5
#define R6 LN_R6
#define R7 LN_R7
#define RSCRATCH  LN_RSCRATCH
#define RSCRATCH2 LN_RSCRATCH2
#define RSCRATCH3 LN_RSCRATCH3

#define R_LN3     LN_R_LN3
#define R_INVLN3  LN_R_INVLN3
#define R_LOG3_2  LN_R_LOG3_2
#define R_LOG3_10 LN_R_LOG3_10


/* ================================================================== */
/*  SECTION 1: CONSTANTS                                              */
/* ================================================================== */

static int constants_loaded = 0;

void lognum3_init(void) {
  if (constants_loaded) return;

  int frac = T_REG_TRITS - INT_TRITS;

  /*
   * ln(3) = 2*atanh(1/2), since (3-1)/(3+1) = 1/2.
   */
  t_load_int(R0, 1);
  t_shl(R0, R0, frac);            /* R0 = 1.0 in fixed-point */
  t_div_small(R0, R0, 2);         /* R0 = 0.5 */
  lognum3_atanh_small(R1, R0);    /* R1 = atanh(0.5) */
  t_add(R_LN3, R1, R1);           /* R_LN3 = ln(3) = 2*atanh(0.5) */

  /*
   * 1/ln(3) via fixed-point division.
   */
  t_load_int(R0, 1);
  t_shl(R0, R0, frac);            /* R0 = 1.0 */
  lognum3_div_fp(R_INVLN3, R0, R_LN3);

  /*
   * log_3(2) = ln(2)/ln(3) = ln(2)*(1/ln(3)).
   * ln(2) = 2*atanh(1/3), since (2-1)/(2+1) = 1/3.
   */
  t_load_int(R0, 1);
  t_shl(R0, R0, frac);            /* R0 = 1.0 */
  t_div_small(R0, R0, 3);         /* R0 = 1/3 */
  lognum3_atanh_small(R1, R0);    /* R1 = atanh(1/3) */
  t_add(R0, R1, R1);              /* R0 = ln(2) = 2*atanh(1/3) */
  lognum3_mul_fp(R_LOG3_2, R0, R_INVLN3);

  /*
   * log_3(10) = 2 + log_3(10/9).
   * log_3(10/9) = ln(10/9)/ln(3) = 2*atanh(1/19)*(1/ln(3)),
   * since (10/9 - 1)/(10/9 + 1) = 1/19.
   */
  t_load_int(R0, 1);
  t_shl(R0, R0, frac);            /* R0 = 1.0 */
  t_div_small(R0, R0, 19);        /* R0 = 1/19 */
  lognum3_atanh_small(R1, R0);    /* R1 = atanh(1/19) */
  t_add(R0, R1, R1);              /* R0 = 2*atanh(1/19) */
  lognum3_mul_fp(R0, R0, R_INVLN3);
  t_load_int(R1, 2);
  t_shl(R1, R1, frac);            /* R1 = 2.0 */
  t_add(R_LOG3_10, R1, R0);       /* R_LOG3_10 = log_3(10) */

  constants_loaded = 1;
}


/* ================================================================== */
/*  SECTION 2: FIXED-POINT HELPERS                                    */
/* ================================================================== */

void lognum3_mul_fp(int dst, int a, int b) {
  int frac = T_REG_TRITS - INT_TRITS;
  t_mul(RSCRATCH, RSCRATCH2, a, b);
  t_shr(RSCRATCH, RSCRATCH, frac);
  t_shl(RSCRATCH2, RSCRATCH2, INT_TRITS);
  t_add(dst, RSCRATCH, RSCRATCH2);
}

static int norm_trit(int d, int *carry) {
  int adj = d + 1;
  int c = (adj >= 0) ? adj / 3 : (adj - 2) / 3;
  *carry = c;
  return d - c * 3;
}

static int abs_cmp_trits(const int *a, const int *b, int len) {
  int sa = 0, sb = 0;
  for (int i = len - 1; i >= 0; i--) {
    if (sa == 0 && a[i] != 0) sa = (a[i] > 0) ? 1 : -1;
    if (sb == 0 && b[i] != 0) sb = (b[i] > 0) ? 1 : -1;
    if (sa != 0 && sb != 0) break;
  }
  if (sa == 0 && sb == 0) return 0;
  if (sa == 0) return -1;
  if (sb == 0) return 1;
  for (int i = len - 1; i >= 0; i--) {
    int va = a[i] * sa, vb = b[i] * sb;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

void lognum3_div_fp(int dst, int num, int den) {
  int frac = T_REG_TRITS - INT_TRITS;
  int N = T_REG_TRITS;
  int N2 = N * 2;

  int td[120];
  for (int i = 0; i < N; i++) td[i] = t_get_trit(den, i);

  int rem[120], rp[120], rn[120], qt[120];
  for (int i = 0; i < N; i++) { rem[i] = 0; qt[i] = 0; }

  for (int k = N2 - 1; k >= 0; k--) {
    for (int i = N - 1; i > 0; i--) rem[i] = rem[i - 1];
    rem[0] = (k >= frac && k < frac + N) ? t_get_trit(num, k - frac) : 0;

    int carry_p = 0;
    for (int i = 0; i < N; i++) {
      int s = rem[i] - td[i] + carry_p;
      rp[i] = norm_trit(s, &carry_p);
    }
    int carry_n = 0;
    for (int i = 0; i < N; i++) {
      int s = rem[i] + td[i] + carry_n;
      rn[i] = norm_trit(s, &carry_n);
    }

    int cp = abs_cmp_trits(rp, rem, N);
    int cn = abs_cmp_trits(rn, rem, N);

    int q = 0;
    if (cp <= 0 && abs_cmp_trits(rp, rn, N) <= 0) {
      q = 1;
      for (int i = 0; i < N; i++) rem[i] = rp[i];
    } else if (cn <= 0) {
      q = -1;
      for (int i = 0; i < N; i++) rem[i] = rn[i];
    }

    if (k < N) qt[k] = q;
  }

  t_clear(dst);
  for (int i = 0; i < N; i++)
    t_set_trit(dst, i, qt[i]);
}

/*
 * Extract integer part of a fixed-point L register.
 *
 * IMPLICIT ROUND-TO-NEAREST: the takum paper prescribes geometric-mean
 * rounding in the logarithmic domain (symmetric about zero so positive
 * and negative errors cancel).  Because L is a *balanced* ternary
 * fixed-point quantity, each fractional trit is drawn from {-1, 0, +1}
 * and any fractional tail represents a value in [-1/2, +1/2] about the
 * next integer step.  A simple arithmetic right-shift (t_shr) by the
 * fractional width therefore truncates the fraction toward zero, which
 * in balanced ternary IS round-to-nearest -- no rounding logic, no bias
 * correction, no sign branching.  This is a direct consequence of the
 * balanced radix, not an approximation.
 */
long long lognum3_extract_int_fp(int src) {
  int frac = T_REG_TRITS - INT_TRITS;
  t_copy(RSCRATCH3, src);
  t_shr(RSCRATCH3, RSCRATCH3, frac);
  return t_store_int(RSCRATCH3);
}


/* ================================================================== */
/*  SECTION 3: TRANSCENDENTALS                                        */
/* ================================================================== */

/*
 * exp(x) for |x| < 1.
 *   exp(x) = 1 + x*(1 + x/2*(1 + x/3*(...)))
 * Horner from inside out: s = 1; for k = N..1: s = 1 + (x*s)/k
 */
void lognum3_exp_small(int dst, int src) {
  t_load_int(dst, 1);
  t_shl(dst, dst, T_REG_TRITS - INT_TRITS);

  for (int k = EXP_TERMS; k >= 1; k--) {
    lognum3_mul_fp(RSCRATCH, src, dst);
    t_div_small(dst, RSCRATCH, k);
    t_load_int(RSCRATCH, 1);
    t_shl(RSCRATCH, RSCRATCH, T_REG_TRITS - INT_TRITS);
    t_add(dst, dst, RSCRATCH);
  }
}

/*
 * atanh(z) for |z| < 0.5.
 *   atanh(z) = z + z^3/3 + z^5/5 + ...
 */
void lognum3_atanh_small(int dst, int src) {
  /* R_W = z², R_P = z^(2k+1) running power, dst = accumulator.
   * R_W and R_P must not alias dst, src, RSCRATCH, or RSCRATCH2.
   * Pick the first two free registers from {R0..R4}. */
  int pool[] = { R0, R1, R2, R3, R4 };
  int R_W = -1, R_P = -1;
  for (int i = 0; i < 5 && R_P < 0; i++) {
    int r = pool[i];
    if (r == dst || r == src || r == RSCRATCH || r == RSCRATCH2) continue;
    if (R_W < 0) R_W = r; else R_P = r;
  }

  t_copy(R_P, src);               /* R_P = z (save before mul_fp may alias src) */
  lognum3_mul_fp(R_W, src, src);  /* R_W = z² */
  t_copy(dst, R_P);               /* dst = z (accumulator) */

  for (int k = 1; k <= ATANH_TERMS; k++) {
    lognum3_mul_fp(R_P, R_P, R_W);
    if (t_is_zero(R_P)) break;
    t_div_small(RSCRATCH, R_P, 2 * k + 1);
    t_add(dst, dst, RSCRATCH);
  }
}

/*
 * 3^d where d is fixed-point.
 * Decomposition: d = d_int + d_frac; 3^d = 3^d_int * exp(d_frac * ln(3)).
 */
void lognum3_3_to_d(int dst, int src) {
  int d_int = (int)lognum3_extract_int_fp(src);
  t_load_int(RSCRATCH3, d_int);
  t_shl(RSCRATCH3, RSCRATCH3, T_REG_TRITS - INT_TRITS);
  t_sub(R4, src, RSCRATCH3);  /* R4 = d_frac */

  lognum3_mul_fp(R4, R4, R_LN3);

  lognum3_exp_small(dst, R4);

  if (d_int > 0)
    t_shl(dst, dst, d_int);
  else if (d_int < 0)
    t_shr(dst, dst, -d_int);
}


/* ================================================================== */
/*  SECTION 4: GAUSSIAN LOGARITHM                                    */
/* ================================================================== */

/*
 * phi(d) = log_3(1 + 3^d), for d <= 0.
 */
void lognum3_gauss_phi(int dst, int src) {
  if (t_is_zero(src)) {
    t_copy(dst, R_LOG3_2);
    return;
  }

  {
    long long d_val = lognum3_extract_int_fp(src);
    if (d_val < -80) { t_clear(dst); return; }
  }

  lognum3_3_to_d(R0, src);  /* R0 = u = 3^d */

  t_load_int(R1, 2);
  t_shl(R1, R1, T_REG_TRITS - INT_TRITS);
  t_add(R1, R1, R0);   /* R1 = 2 + u */
  lognum3_div_fp(R2, R0, R1);  /* R2 = z = u/(2+u) fixed-point */

  lognum3_atanh_small(R3, R2);  /* R3 = atanh(z) */

  t_add(R3, R3, R3);   /* ln(1+u) = 2*atanh(z) */

  lognum3_mul_fp(dst, R3, R_INVLN3);
}

/*
 * psi(d) = log_3(1 - 3^d), for d < 0.
 */
void lognum3_gauss_psi(int dst, int src) {
  {
    long long d_val = lognum3_extract_int_fp(src);
    if (d_val < -80) { t_clear(dst); return; }
  }

  lognum3_3_to_d(R0, src);  /* R0 = u = 3^d */

  t_load_int(R1, 1);
  t_shl(R1, R1, T_REG_TRITS - INT_TRITS);
  t_sub(R1, R1, R0);   /* R1 = v = 1 - u */

  if (t_is_zero(R1)) {
    t_load_int(dst, -700);
    t_shl(dst, dst, T_REG_TRITS - INT_TRITS);
    return;
  }

  /* reduce v to [1/3, 1) */
  int k = 0;
  t_load_int(R2, 1);
  t_shl(R2, R2, T_REG_TRITS - INT_TRITS);
  t_shr(R2, R2, 1);  /* R2 = 1/3 */

  t_load_int(R3, 1);
  t_shl(R3, R3, T_REG_TRITS - INT_TRITS);  /* R3 = 1.0 */

  while (t_cmp(R1, R2) < 0 && k < 120) {
    t_shl(R1, R1, 1);
    k++;
  }
  while (t_cmp(R1, R3) >= 0) {
    t_shr(R1, R1, 1);
    k--;
  }

  /* z = (v - 1) / (v + 1) */
  t_load_int(R2, 1);
  t_shl(R2, R2, T_REG_TRITS - INT_TRITS);
  t_sub(R3, R1, R2);
  t_add(R4, R1, R2);
  lognum3_div_fp(R3, R3, R4);  /* R3 = z */

  lognum3_atanh_small(R4, R3);  /* R4 = atanh(z) */

  t_add(R4, R4, R4);   /* ln(v') = 2*atanh(z) */

  lognum3_mul_fp(R3, R4, R_INVLN3);  /* log3(v') */

  t_load_int(R4, -k);
  t_shl(R4, R4, T_REG_TRITS - INT_TRITS);
  t_add(dst, R4, R3);
}


/* ================================================================== */
/*  SECTION 5: DECIMAL STRING PARSING                                 */
/* ================================================================== */

int lognum3_parse_decimal(int dst, const char *s) {
  lognum3_init();
  int frac = T_REG_TRITS - INT_TRITS;

  /* Skip whitespace */
  while (*s == ' ' || *s == '\t') s++;

  /* Parse sign */
  int negative = 0;
  if (*s == '-') { negative = 1; s++; }
  else if (*s == '+') s++;

  /* Collect significant digits, tracking decimal position */
  int digits[60];
  int ndigits = 0;
  int has_dot = 0;
  int frac_digits = 0;   /* total digits after the dot (including leading zeros) */
  int leading_zeros = 1;

  const char *p = s;
  while (*p) {
    if (*p >= '0' && *p <= '9') {
      int d = *p - '0';
      if (d == 0 && leading_zeros) {
        if (has_dot) frac_digits++;
      } else {
        leading_zeros = 0;
        if (ndigits < 55) digits[ndigits++] = d;
        if (has_dot) frac_digits++;
      }
    } else if (*p == '.') {
      has_dot = 1;
    } else if (*p == 'e' || *p == 'E') {
      p++;
      break;
    } else {
      break;
    }
    p++;
  }

  /* Parse exponent */
  int exp_val = 0;
  int exp_neg = 0;
  if (*p == '-') { exp_neg = 1; p++; }
  else if (*p == '+') p++;
  while (*p >= '0' && *p <= '9') {
    exp_val = exp_val * 10 + (*p - '0');
    p++;
  }
  if (exp_neg) exp_val = -exp_val;

  if (ndigits == 0) { t_clear(dst); return 0; }

  /*
   * value = d₁.d₂d₃...dₙ × 10^total_exp
   * where total_exp = (number of integer significant digits - 1) + exp_val
   */
  int int_digits = ndigits - frac_digits;
  int total_exp = int_digits - 1 + exp_val;

  /*
   * Build m = d₁ + d₂/10 + d₃/100 + ... ∈ [1, 10) in ternary fixed-point.
   * Process right to left: start from the last digit, add, multiply by 0.1.
   * Precompute 1/10 and save to a local so lognum3_mul_fp can't clobber it.
   */
  t_load_int(R0, 1);
  t_shl(R0, R0, frac);
  t_load_int(R1, 10);
  t_shl(R1, R1, frac);
  lognum3_div_fp(R2, R0, R1);        /* R2 = 0.1 in fixed-point */
  treg_t inv10 = *t_reg(R2);         /* save to local */

  t_clear(R0);
  for (int i = ndigits - 1; i >= 0; i--) {
    t_load_int(R1, digits[i]);
    t_shl(R1, R1, frac);
    t_add(R0, R0, R1);
    if (i > 0) {
      *t_reg(R1) = inv10;            /* restore 0.1 */
      lognum3_mul_fp(R0, R0, R1);
    }
  }

  /* R0 = m ∈ [1, 10) in fixed-point.
   * Reduce to d_red ∈ [1, 3): m < 10 < 27 = 3³, so k ∈ {0, 1, 2}. */
  int k = 0;
  {
    long long m_int = lognum3_extract_int_fp(R0);
    if (m_int >= 9) k = 2;
    else if (m_int >= 3) k = 1;
  }
  if (k > 0) t_shr(R0, R0, k);

  /*
   * Compute k_eff = k + total_exp × log₃(10) BEFORE the atanh step,
   * and save it so the atanh computation can use R0..R4 freely.
   */
  t_load_int(R1, total_exp);
  t_shl(R1, R1, frac);
  lognum3_mul_fp(R2, R1, R_LOG3_10); /* R2 = total_exp × log₃(10) */
  t_load_int(R1, k);
  t_shl(R1, R1, frac);
  t_add(R2, R2, R1);                 /* R2 = k_eff */
  treg_t k_eff = *t_reg(R2);         /* save to local */

  /* log₃(d') = 2 · atanh((d' - 1)/(d' + 1)) / ln(3) */
  t_load_int(R1, 1);
  t_shl(R1, R1, frac);
  t_sub(R2, R0, R1);
  t_add(R3, R0, R1);
  lognum3_div_fp(R2, R2, R3);
  lognum3_atanh_small(R3, R2);
  t_add(R3, R3, R3);
  lognum3_mul_fp(R2, R3, R_INVLN3);  /* R2 = log₃(d') */

  /* L = k_eff + log₃(d') */
  *t_reg(R3) = k_eff;
  t_add(dst, R3, R2);

  return negative ? -1 : 1;
}

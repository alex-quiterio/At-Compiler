#pragma once

#include "ternary.h"
#include "balanced3.h"

/*============================================================================
 * takum3.h -- Logarithmic Ternary Takum Arithmetic (80 trits)
 *============================================================================
 *
 * Implements Hunhold's Definition 2 (2024) adapted for balanced ternary
 * with base 3.  The key difference from posit3 is a FIXED-SIZE regime
 * field (2 trits) instead of a variable-length run.
 *
 * BASE ADAPTATION:
 *   Hunhold's takum uses base sqrt(e) so that L = log_{sqrt(e)}(value)
 *   aligns with natural logarithms and transcendental evaluation.  Here
 *   we shift the base to 3 to match the native radix of the underlying
 *   ternary ALU: L = log_3(|value|) becomes an exact fixed-point
 *   balanced-ternary quantity, so multiply/divide reduce to t_add/t_sub
 *   on L with no base-conversion cost inside the hot path.
 *
 * REGIME SIZING:
 *   R is locked to exactly 2 trits.  Balanced interpretation gives
 *   R_bal = R1*3 + R0 in [-4, +4], so r = max(1, |R_bal|) in [1, 4] and
 *   the characteristic range is contiguous [-121, 121] -- a mathematically
 *   sound ternary analogue of takum's fixed-overhead regime, tuned to the
 *   precision headroom of an 80-trit word.
 *
 * Format (80 trits, positive form):
 *
 *   [+1] [R, 2 trits] [C, r trits] [M, 77-r trits]
 *   MST    78-77         76-...        remaining
 *
 * Sign:  implicit in MST (trit 79).  Negative values are trit-flipped.
 *
 * R     = regime, 2 balanced trits: R_bal = R1*3 + R0 in [-4, +4]
 * r     = max(1, |R_bal|) — number of characteristic trits (1..4)
 * C     = characteristic, r trits (unsigned interpretation)
 * M     = mantissa, p = 77 - r trits (73..76 trits)
 *
 * Characteristic formula:
 *   R_bal > 0:  c = (3^r + 1)/2 + C_unsigned
 *   R_bal = 0:  c = C_unsigned - 1
 *   R_bal < 0:  c = -(3^(r+1) - 1)/2 + C_unsigned
 *
 * Value = sign * 3^L, where L = c + m.  M is interpreted as balanced
 * ternary directly into the fractional trits of the fixed-point register,
 * so m in [-1/2, +1/2).  Packed ordering is preserved either way.
 *
 * Special values (same encoding as posit3):
 *   Zero:  all trits = 0   (h[0] = h[1] = T_HALF_BIAS)
 *   +NaR:  all trits = +1  (h[0] = h[1] = T_HALF_MAX)
 *   -NaR:  all trits = -1  (h[0] = h[1] = 0)
 *
 * Properties:
 *   Packed ordering preserved (excluding NaR at extremes).
 *   Min precision: 73 mantissa trits (R=+-4, r=4).
 *   Max precision: 76 mantissa trits (R=0 or +-1, r=1).
 *   Range: |L| up to 121 -> values from ~10^(-58) to ~10^(58).
 *============================================================================*/

typedef struct { unsigned long long h[2]; } takum3_t;

#define TAKUM3_TRITS     80
#define TAKUM3_R_TRITS    2
#define TAKUM3_MAX_R      4     /* |R_bal| max = (3^2-1)/2 = 4 */

/* Zero and NaR */
int takum3_is_zero(takum3_t v);
int takum3_is_nar(takum3_t v);
int takum3_is_positive(takum3_t v);
int takum3_is_negative(takum3_t v);

/* Trit access */
int takum3_get_trit(takum3_t v, int pos);
void takum3_set_trit(takum3_t *result, takum3_t v, int pos, int trit);

/* Arithmetic */
void takum3_neg(takum3_t *result, takum3_t v);
void takum3_add(takum3_t *result, takum3_t a, takum3_t b);
void takum3_sub(takum3_t *result, takum3_t a, takum3_t b);
void takum3_mul(takum3_t *result, takum3_t a, takum3_t b);
void takum3_div(takum3_t *result, takum3_t a, takum3_t b);

/* Conversion */
void takum3_from_double(takum3_t *result, double d);
double takum3_to_double(takum3_t v);
void takum3_from_balanced3(takum3_t *result, balanced3_t b3);
balanced3_t takum3_to_balanced3(takum3_t v);
void takum3_from_string(takum3_t *result, const char *s);

/* I/O */
void takum3_print(takum3_t v);
void takum3_read(takum3_t *result);

/* Comparison (returns balanced3_t: +1 true, -1 false) */
balanced3_t takum3_eq(takum3_t a, takum3_t b);
balanced3_t takum3_ne(takum3_t a, takum3_t b);
balanced3_t takum3_lt(takum3_t a, takum3_t b);
balanced3_t takum3_gt(takum3_t a, takum3_t b);
balanced3_t takum3_le(takum3_t a, takum3_t b);
balanced3_t takum3_ge(takum3_t a, takum3_t b);

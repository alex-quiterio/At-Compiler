#pragma once

/*
 * divmod.h -- 64-bit division/modulo for 32-bit targets.
 *
 * GCC emits calls to __(u)divdi3 and __(u)moddi3 when dividing 
 * long long values on i386.  Normally libgcc provides these, but the
 * RTS is built with -nostdlib -fno-builtin, so we supply our own.
 *
 * Algorithm: binary long division (shift-subtract), operating on
 * 32-bit halves only.  No 64-bit divide instruction is used.
 */

typedef unsigned long long u64;
u64 __udivdi3(u64 a, u64 b);
u64 __umoddi3(u64 a, u64 b);

typedef long long s64;
s64 __divdi3(s64 a, s64 b);
s64 __moddi3(s64 a, s64 b);

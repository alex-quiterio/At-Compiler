#include "posit3.h"
#include "lognum3.h"
#include "string.h"

/*============================================================================
 * posit3.c -- Logarithmic Ternary Posit Arithmetic (80 trits)
 *============================================================================
 *
 * All arithmetic is performed via the ternary ALU (ternary.h).  This
 * file never performs binary arithmetic on trit data -- every operation
 * goes through t_add, t_sub, t_mul, t_div, t_neg, t_shl, t_shr, etc.
 *
 * The binary bridge (t_load_int, t_store_int, t_load_double, etc.) is
 * crossed ONLY in conversion functions (posit3_from_double, posit3_to_double)
 * and I/O.
 *
 * REGISTER ALLOCATION:
 *   T0..T7 are used by posit3 operations.
 *   T8..T11 are reserved for balanced3 (see balanced3.c).
 *   T12..T15 are scratch.
 *
 * SECTIONS:
 *   1. Predicates and trit access (via ALU)
 *   2. Constants (loaded into registers on first use)
 *   3. Transcendentals (exp, atanh, Gaussian logarithm)
 *   4. Decode / encode (packed posit3 <-> log L in register)
 *   5. Native arithmetic
 *   6. Conversion and I/O
 *   7. Comparison
 *============================================================================*/

/*
 * Fixed-point format for internal log arithmetic.
 *
 * The logarithm L = log_3(|value|) is stored as a fixed-point balanced
 * ternary number in a 120-trit ALU register, with INT_TRITS integer
 * trits and the remaining 120 - INT_TRITS fractional trits.
 *
 * INT_TRITS = 12 gives range ±(3^12-1)/2 = ±265720, far exceeding
 * the maximum |L| = regime_max * GROWTH + 4 = 706.
 */
/* Local aliases mapping to the shared lognum3 register convention. */
#define INT_TRITS    LOGNUM3_INT_TRITS

#define R0 LN_R0
#define R1 LN_R1
#define R2 LN_R2
#define R3 LN_R3
#define R4 LN_R4
#define R5 LN_R5
#define R6 LN_R6
#define R7 LN_R7
#define RSCRATCH  LN_RSCRATCH
#define RSCRATCH2 LN_RSCRATCH2
#define RSCRATCH3 LN_RSCRATCH3

#define R_LN3     LN_R_LN3
#define R_INVLN3  LN_R_INVLN3
#define R_LOG3_2  LN_R_LOG3_2
#define R_LOG3_10 LN_R_LOG3_10

/* ================================================================== */
/*  SECTION 1: PREDICATES AND TRIT ACCESS                             */
/* ================================================================== */

/*
 * Mask to 80 trits: zero trits 80-119 (half 2 at bias).
 * Used after arithmetic to enforce the 80-trit word width.
 */
static void mask80(int r) {
  t_reg(r)->h[2] = T_HALF_BIAS;
}

/*
 * Load a packed posit3_t (16 bytes) into a 120-trit ALU register (24 bytes).
 * The third half is set to bias (zero trits).
 */
static void posit3_load(int r, posit3_t v) {
  treg_t *reg = t_reg(r);
  reg->h[0] = v.h[0];
  reg->h[1] = v.h[1];
  reg->h[2] = T_HALF_BIAS;
}

/* Read an ALU register as a packed posit3_t (masked to 80 trits). */
static posit3_t posit3_read_reg(int r) {
  mask80(r);
  posit3_t v;
  v.h[0] = t_reg(r)->h[0];
  v.h[1] = t_reg(r)->h[1];
  return v;
}

int posit3_is_zero(posit3_t v) {
  return v.h[0] == T_HALF_BIAS && v.h[1] == T_HALF_BIAS;
}

int posit3_is_nar(posit3_t v) {
  return (v.h[0] == T_HALF_MAX && v.h[1] == T_HALF_MAX)
      || (v.h[0] == 0 && v.h[1] == 0);
}

int posit3_is_positive(posit3_t v) {
  /* trit 79 is in half 1 (trits 40-79); positive if half 1 > bias,
   * or half 1 == bias and half 0 > bias */
  return v.h[1] > T_HALF_BIAS
      || (v.h[1] == T_HALF_BIAS && v.h[0] > T_HALF_BIAS);
}

int posit3_is_negative(posit3_t v) {
  return v.h[1] < T_HALF_BIAS
      || (v.h[1] == T_HALF_BIAS && v.h[0] < T_HALF_BIAS);
}

int posit3_get_trit(posit3_t v, int pos) {
  if (pos < 0 || pos >= POSIT3_TRITS) return 0;
  posit3_load(RSCRATCH, v);
  return t_get_trit(RSCRATCH, pos);
}

void posit3_set_trit(posit3_t *result, posit3_t v, int pos, int trit) {
  if (pos < 0 || pos >= POSIT3_TRITS) { *result = v; return; }
  posit3_load(RSCRATCH, v);
  t_set_trit(RSCRATCH, pos, trit);
  mask80(RSCRATCH);
  *result = posit3_read_reg(RSCRATCH);
}

static posit3_t posit3_neg_val(posit3_t v) {
  posit3_load(RSCRATCH, v);
  t_neg(RSCRATCH, RSCRATCH);
  mask80(RSCRATCH);
  return posit3_read_reg(RSCRATCH);
}

void posit3_neg(posit3_t *result, posit3_t v) {
  *result = posit3_neg_val(v);
}

/* Construct a posit3_t from its two packed halves. */
static posit3_t posit3_pack(unsigned long long h0, unsigned long long h1) {
  posit3_t v;
  v.h[0] = h0;
  v.h[1] = h1;
  return v;
}

#define POSIT3_ZERO  posit3_pack(T_HALF_BIAS, T_HALF_BIAS)
#define POSIT3_PNAR  posit3_pack(T_HALF_MAX,  T_HALF_MAX)
#define POSIT3_NNAR  posit3_pack(0,           0)
/* max/min finite: all trits +1/-1 except trit 0 (distinguishes from NaR) */
#define POSIT3_MAXFIN posit3_pack(T_HALF_MAX - 1, T_HALF_MAX)
#define POSIT3_MINFIN posit3_pack(1,              0)
/* Smallest-magnitude finite values (for underflow saturation -- classic
 * posit semantics round tiny to minpos, never flushing to zero).
 * MIN_POS_FIN = pack-just-above-zero; MAX_NEG_FIN = pack-just-below-zero. */
#define POSIT3_MIN_POS_FIN posit3_pack(T_HALF_BIAS + 1, T_HALF_BIAS)
#define POSIT3_MAX_NEG_FIN posit3_pack(T_HALF_BIAS - 1, T_HALF_BIAS)

/* Sections 2 (constants) and 3 (transcendentals) have been extracted
 * to lognum3.c.  See lognum3.h for the shared API. */



/* ================================================================== */
/*  SECTION 4: DECODE / ENCODE                                        */
/* ================================================================== */

/*
 * decode_log -- extract the fixed-point L = log_3(|value|) from a
 * posit3_t.  Stores L in register `dst`.  Returns the sign (+1 or -1)
 * and sets *is_nar if the value is NaR.
 *
 * The posit3's regime/exponent/fraction fields ARE L, just packed in
 * the variable-width posit encoding.  We unpack them into a uniform
 * fixed-point register representation.
 */
static int decode_log(int dst, posit3_t v, int *is_nar) {
  *is_nar = 0;
  if (posit3_is_zero(v)) { t_clear(dst); return 0; }
  if (posit3_is_nar(v))  { t_clear(dst); *is_nar = 1; return posit3_is_positive(v) ? 1 : -1; }

  int sign;
  if (posit3_is_negative(v)) { sign = -1; v = posit3_neg_val(v); }
  else { sign = 1; }

  posit3_load(RSCRATCH, v);

  /* decode regime from trit 78 downward.
   *
   * TERNARY POSIT REGIME TERMINATION: standard binary posits use the
   * opposite bit to close a regime run (e.g., 1110 or 0001).  Balanced
   * ternary gives us a third state (0) that neither continues a +1 run
   * nor a -1 run, so we use the 0 trit as a neutral run-delimiter.
   * This removes the need to branch on the run direction when reading
   * the terminator and consumes exactly one trit regardless of sign. */
  int cursor = POSIT3_TRITS - 2;  /* trit 78 */
  int regime = 0;

  int run_trit = t_get_trit(RSCRATCH, cursor);
  if (run_trit == 1) {
    while (cursor >= 0 && t_get_trit(RSCRATCH, cursor) == 1)
      { regime++; cursor--; }
    if (cursor >= 0) cursor--;  /* terminator (0 trit) */
  } else if (run_trit == -1) {
    while (cursor >= 0 && t_get_trit(RSCRATCH, cursor) == -1)
      { regime--; cursor--; }
    if (cursor >= 0) cursor--;  /* terminator (0 trit) */
  } else {
    cursor--;  /* regime = 0, no run */
  }

  /* exponent field: 2 trits (MST first) */
  int e1 = 0, e0 = 0;
  if (cursor >= 0) { e1 = t_get_trit(RSCRATCH, cursor); cursor--; }
  if (cursor >= 0) { e0 = t_get_trit(RSCRATCH, cursor); cursor--; }
  int exp_field = e1 * 3 + e0;

  /* L_int = regime * 9 + exp_field */
  int L_int = regime * POSIT3_GROWTH + exp_field;

  /* store L as fixed-point: integer part + fraction trits */
  t_load_int(dst, L_int);
  t_shl(dst, dst, T_REG_TRITS - INT_TRITS);  /* position integer part */

  /* fraction trits: from cursor down to 0, these are the most-significant
   * fraction trits of L.  They go into trit positions starting at
   * T_REG_TRITS - INT_TRITS - 1 (the first fraction trit). */
  int frac_pos = T_REG_TRITS - INT_TRITS - 1;
  for (int i = cursor; i >= 0 && frac_pos >= 0; i--, frac_pos--)
    t_set_trit(dst, frac_pos, t_get_trit(RSCRATCH, i));

  return sign;
}

/*
 * encode_log -- encode a fixed-point L (in register `src`) and a sign
 * back into a packed posit3_t.
 */
static posit3_t encode_log(int src, int sign, int is_nar) {
  if (sign == 0) return POSIT3_ZERO;
  if (is_nar) return (sign > 0) ? POSIT3_PNAR : POSIT3_NNAR;

  /* extract integer part of L */
  int L_int = (int)lognum3_extract_int_fp(src);

  /* decompose L_int = regime * GROWTH + exp_field, exp_field in [-4,+4] */
  int regime = L_int / POSIT3_GROWTH;
  int exp_field = L_int - regime * POSIT3_GROWTH;
  while (exp_field > 4)  { regime++; exp_field -= POSIT3_GROWTH; }
  while (exp_field < -4) { regime--; exp_field += POSIT3_GROWTH; }

  int abs_regime = (regime >= 0) ? regime : -regime;
  if (abs_regime >= POSIT3_REGIME_MAX) {
    /* Saturate at the dynamic-range boundary: overflow to MAX/MIN finite,
     * underflow to MIN_POS_FIN/MAX_NEG_FIN.  Posit arithmetic rounds to the
     * nearest finite, never flushing to zero or crossing to NaR. */
    if (regime > 0)
      return (sign > 0) ? POSIT3_MAXFIN : POSIT3_MINFIN;
    else
      return (sign > 0) ? POSIT3_MIN_POS_FIN : POSIT3_MAX_NEG_FIN;
  }

  /* build trit pattern in an ALU register */
  t_clear(R0);
  int cursor = POSIT3_TRITS - 1;

  t_set_trit(R0, cursor--, 1);  /* MST = +1 */

  /* regime run + terminator */
  if (regime > 0) {
    for (int i = 0; i < regime && cursor >= 0; i++)
      t_set_trit(R0, cursor--, 1);
    if (cursor >= 0) t_set_trit(R0, cursor--, 0);
  } else if (regime < 0) {
    for (int i = 0; i < -regime && cursor >= 0; i++)
      t_set_trit(R0, cursor--, -1);
    if (cursor >= 0) t_set_trit(R0, cursor--, 0);
  } else {
    if (cursor >= 0) t_set_trit(R0, cursor--, 0);
  }

  /* exponent (2 trits) */
  int r0 = exp_field % 3;
  if (r0 > 1) r0 -= 3;
  if (r0 < -1) r0 += 3;
  int r1 = (exp_field - r0) / 3;
  if (r1 > 1) r1 -= 3;
  if (r1 < -1) r1 += 3;
  if (cursor >= 0) t_set_trit(R0, cursor--, r1);
  if (cursor >= 0) t_set_trit(R0, cursor--, r0);

  /* fraction trits from L's fractional part */
  int frac_src = T_REG_TRITS - INT_TRITS - 1;  /* first frac trit in src */
  for (int i = cursor; i >= 0 && frac_src >= 0; i--, frac_src--)
    t_set_trit(R0, i, t_get_trit(src, frac_src));

  mask80(R0);
  posit3_t result = posit3_read_reg(R0);

  if (sign < 0) result = posit3_neg_val(result);
  return result;
}


/* ================================================================== */
/*  SECTION 5: NATIVE ARITHMETIC                                      */
/* ================================================================== */

/*
 * posit3_mul:  L_result = L_a + L_b,  sign_result = sign_a * sign_b
 */
void posit3_mul(posit3_t *result, posit3_t a, posit3_t b) {
  lognum3_init();
  if (posit3_is_nar(a)) { *result = a; return; }
  if (posit3_is_nar(b)) { *result = b; return; }
  if (posit3_is_zero(a) || posit3_is_zero(b)) {
    *result = POSIT3_ZERO; return;
  }

  int nar_a, nar_b;
  int sa = decode_log(R0, a, &nar_a);  /* R0 = L_a */
  int sb = decode_log(R1, b, &nar_b);  /* R1 = L_b */

  t_add(R2, R0, R1);  /* R2 = L_a + L_b */

  *result = encode_log(R2, sa * sb, 0);
}

/*
 * posit3_div:  L_result = L_a - L_b,  sign_result = sign_a * sign_b
 */
void posit3_div(posit3_t *result, posit3_t a, posit3_t b) {
  lognum3_init();
  if (posit3_is_nar(a)) { *result = a; return; }
  if (posit3_is_zero(b)) {
    *result = (posit3_is_zero(a) || posit3_is_positive(a)) ? POSIT3_PNAR : POSIT3_NNAR;
    return;
  }
  if (posit3_is_nar(b)) { *result = POSIT3_ZERO; return; }
  if (posit3_is_zero(a)) { *result = POSIT3_ZERO; return; }

  int nar_a, nar_b;
  int sa = decode_log(R0, a, &nar_a);
  int sb = decode_log(R1, b, &nar_b);

  t_sub(R2, R0, R1);  /* R2 = L_a - L_b */

  *result = encode_log(R2, sa * sb, 0);
}

/*
 * posit3_add:  a + b using the Gaussian logarithm.
 *
 * Same sign:   L_result = L_a + φ(L_b - L_a),  ensure |a| >= |b|
 * Diff sign:   L_result = L_a + ψ(L_b - L_a),  ensure |a| >= |b|
 */
static posit3_t posit3_add_val(posit3_t a, posit3_t b) {
  lognum3_init();
  if (posit3_is_nar(a)) return a;
  if (posit3_is_nar(b)) return b;
  if (posit3_is_zero(a)) return b;
  if (posit3_is_zero(b)) return a;

  int nar_a, nar_b;
  int sa = decode_log(R0, a, &nar_a);  /* R0 = L_a */
  int sb = decode_log(R1, b, &nar_b);  /* R1 = L_b */

  /* ensure |a| >= |b|: larger L = larger magnitude */
  if (t_cmp(R1, R0) > 0) {
    /* swap */
    t_copy(R2, R0); t_copy(R0, R1); t_copy(R1, R2);
    int tmp = sa; sa = sb; sb = tmp;
  }

  /* d = L_b - L_a  (≤ 0) */
  t_sub(R2, R1, R0);  /* R2 = d */

  /* Save L_a: gauss_phi/psi clobber R0-R4 and all scratch registers */
  treg_t saved_La = *t_reg(R0);

  if (sa == sb) {
    /* same sign: L_result = L_a + φ(d) */
    lognum3_gauss_phi(R3, R2);      /* R3 = φ(d) */
    *t_reg(R0) = saved_La;          /* restore L_a */
    t_add(R4, R0, R3);      /* R4 = L_a + φ(d) */
    return encode_log(R4, sa, 0);
  } else {
    /* different signs */
    if (t_is_zero(R2)) {
      /* |a| == |b|, exact cancellation */
      return POSIT3_ZERO;
    }
    lognum3_gauss_psi(R3, R2);      /* R3 = ψ(d) */
    *t_reg(R0) = saved_La;          /* restore L_a */
    t_add(R4, R0, R3);      /* R4 = L_a + ψ(d) */
    return encode_log(R4, sa, 0);
  }
}

void posit3_add(posit3_t *result, posit3_t a, posit3_t b) {
  *result = posit3_add_val(a, b);
}

/*
 * posit3_sub:  a - b = a + (-b)
 */
void posit3_sub(posit3_t *result, posit3_t a, posit3_t b) {
  lognum3_init();
  if (posit3_is_nar(a)) { *result = a; return; }
  if (posit3_is_nar(b)) { *result = b; return; }
  *result = posit3_add_val(a, posit3_neg_val(b));
}


/* ================================================================== */
/*  SECTION 6: CONVERSION AND I/O                                     */
/* ================================================================== */

void posit3_from_double(posit3_t *result, double d) {
  if (d == 0.0) { *result = POSIT3_ZERO; return; }
  lognum3_init();

  int negative = 0;
  if (d < 0.0) { negative = 1; d = -d; }

  int k = 0;
  double d_red = d;
  while (d_red >= 3.0) { d_red /= 3.0; k++; }
  while (d_red < 1.0)  { d_red *= 3.0;  k--; }

  if (k > POSIT3_REGIME_MAX * POSIT3_GROWTH + 4) {
    *result = negative ? POSIT3_MINFIN : POSIT3_MAXFIN; return;
  }
  if (k < -(POSIT3_REGIME_MAX * POSIT3_GROWTH + 4) - 1) {
    *result = negative ? POSIT3_MAX_NEG_FIN : POSIT3_MIN_POS_FIN; return;
  }

  int frac = T_REG_TRITS - INT_TRITS;

  if (k >= 0 && d <= 265720.0) {
    t_load_double(R0, d, INT_TRITS);
    if (k > 0) t_shr(R0, R0, k);
  } else {
    t_load_double(R0, d_red, INT_TRITS);
  }

  /* log₃(d') = 2·atanh((d'-1)/(d'+1)) / ln(3), where d' ∈ [1,3) */
  t_load_int(R1, 1);
  t_shl(R1, R1, frac);
  t_sub(R2, R0, R1);
  t_add(R3, R0, R1);
  lognum3_div_fp(R2, R2, R3);
  lognum3_atanh_small(R3, R2);
  t_add(R3, R3, R3);
  lognum3_mul_fp(R2, R3, R_INVLN3);

  t_load_int(R3, k);
  t_shl(R3, R3, frac);
  t_add(RSCRATCH, R3, R2);

  *result = encode_log(RSCRATCH, negative ? -1 : 1, 0);
}

double posit3_to_double(posit3_t v) {
  if (posit3_is_zero(v)) return 0.0;
  if (posit3_is_nar(v)) {
    return posit3_is_positive(v) ? 1.7976931348623157e+308 : -1.7976931348623157e+308;
  }

  int is_nar;
  int sign = decode_log(R0, v, &is_nar);

  double L = t_store_double(R0, INT_TRITS);

  /* value = 3^L */
  int L_int = (int)L;
  double L_frac = L - L_int;

  double val = 1.0;
  if (L_int >= 0) { for (int i = 0; i < L_int; i++) val *= 3.0; }
  else { for (int i = 0; i < -L_int; i++) val /= 3.0; }

  /* 3^L_frac = exp(L_frac * ln(3)) */
  double x = L_frac * 1.0986122886681098;
  double exp_x = 1.0, term = 1.0;
  for (int i = 1; i < 30; i++) { term *= x / i; exp_x += term; }
  val *= exp_x;

  return (sign < 0) ? -val : val;
}

void posit3_from_balanced3(posit3_t *result, balanced3_t b3) {
  lognum3_init();

  /* Load balanced3 (40 trits) into ALU register -- pure ternary */
  treg_t *reg = t_reg(R0);
  reg->h[0] = b3;
  reg->h[1] = T_HALF_BIAS;
  reg->h[2] = T_HALF_BIAS;

  long long val = t_store_int(R0);
  if (val == 0) { *result = POSIT3_ZERO; return; }

  int negative = 0;
  if (val < 0) { negative = 1; val = -val; t_neg(R0, R0); mask80(R0); }

  /* k = floor(log₃(|val|)) so that d_red = |val|/3^k ∈ [1,3) */
  int k = 0;
  { long long tmp = val; while (tmp >= 3) { tmp /= 3; k++; } }

  /* Place d_red in fixed-point: shift so MST sits at the 3^0 position */
  int frac = T_REG_TRITS - INT_TRITS;
  t_shl(R0, R0, frac - k);

  /* log₃(d') = 2·atanh((d'-1)/(d'+1)) / ln(3) */
  t_load_int(R1, 1);
  t_shl(R1, R1, frac);
  t_sub(R2, R0, R1);
  t_add(R3, R0, R1);
  lognum3_div_fp(R2, R2, R3);
  lognum3_atanh_small(R3, R2);
  t_add(R3, R3, R3);
  lognum3_mul_fp(R2, R3, R_INVLN3);

  t_load_int(R3, k);
  t_shl(R3, R3, frac);
  t_add(RSCRATCH, R3, R2);

  *result = encode_log(RSCRATCH, negative ? -1 : 1, 0);
}

balanced3_t posit3_to_balanced3(posit3_t v) {
  if (posit3_is_zero(v)) return balanced3_from_int(0);
  if (posit3_is_nar(v))  return balanced3_from_int(0);

  int is_nar;
  int sign = decode_log(R0, v, &is_nar);

  /* 3^L in the ternary ALU (fixed-point result) */
  lognum3_3_to_d(R1, R0);

  /* Extract integer part from fixed-point and apply sign */
  long long ival = lognum3_extract_int_fp(R1);
  if (sign < 0) ival = -ival;
  return balanced3_from_int64(ival);
}

/*
 * posit3_print -- native ternary decimal output in scientific notation.
 *
 * 1. Decode posit → fixed-point L = log₃(|value|).
 * 2. Compute decimal exponent: dec_exp ≈ floor(L · log₁₀(3)).
 * 3. Reduce L' = L - dec_exp · log₃(10) so 3^L' ∈ [1, 10).
 * 4. Compute mantissa = 3^L' via alu_3_to_d.
 * 5. Adjust mantissa/exponent so leading digit ∈ [1, 9].
 * 6. Output as D.DDDe±EE (exponent omitted when zero).
 */
#define POSIT3_FRAC_DIGITS 36

void posit3_print(posit3_t v) {
  lognum3_init();
  if (posit3_is_zero(v)) { prints("0"); return; }
  if (posit3_is_nar(v)) {
    prints(posit3_is_positive(v) ? "+NaR" : "-NaR");
    return;
  }

  int is_nar;
  int sign = decode_log(R0, v, &is_nar);
  if (sign < 0) prints("-");

  int frac_trits = T_REG_TRITS - INT_TRITS;

  /*
   * Compute approximate decimal exponent from L.
   * log₁₀(|value|) = L · log₁₀(3).  log₁₀(3) ≈ 0.47712.
   * Use integer approximation on L's integer part.
   */
  long long L_int = lognum3_extract_int_fp(R0);
  int dec_exp = 0;

  if (L_int > 0)
    dec_exp = (int)(L_int * 47712LL / 100000LL);
  else if (L_int < 0)
    dec_exp = (int)((L_int * 47712LL - 99999LL) / 100000LL);

  /* Reduce: L' = L - dec_exp · log₃(10) */
  if (dec_exp != 0) {
    t_load_int(R3, (long long)dec_exp);
    t_shl(R3, R3, frac_trits);
    lognum3_mul_fp(R3, R3, R_LOG3_10);    /* R3 = dec_exp · log₃(10) */
    t_sub(R0, R0, R3);            /* R0 = L' */
  }

  /* mantissa = 3^L' (should be near [1, 10)) */
  lognum3_3_to_d(R1, R0);

  /* Extract integer part of mantissa */
  t_copy(R2, R1);
  t_shr(R2, R2, frac_trits);
  long long int_part = t_store_int(R2);

  /* Adjust mantissa into [1, 10): divide or multiply by 10 */
  int safety = 20;
  while (int_part >= 10 && safety-- > 0) {
    t_div_small(R1, R1, 10);
    dec_exp++;
    t_copy(R2, R1);
    t_shr(R2, R2, frac_trits);
    int_part = t_store_int(R2);
  }
  safety = 20;
  while (int_part <= 0 && !t_is_zero(R1) && safety-- > 0) {
    t_shl(R2, R1, 2);
    t_add(R1, R2, R1);           /* R1 *= 10 */
    dec_exp--;
    t_copy(R2, R1);
    t_shr(R2, R2, frac_trits);
    int_part = t_store_int(R2);
  }

  if (int_part < 1) int_part = 1;
  if (int_part > 9) int_part = 9;

  /* Separate integer and fractional parts */
  t_load_int(R2, int_part);
  t_shl(R2, R2, frac_trits);
  t_sub(R1, R1, R2);             /* R1 = fractional part */

  /* Normalize: ensure fraction ≥ 0 */
  if (t_sign(R1) < 0) {
    int_part--;
    if (int_part < 1) { int_part = 9; dec_exp--; }
    t_load_int(R2, 1);
    t_shl(R2, R2, frac_trits);
    t_add(R1, R1, R2);
  }

  /* Print leading digit */
  char lbuf[2] = { '0' + (int)int_part, '\0' };
  prints(lbuf);

  /* Fractional digits: multiply by 10 repeatedly, extract digit */
  if (!t_is_zero(R1)) {
    char fbuf[POSIT3_FRAC_DIGITS + 2];
    fbuf[0] = '.';
    int flen = 1;
    int trailing_zeros = 0;

    for (int i = 0; i < POSIT3_FRAC_DIGITS; i++) {
      /* R1*10 = shl(R1,2) + R1  (since 10 = 9 + 1 = 3² + 1) */
      t_shl(R2, R1, 2);
      t_add(R2, R2, R1);

      /* extract digit = integer part of R2 */
      t_copy(RSCRATCH, R2);
      t_shr(RSCRATCH, RSCRATCH, frac_trits);
      int digit = (int)t_store_int(RSCRATCH);

      /* subtract digit to keep fractional remainder */
      t_shl(RSCRATCH, RSCRATCH, frac_trits);
      t_sub(R1, R2, RSCRATCH);

      /* normalize: if remainder is negative, adjust digit down */
      if (t_sign(R1) < 0) {
        digit--;
        t_load_int(RSCRATCH, 1);
        t_shl(RSCRATCH, RSCRATCH, frac_trits);
        t_add(R1, R1, RSCRATCH);
      }

      if (digit < 0) digit = 0;
      if (digit > 9) digit = 9;

      if (digit == 0) {
        trailing_zeros++;
      } else {
        for (int z = 0; z < trailing_zeros; z++)
          fbuf[flen++] = '0';
        trailing_zeros = 0;
        fbuf[flen++] = '0' + digit;
      }

      if (t_is_zero(R1)) break;
    }

    fbuf[flen] = '\0';
    if (flen > 1)
      prints(fbuf);
  }

  /* Print exponent if non-zero */
  if (dec_exp != 0) {
    char ebuf[20];
    int epos = 19;
    ebuf[epos] = '\0';
    int abs_exp = dec_exp < 0 ? -dec_exp : dec_exp;
    while (abs_exp > 0) {
      ebuf[--epos] = '0' + (abs_exp % 10);
      abs_exp /= 10;
    }
    ebuf[--epos] = dec_exp < 0 ? '-' : '+';
    ebuf[--epos] = 'e';
    prints(ebuf + epos);
  }
}

void posit3_read(posit3_t *result) {
  char buf[128];
  if (readln(buf, 128) == 0) { *result = POSIT3_ZERO; return; }
  posit3_from_string(result, buf);
}

void posit3_from_string(posit3_t *result, const char *s) {
  int sign = lognum3_parse_decimal(RSCRATCH, s);
  if (sign == 0) { *result = POSIT3_ZERO; return; }
  *result = encode_log(RSCRATCH, sign, 0);
}


/* ================================================================== */
/*  SECTION 7: COMPARISON                                             */
/* ================================================================== */

/*
 * Comparison exploits the ordering-preserving property of the packed
 * representation.  We load both values and compare halves from MST
 * to LST.  Since both types are treg_t, we can use t_cmp directly
 * (but we only care about the 80-trit portion, i.e., halves 0 and 1).
 */
static int posit3_cmp_packed(posit3_t a, posit3_t b) {
  /* compare half 1 (trits 40-79, contains MST) first */
  if (a.h[1] > b.h[1]) return 1;
  if (a.h[1] < b.h[1]) return -1;
  if (a.h[0] > b.h[0]) return 1;
  if (a.h[0] < b.h[0]) return -1;
  return 0;
}

balanced3_t posit3_eq(posit3_t a, posit3_t b) {
  return balanced3_from_int(posit3_cmp_packed(a, b) == 0 ? 1 : -1);
}
balanced3_t posit3_ne(posit3_t a, posit3_t b) {
  return balanced3_from_int(posit3_cmp_packed(a, b) != 0 ? 1 : -1);
}
balanced3_t posit3_lt(posit3_t a, posit3_t b) {
  return balanced3_from_int(posit3_cmp_packed(a, b) < 0 ? 1 : -1);
}
balanced3_t posit3_gt(posit3_t a, posit3_t b) {
  return balanced3_from_int(posit3_cmp_packed(a, b) > 0 ? 1 : -1);
}
balanced3_t posit3_le(posit3_t a, posit3_t b) {
  return balanced3_from_int(posit3_cmp_packed(a, b) <= 0 ? 1 : -1);
}
balanced3_t posit3_ge(posit3_t a, posit3_t b) {
  return balanced3_from_int(posit3_cmp_packed(a, b) >= 0 ? 1 : -1);
}

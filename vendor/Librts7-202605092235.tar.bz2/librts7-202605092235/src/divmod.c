/*
 * divmod.c -- 64-bit division/modulo for 32-bit targets.
 *
 * GCC emits calls to __(u)divdi3 and __(u)moddi3 when dividing 
 * long long values on i386.  Normally libgcc provides these, but the
 * RTS is built with -nostdlib -fno-builtin, so we supply our own.
 *
 * Algorithm: binary long division (shift-subtract), operating on
 * 32-bit halves only.  No 64-bit divide instruction is used.
 */

#include "divmod.h"

typedef unsigned int u32;

static u64 udivmod64(u64 num, u64 den, u64 *rem) {
    if (den == 0) {
        /* undefined; return 0 to avoid hanging */
        if (rem) *rem = 0;
        return 0;
    }

    /* fast path: if both fit in 32 bits, use hw divide */
    if ((num >> 32) == 0 && (den >> 32) == 0) {
        u32 q = (u32)num / (u32)den;
        if (rem) *rem = (u32)num % (u32)den;
        return q;
    }

    /* binary long division: one bit at a time */
    u64 quot = 0;
    u64 r    = 0;

    for (int i = 63; i >= 0; i--) {
        r = (r << 1) | ((num >> i) & 1);
        if (r >= den) {
            r -= den;
            quot |= (u64)1 << i;
        }
    }

    if (rem) *rem = r;
    return quot;
}

u64 __udivdi3(u64 a, u64 b) {
    return udivmod64(a, b, (u64 *)0);
}

u64 __umoddi3(u64 a, u64 b) {
    u64 r;
    udivmod64(a, b, &r);
    return r;
}

s64 __divdi3(s64 a, s64 b) {
    int neg = 0;
    if (a < 0) { a = -a; neg = !neg; }
    if (b < 0) { b = -b; neg = !neg; }
    s64 q = (s64)udivmod64((u64)a, (u64)b, (u64 *)0);
    return neg ? -q : q;
}

s64 __moddi3(s64 a, s64 b) {
    int neg = (a < 0);
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    u64 r;
    udivmod64((u64)a, (u64)b, &r);
    return neg ? -(s64)r : (s64)r;
}
